package test.java.stepdefs.com.cvshealth.digital.cat.clinicaltools;

import cucumber.api.java.en.Then;
import test.java.stepdefs.com.cvshealth.digital.library.AbstractStepDefinition;
import test.java.stepdefs.com.cvshealth.digital.library.DBCacheSingleton;
import test.java.stepdefs.com.cvshealth.digital.library.ExceptionHandler;
import test.java.stepdefs.com.cvshealth.digital.library.ExecutionContext;
import test.java.stepdefs.com.cvshealth.digital.library.OperationsDesktop;

public class AsNeededMedications extends AbstractStepDefinition {
	
	@Then("^User is able to see all basic components of AsNeeded medications table$")
	public void user_is_able_to_see_all_basic_componenets_of_AsNeeded_medications_table() {

		reportUtility.performInitialSetupForStep(executionContext);

		try {

			// Retrieve all the xpath needed for validation
			String directionForUsePath = ExecutionContext.getObjectLocator(
					DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "PrescriptionSchedule_Page",
					"wElt_DirectionForUse_Other", Browser);
			String refillInfoPath = ExecutionContext.getObjectLocator(
					DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "PrescriptionSchedule_Page",
					"wElt_RefillInfo_Other", Browser);
			/*String sixMonthPickUpHistoryPath = ExecutionContext.getObjectLocator(
					DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "PrescriptionSchedule_Page",
					"wElt_6MonthPickUpHistory", Browser);*/
			String morningSlotPath = ExecutionContext.getObjectLocator(
					DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "PrescriptionSchedule_Page",
					"wElt_MorningSlot_AsNeeded", Browser);
			String middaySlotPath = ExecutionContext.getObjectLocator(
					DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "PrescriptionSchedule_Page",
					"wElt_MiddaySlot_AsNeeded", Browser);
			String eveningSlotPath = ExecutionContext.getObjectLocator(
					DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "PrescriptionSchedule_Page",
					"wElt_EveningSlot_AsNeeded", Browser);
			String bedtimeSlotPath = ExecutionContext.getObjectLocator(
					DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "PrescriptionSchedule_Page",
					"wElt_BedtimeSlot_AsNeeded", Browser);

			// Verify Medications or Directions for use column
			executionContext.setXpathDataPair(directionForUsePath, "");
			OperationsDesktop.exist(executionContext);

			// Verify Refill Information column
			executionContext.setXpathDataPair(refillInfoPath, "");
			OperationsDesktop.exist(executionContext);

			/*// Verify 6 Month Pick Up Information column
			executionContext.setXpathDataPair(sixMonthPickUpHistoryPath, "");
			OperationsDesktop.exist(executionContext);*/
                   	
        
			// Verify Morning Slot column
			executionContext.setXpathDataPair(morningSlotPath, "");
			OperationsDesktop.scroll_To_Object(executionContext);
			OperationsDesktop.exist(executionContext);

			// Verify Middday Slot column
			executionContext.setXpathDataPair(middaySlotPath, "");
			OperationsDesktop.exist(executionContext);

			// Verify Evening Slot column
			executionContext.setXpathDataPair(eveningSlotPath, "");
			OperationsDesktop.exist(executionContext);

			// Verify Bedtime Slot column
			executionContext.setXpathDataPair(bedtimeSlotPath, "");
			OperationsDesktop.exist(executionContext); 

		} catch (Exception e) {

			ExceptionHandler.handleException(e);
			reportUtility.setStatusOfOperationForStep(executionContext, false);

		}

		reportUtility.finalStatusSetupToExecuteForEveryStep(executionContext);
	}


/*@Then("^User is able to see \"<rxnumber>\",\"<refillsremaining>\",\"<rxstore>\",\"<telephonenumber>\",\"<prescribername>\" for medication \"<medication>\"\r\n" + 
		"$")
public void Verify_RxInformation_for_AsNeeded_Medications() {
	
	reportUtility.performInitialSetupForStep(executionContext);

	try {

		// Retrieve all the xpath needed for validation
		String directionForUsePath = ExecutionContext.getObjectLocator(
				DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "PrescriptionSchedule_Page",
				"wElt_DirectionForUse_Other", Browser);
		String refillInfoPath = ExecutionContext.getObjectLocator(
				DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "PrescriptionSchedule_Page",
				"wElt_RefillInfo_Other", Browser);
		
		String rxNumberPath = ExecutionContext.getObjectLocator(
				DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "PrescriptionSchedule_Page",
				"wElt_rxNumber", Browser);
		String refillRemainingPath = ExecutionContext.getObjectLocator(
				DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "PrescriptionSchedule_Page",
				"wElt_refillRemaining", Browser);
		String rxStorePath = ExecutionContext.getObjectLocator(
				DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "PrescriptionSchedule_Page",
				"wElt_rxStore", Browser);
		String telephoneNumberPath = ExecutionContext.getObjectLocator(
				DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "PrescriptionSchedule_Page",
				"wElt_telephoneNumber", Browser);
		String prescriberNamePath = ExecutionContext.getObjectLocator(
				DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "PrescriptionSchedule_Page",
				"wElt_prescriberName", Browser);
		String medicaionPath = ExecutionContext.getObjectLocator(
				DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "PrescriptionSchedule_Page",
				"wElt_medication", Browser);
		// Verify Medications or Directions for use column
		executionContext.setXpathDataPair(directionForUsePath, "");
		OperationsDesktop.exist(executionContext);

		// Verify refillinfo column
		executionContext.setXpathDataPair(refillInfoPath, "");
		OperationsDesktop.exist(executionContext);
 
		// Verify rxnumber column
		executionContext.setXpathDataPair(rxNumberPath, "");
		OperationsDesktop.exist(executionContext);               	
    
		// Verify refillremaining column
		executionContext.setXpathDataPair(refillRemainingPath, "");
		//OperationsDesktop.scroll_To_Object(executionContext);
		OperationsDesktop.exist(executionContext);

		// Verify rxstore column
		executionContext.setXpathDataPair(rxStorePath, "");
		OperationsDesktop.exist(executionContext);

		// Verify telephone number column
		executionContext.setXpathDataPair(telephoneNumberPath, "");
		OperationsDesktop.exist(executionContext);

		// Verify prescriber namet column
		executionContext.setXpathDataPair(prescriberNamePath, "");
		OperationsDesktop.exist(executionContext); 

		// Verify medication column
				executionContext.setXpathDataPair(medicaionPath, "");
				OperationsDesktop.exist(executionContext); 

	} catch (Exception e) {

		ExceptionHandler.handleException(e);
		reportUtility.setStatusOfOperationForStep(executionContext, false);

	}

	reportUtility.finalStatusSetupToExecuteForEveryStep(executionContext);
}*/

}