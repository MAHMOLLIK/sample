package test.java.stepdefs.com.cvshealth.digital.library;

import java.util.ArrayList;


import java.util.Date;
import java.util.List;
import java.util.Properties;
import java.util.Set;
import org.openqa.selenium.By;
import org.openqa.selenium.Cookie;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import test.java.stepdefs.com.cvshealth.digital.library.ExecutionContext;

public class OperationsDesktop {

	/*
	 * =============================================================================
	 * ============== Function Name: navigateURL CREATED BY: ACOE Team CREATED DATE:
	 * 05/03/2019 DESCRIPTION: This method is used to navigate specified URL
	 * Parameter: Object of class ExecutionContext RETURNS: Nothing COMMENTS:
	 * Modification Log: Revision: 1.0 Date: 05/03/2019 Comment: Implemented method
	 * with initial requirement
	 * 
	 * =============================================================================
	 * ==============
	 */
	/**
	 * <p style="font-family:Arial;">
	 * <b>DESCRIPTION: This method is used to navigate specified URL <br>
	 * <br>
	 * Author: - ACOE Team <br>
	 * <br>
	 * Date Created: 05/03/2019 <br>
	 * <br>
	 * Revision History: <br>
	 * 1.0: Define method and added initial code <br>
	 * 
	 * @param Object
	 *            of class ExecutionContext
	 * @return No Return Value
	 * @throws Exception
	 *             If any error occurs, reports the exception message and log the
	 *             full exception trace in log file </b>
	 *             </P>
	 * 
	 */
	public static boolean navigateURL(ExecutionContext executionContext) {
		String expectedResult = "";
		String actualResult = "";
		boolean status = false;
		try {
			Log.writeToLogFile("Executing menthod navigateURL....");
			String URL = executionContext.getCurrentElementData();
			expectedResult = "URL '" + URL + "' should be navigated";
			executionContext.getDriver().get(URL);
			wait_Page_Load(executionContext);
			Cookie cookie = new Cookie("selenium_cookie", "true");
			executionContext.getDriver().manage().addCookie(cookie);
			actualResult = "URL '" + URL + "' is navigated";
			status = true;
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
			actualResult = actualResult + e.getMessage();
		}
		ReportUtility.reportStepStatus(executionContext, expectedResult, actualResult, status);
		return status;
	}

	/*
	 * =============================================================================
	 * ============== Function Name: wait_Page_Load CREATED BY: ACOE Team CREATED
	 * DATE: 05/03/2019 DESCRIPTION: This method is used wait until page is not
	 * loaded Parameter: Object of class ExecutionContext RETURNS: Nothing COMMENTS:
	 * Modification Log: Revision: 1.0 Date: 05/03/2019 Comment: Implemented method
	 * with initial requirement
	 * 
	 * =============================================================================
	 * ==============
	 */
	/**
	 * <p style="font-family:Arial;">
	 * <b>DESCRIPTION: This method is used wait until page is not loaded <br>
	 * <br>
	 * Author: - ACOE Team <br>
	 * <br>
	 * Date Created: 05/03/2019 <br>
	 * <br>
	 * Revision History: <br>
	 * 1.0: Define method and added initial code <br>
	 * 
	 * @param Object
	 *            of class ExecutionContext
	 * @return No Return Value
	 * @throws Exception
	 *             If any error occurs, reports the exception message and log the
	 *             full exception trace in log file </b>
	 *             </P>
	 * 
	 */
	public static boolean wait_Page_Load(ExecutionContext executionContext) {
		String expectedResult = "Wait page load should be performed";
		String actualResult = "Wait page load is not performed";
		boolean status = false;
		try {
			@SuppressWarnings("unused")
			ExpectedCondition<Boolean> expectation = new ExpectedCondition<Boolean>() {
				public Boolean apply(WebDriver driver) {
					return ((JavascriptExecutor) executionContext.getDriver())
							.executeScript("return document.readyState").toString().equals("complete");
				}
			};

			WebDriverWait wait = new WebDriverWait(executionContext.getDriver(), 60);	//Make the wait time configurable, environment specific - environment.properties
			wait.until((ExpectedCondition<Boolean>) d -> ((JavascriptExecutor) executionContext.getDriver())
					.executeScript("return document.readyState").equals("complete"));
			actualResult = "Wait page load is performed";
			status = true;

		} catch (Exception e) {
			ExceptionHandler.handleException(e);
			actualResult = actualResult + e.getMessage();
		}
		ReportUtility.reportStepStatus(executionContext, expectedResult, actualResult, status);
		return status;
				
	}

	/*
	 * =============================================================================
	 * ============== Function Name: click CREATED BY: ACOE Team CREATED DATE:
	 * 05/03/2019 DESCRIPTION: This method is used click specified object Parameter:
	 * Object of class ExecutionContext RETURNS: Nothing COMMENTS: Modification Log:
	 * Revision: 1.0 Date: 05/03/2019 Comment: Implemented method with initial
	 * requirement
	 * 
	 * =============================================================================
	 * ==============
	 */
	/**
	 * <p style="font-family:Arial;">
	 * <b>DESCRIPTION: This method is used click specified object <br>
	 * <br>
	 * Author: - ACOE Team <br>
	 * <br>
	 * Date Created: 05/03/2019 <br>
	 * <br>
	 * Revision History: <br>
	 * 1.0: Define method and added initial code <br>
	 * 
	 * @param Object
	 *            of class ExecutionContext
	 * @return No Return Value
	 * @throws Exception
	 *             If any error occurs, reports the exception message and log the
	 *             full exception trace in log file </b>
	 *             </P>
	 * 
	 */
	public static boolean click(ExecutionContext executionContext) {
		String expectedResult = "Object should be clicked";
		String actualResult = "Object is not clicked";
		boolean status = false;
		try {
			String objectXPath = executionContext.getCurrentElementXPath();
			String data = executionContext.getCurrentElementData();
			if (data == null || data.equalsIgnoreCase("")) {

			} else {
				objectXPath = objectXPath.replaceAll("####", data);
			}
			expectedResult = "Locator '" + objectXPath + "' should be clicked";
			List<WebElement> elements = findElements(executionContext.getDriver(), objectXPath);
			if (!(elements == null || elements.size() <= 0)) {
				elements.get(0).click();
				status = true;
				actualResult = "Locator '" + objectXPath + "' is clicked";
			} else {
				actualResult = "Locator '" + objectXPath + "' is not clicked. Element could not be found with xPath '"
						+ objectXPath + "'";
			}
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
			actualResult = actualResult + ". " + e.getMessage();
		}
		ReportUtility.reportStepStatus(executionContext, expectedResult, actualResult, status);
		return status;
				
	}

	/*
	 * =============================================================================
	 * ============== Function Name: click_Last_Object CREATED BY: ACOE Team CREATED
	 * DATE: 05/03/2019 DESCRIPTION: This method is used to click last displayed
	 * object Parameter: Object of class ExecutionContext RETURNS: Nothing COMMENTS:
	 * Modification Log: Revision: 1.0 Date: 05/03/2019 Comment: Implemented method
	 * with initial requirement
	 * 
	 * =============================================================================
	 * ==============
	 */
	/**
	 * <p style="font-family:Arial;">
	 * <b>DESCRIPTION: This method is used to click last displayed object <br>
	 * <br>
	 * Author: - ACOE Team <br>
	 * <br>
	 * Date Created: 05/03/2019 <br>
	 * <br>
	 * Revision History: <br>
	 * 1.0: Define method and added initial code <br>
	 * 
	 * @param Object
	 *            of class ExecutionContext
	 * @return No Return Value
	 * @throws Exception
	 *             If any error occurs, reports the exception message and log the
	 *             full exception trace in log file </b>
	 *             </P>
	 * 
	 */
	public static boolean click_Last_Object(ExecutionContext executionContext) {
		String expectedResult = "Last object should be clicked";
		String actualResult = "Last object is not clicked";
		boolean status = false;
		try {
			String objectXPath = executionContext.getCurrentElementXPath();
			String data = executionContext.getCurrentElementData();
			if (data == null || data.equalsIgnoreCase("")) {

			} else {
				objectXPath = objectXPath.replaceAll("####", data);
			}
			expectedResult = "Last object with lLocator '" + objectXPath + "' should be clicked";
			List<WebElement> elements = findElements(executionContext.getDriver(), objectXPath);
			if (!(elements == null || elements.size() <= 0)) {
				int lastObjectIndex = elements.size() - 1;
				elements.get(lastObjectIndex).click();
			} else {
				actualResult = "Last object with locator '" + objectXPath
						+ "' is not clicked. Element could not be found with xPath '" + objectXPath + "'";
			}
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
			actualResult = actualResult + ". " + e.getMessage();
		}
		ReportUtility.reportStepStatus(executionContext, expectedResult, actualResult, status);
		return status;
				
	}

	/*
	 * =============================================================================
	 * ============== Function Name: click_First_Object CREATED BY: ACOE Team
	 * CREATED DATE: 05/03/2019 DESCRIPTION: This method is used to click first
	 * displayed object Parameter: Object of class ExecutionContext RETURNS: Nothing
	 * COMMENTS: Modification Log: Revision: 1.0 Date: 05/03/2019 Comment:
	 * Implemented method with initial requirement
	 * 
	 * =============================================================================
	 * ==============
	 */
	/**
	 * <p style="font-family:Arial;">
	 * <b>DESCRIPTION: This method is used to click first displayed object <br>
	 * <br>
	 * Author: - ACOE Team <br>
	 * <br>
	 * Date Created: 05/03/2019 <br>
	 * <br>
	 * Revision History: <br>
	 * 1.0: Define method and added initial code <br>
	 * 
	 * @param Object
	 *            of class ExecutionContext
	 * @return No Return Value
	 * @throws Exception
	 *             If any error occurs, reports the exception message and log the
	 *             full exception trace in log file </b>
	 *             </P>
	 * 
	 */
	public static boolean click_First_Object(ExecutionContext executionContext) {
		String expectedResult = "First clickable object should be clicked";
		String actualResult = "Object is not clicked";
		boolean status = false;
		try {
			String objectXPath = executionContext.getCurrentElementXPath();
			String data = executionContext.getCurrentElementData();
			if (data == null || data.equalsIgnoreCase("")) {

			} else {
				objectXPath = objectXPath.replaceAll("####", data);
			}
			expectedResult = "First clickable with locator '" + objectXPath + "' should be clicked";
			List<WebElement> elements = findElements(executionContext.getDriver(), objectXPath);
			if (!(elements == null || elements.size() <= 0)) {
				for (WebElement w : elements) {
					try {
						w.click();
						status = true;
						actualResult = "First clickable with locator '" + objectXPath + "' is clicked";
					} catch (Exception e) {
					}
				}

			} else {
				actualResult = "Object with locator '" + objectXPath
						+ "' is not clicked. Element could not be found with xPath '" + objectXPath + "'";
			}
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
			actualResult = actualResult + ". " + e.getMessage();
		}
		ReportUtility.reportStepStatus(executionContext, expectedResult, actualResult, status);return status;
				
	}

	/*
	 * =============================================================================
	 * ============== Function Name: click_Object_If_Exist CREATED BY: ACOE Team
	 * CREATED DATE: 05/03/2019 DESCRIPTION: This method is used click if specified
	 * object found Parameter: Object of class ExecutionContext RETURNS: Nothing
	 * COMMENTS: Modification Log: Revision: 1.0 Date: 05/03/2019 Comment:
	 * Implemented method with initial requirement
	 * 
	 * =============================================================================
	 * ==============
	 */
	/**
	 * <p style="font-family:Arial;">
	 * <b>DESCRIPTION: This method is used click if specified object found <br>
	 * <br>
	 * Author: - ACOE Team <br>
	 * <br>
	 * Date Created: 05/03/2019 <br>
	 * <br>
	 * Revision History: <br>
	 * 1.0: Define method and added initial code <br>
	 * 
	 * @param Object
	 *            of class ExecutionContext
	 * @return No Return Value
	 * @throws Exception
	 *             If any error occurs, reports the exception message and log the
	 *             full exception trace in log file </b>
	 *             </P>
	 * 
	 */
	public static boolean click_Object_If_Exist(ExecutionContext executionContext) {
		String expectedResult = "Object should be clicked if exist";
		String actualResult = "Object is not clicked";
		boolean status = false;
		try {
			String objectXPath = executionContext.getCurrentElementXPath();
			String data = executionContext.getCurrentElementData();
			if (data == null || data.equalsIgnoreCase("")) {

			} else {
				objectXPath = objectXPath.replaceAll("####", data);
			}
			expectedResult = "Object with locator '" + objectXPath + "' should be clicked if exist";
			List<WebElement> elements = findElements(executionContext.getDriver(), objectXPath);
			if (!(elements == null || elements.size() <= 0)) {
				elements.get(0).click();
				status = true;
				actualResult = "Object with locator '" + objectXPath + "' is clicked";
			} else {
				status = true;
				actualResult = "Object with locator '" + objectXPath
						+ "' is not clicked as no object found with xPath '" + objectXPath + "'";
			}
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
			actualResult = actualResult + ". " + e.getMessage();
		}
		ReportUtility.reportStepStatus(executionContext, expectedResult, actualResult, status);return status;
				
	}

	/*
	 * =============================================================================
	 * ============== Function Name: click_NonAngular CREATED BY: ACOE Team CREATED
	 * DATE: 05/03/2019 DESCRIPTION: This method is used click specified object
	 * Parameter: Object of class ExecutionContext RETURNS: Nothing COMMENTS:
	 * Modification Log: Revision: 1.0 Date: 05/03/2019 Comment: Implemented method
	 * with initial requirement
	 * 
	 * =============================================================================
	 * ==============
	 */
	/**
	 * <p style="font-family:Arial;">
	 * <b>DESCRIPTION: This method is used click specified object <br>
	 * <br>
	 * Author: - ACOE Team <br>
	 * <br>
	 * Date Created: 05/03/2019 <br>
	 * <br>
	 * Revision History: <br>
	 * 1.0: Define method and added initial code <br>
	 * 
	 * @param Object
	 *            of class ExecutionContext
	 * @return No Return Value
	 * @throws Exception
	 *             If any error occurs, reports the exception message and log the
	 *             full exception trace in log file </b>
	 *             </P>
	 * 
	 */
	public static boolean click_NonAngular(ExecutionContext executionContext) {
		String expectedResult = "Object should be clicked";
		String actualResult = "Object is not clicked";
		boolean status = false;
		try {
			String objectXPath = executionContext.getCurrentElementXPath();
			String data = executionContext.getCurrentElementData();
			if (data == null || data.equalsIgnoreCase("")) {

			} else {
				objectXPath = objectXPath.replaceAll("####", data);
			}
			expectedResult = "Locator '" + objectXPath + "' should be clicked";
			List<WebElement> elements = findElements(executionContext.getDriver(), objectXPath);
			if (!(elements == null || elements.size() <= 0)) {
				JavascriptExecutor js = (JavascriptExecutor) executionContext.getDriver();
				js.executeScript("document.evaluate(\"" + objectXPath
						+ "\", document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue.click();",
						"");
				actualResult = "Locator '" + objectXPath + "' is clicked";
				status = true;
			} else {
				actualResult = "Locator '" + objectXPath + "' is not clicked. Element could not be found with xPath '"
						+ objectXPath + "'";
			}
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
			actualResult = actualResult + ". " + e.getMessage();
		}
		ReportUtility.reportStepStatus(executionContext, expectedResult, actualResult, status);return status;
				
	}

	/*
	 * =============================================================================
	 * ============== Function Name: input CREATED BY: ACOE Team CREATED DATE:
	 * 05/03/2019 DESCRIPTION: This method is used input data in specified object
	 * Parameter: Object of class ExecutionContext RETURNS: Nothing COMMENTS:
	 * Modification Log: Revision: 1.0 Date: 05/03/2019 Comment: Implemented method
	 * with initial requirement
	 * 
	 * =============================================================================
	 * ==============
	 */
	/**
	 * <p style="font-family:Arial;">
	 * <b>DESCRIPTION: This method is used input data in specified object <br>
	 * <br>
	 * Author: - ACOE Team <br>
	 * <br>
	 * Date Created: 05/03/2019 <br>
	 * <br>
	 * Revision History: <br>
	 * 1.0: Define method and added initial code <br>
	 * 
	 * @param Object
	 *            of class ExecutionContext
	 * @return No Return Value
	 * @throws Exception
	 *             If any error occurs, reports the exception message and log the
	 *             full exception trace in log file </b>
	 *             </P>
	 * 
	 */
	public static boolean input(ExecutionContext executionContext) {
		String expectedResult = "Data should be inputted in the object";
		String actualResult = "Data is not inputted in the object";
		boolean status = false;
		try {
			String objectXPath = executionContext.getCurrentElementXPath();
			String data = executionContext.getCurrentElementData();
			expectedResult = "Data " + data + " should be inputted in object with locator '" + objectXPath + "'";
			actualResult = "Data " + data + " is not inputted in object with locator '" + objectXPath + "'";
			List<WebElement> elements = findElements(executionContext.getDriver(), objectXPath);
			if (!(elements == null || elements.size() <= 0)) {
				elements.get(0).clear();
				Thread.sleep(2000);
				elements.get(0).sendKeys(data);
				Thread.sleep(2000);
				String data1 = elements.get(0).getAttribute("value");
				if (data1 == null || data1.equalsIgnoreCase("") || (!data1.equalsIgnoreCase(data))) {
					elements.get(0).clear();
					elements.get(0).sendKeys(data);
				}
				actualResult = "Data " + data + " is inputted in object with locator '" + objectXPath + "'.";
				status = true;
			} else {
				actualResult = "Data " + data + " is not inputted in object with locator '" + objectXPath
						+ "'. Element could not be found with xPath '" + objectXPath + "'";
			}
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
			actualResult = actualResult + ". " + e.getMessage();
		}
		ReportUtility.reportStepStatus(executionContext, expectedResult, actualResult, status);return status;
				
	}

	/*
	 * =============================================================================
	 * ============== Function Name: input_NonAngular CREATED BY: ACOE Team CREATED
	 * DATE: 05/03/2019 DESCRIPTION: This method is used input data in specified
	 * object Parameter: Object of class ExecutionContext RETURNS: Nothing COMMENTS:
	 * Modification Log: Revision: 1.0 Date: 05/03/2019 Comment: Implemented method
	 * with initial requirement
	 * 
	 * =============================================================================
	 * ==============
	 */
	/**
	 * <p style="font-family:Arial;">
	 * <b>DESCRIPTION: This method is used input data in specified object <br>
	 * <br>
	 * Author: - ACOE Team <br>
	 * <br>
	 * Date Created: 05/03/2019 <br>
	 * <br>
	 * Revision History: <br>
	 * 1.0: Define method and added initial code <br>
	 * 
	 * @param Object
	 *            of class ExecutionContext
	 * @return No Return Value
	 * @throws Exception
	 *             If any error occurs, reports the exception message and log the
	 *             full exception trace in log file </b>
	 *             </P>
	 * 
	 */
	public static boolean input_NonAngular(ExecutionContext executionContext) {
		String expectedResult = "Data should be inputted in the object";
		String actualResult = "Data is not inputted in the object";
		boolean status = false;
		try {
			String objectXPath = executionContext.getCurrentElementXPath();
			String data = executionContext.getCurrentElementData();
			expectedResult = "Locator '" + objectXPath + "' should be clicked";
			List<WebElement> elements = findElements(executionContext.getDriver(), objectXPath);
			if (!(elements == null || elements.size() <= 0)) {
				JavascriptExecutor js = (JavascriptExecutor) executionContext.getDriver();
				js.executeScript("document.evaluate(\"" + objectXPath
						+ "\", document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue.value=\""
						+ data + "\";", "");
				actualResult = "Data " + data + " is inputted in object with locator '" + objectXPath + "'.";
				status = true;
			} else {
				actualResult = "Data " + data + " is not inputted in object with locator '" + objectXPath
						+ "'. Element could not be found with xPath '" + objectXPath + "'";
			}
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
			actualResult = actualResult + ". " + e.getMessage();
		}
		ReportUtility.reportStepStatus(executionContext, expectedResult, actualResult, status);return status;
				
	}

	/*
	 * =============================================================================
	 * ============== Function Name: input_If_Exist CREATED BY: ACOE Team CREATED
	 * DATE: 05/03/2019 DESCRIPTION: This method is used to input data if object
	 * with specified locator is exist Parameter: Object of class ExecutionContext
	 * RETURNS: Nothing COMMENTS: Modification Log: Revision: 1.0 Date: 05/03/2019
	 * Comment: Implemented method with initial requirement
	 * 
	 * =============================================================================
	 * ==============
	 */
	/**
	 * <p style="font-family:Arial;">
	 * <b>DESCRIPTION: This method is used to input data if object with specified
	 * locator is exist <br>
	 * <br>
	 * Author: - ACOE Team <br>
	 * <br>
	 * Date Created: 05/03/2019 <br>
	 * <br>
	 * Revision History: <br>
	 * 1.0: Define method and added initial code <br>
	 * 
	 * @param Object
	 *            of class ExecutionContext
	 * @return No Return Value
	 * @throws Exception
	 *             If any error occurs, reports the exception message and log the
	 *             full exception trace in log file </b>
	 *             </P>
	 * 
	 */
	public static boolean input_If_Exist(ExecutionContext executionContext) {
		String objectXPath = executionContext.getCurrentElementXPath();
		String data = executionContext.getCurrentElementData();
		String actualResult = "Object with locator " + objectXPath + " is not found";
		String expectedResult = "Data " + data + " should be inputted in object with locator " + objectXPath
				+ " if it is found";
		boolean status = false;
		try {
			List<WebElement> elements = findElements(executionContext.getDriver(), objectXPath);
			if (elements != null && elements.size() > 0) {
				if (data == null || data.equalsIgnoreCase("")) {
					actualResult = "No data specified, data is required to input in object with locator "
							+ objectXPath;
				} else {
					try {
						elements.get(0).sendKeys(data);
						status = true;
					} catch (Exception e) {
					}
					if (status) {
						actualResult = "Data " + data + " is inputted in object with locator " + objectXPath;
					}
				}

			} else {
				actualResult = "Data " + data + " is not inputted in object with locator " + objectXPath
						+ " as no object is found";
				status = true;
			}

		} catch (Exception e) {
			ExceptionHandler.handleException(e);
			actualResult = actualResult + ". " + e.getMessage();
		}
		ReportUtility.reportStepStatus(executionContext, expectedResult, actualResult, status);return status;
				

	}

	/*
	 * =============================================================================
	 * ============== Function Name: clear_Textbox CREATED BY: ACOE Team CREATED
	 * DATE: 05/03/2019 DESCRIPTION: This method is used clear textbox Parameter:
	 * Object of class ExecutionContext RETURNS: Nothing COMMENTS: Modification Log:
	 * Revision: 1.0 Date: 05/03/2019 Comment: Implemented method with initial
	 * requirement
	 * 
	 * =============================================================================
	 * ==============
	 */
	/**
	 * <p style="font-family:Arial;">
	 * <b>DESCRIPTION: This method is used clear textbox <br>
	 * <br>
	 * Author: - ACOE Team <br>
	 * <br>
	 * Date Created: 05/03/2019 <br>
	 * <br>
	 * Revision History: <br>
	 * 1.0: Define method and added initial code <br>
	 * 
	 * @param Object
	 *            of class ExecutionContext
	 * @return No Return Value
	 * @throws Exception
	 *             If any error occurs, reports the exception message and log the
	 *             full exception trace in log file </b>
	 *             </P>
	 * 
	 */
	public static boolean clear_Textbox(ExecutionContext executionContext) {
		String objectXPath = executionContext.getCurrentElementXPath();
		String actualResult = "Textbox with object locator " + objectXPath + " is not found";
		String expectedResult = "Textbox with object locator " + objectXPath + " should be cleared";
		boolean status = false;
		try {
			List<WebElement> elements = findElements(executionContext.getDriver(), objectXPath);
			if (elements != null && elements.size() > 0) {
				elements.get(0).clear();
				elements.get(0).sendKeys("");
				actualResult = "Textbox with object locator " + objectXPath + " is cleared";
				status = true;
			}

		} catch (Exception e) {
			ExceptionHandler.handleException(e);
			actualResult = actualResult + ". " + e.getMessage();
		}
		ReportUtility.reportStepStatus(executionContext, expectedResult, actualResult, status);return status;
				

	}

	/*
	 * =============================================================================
	 * ============== Function Name: mouse_Hover CREATED BY: ACOE Team CREATED DATE:
	 * 05/03/2019 DESCRIPTION: This method is used move mouse at specified locator
	 * Parameter: Object of class ExecutionContext RETURNS: Nothing COMMENTS:
	 * Modification Log: Revision: 1.0 Date: 05/03/2019 Comment: Implemented method
	 * with initial requirement
	 * 
	 * =============================================================================
	 * ==============
	 */
	/**
	 * <p style="font-family:Arial;">
	 * <b>DESCRIPTION: This method is used move mouse at specified locator <br>
	 * <br>
	 * Author: - ACOE Team <br>
	 * <br>
	 * Date Created: 05/03/2019 <br>
	 * <br>
	 * Revision History: <br>
	 * 1.0: Define method and added initial code <br>
	 * 
	 * @param Object
	 *            of class ExecutionContext
	 * @return No Return Value
	 * @throws Exception
	 *             If any error occurs, reports the exception message and log the
	 *             full exception trace in log file </b>
	 *             </P>
	 * 
	 */
	public static boolean mouse_Hover(ExecutionContext executionContext) {
		String expectedResult = "Mouse should be moved to specified object";
		String actualResult = "Mouse is not moved to specified object";
		boolean status = false;
		try {
			String objectXPath = executionContext.getCurrentElementXPath();
			expectedResult = "Mouse should be moved to the object with locator '" + objectXPath + "'";
			List<WebElement> elements = findElements(executionContext.getDriver(), objectXPath);
			if (!(elements == null || elements.size() <= 0)) {
				Actions builder = new Actions(executionContext.getDriver());
				WebElement we = elements.get(0);
				builder.moveToElement(we).build().perform();
				Thread.sleep(2000);
				status = true;
				actualResult = "Mouse should be moved to the object with locator '" + objectXPath + "'";
			} else {
				actualResult = "Mouse is not moved to the object with locator '" + objectXPath
						+ "'. Element could not be found with xPath '" + objectXPath + "'";
			}
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
			actualResult = actualResult + ". " + e.getMessage();
		}
		ReportUtility.reportStepStatus(executionContext, expectedResult, actualResult, status);return status;
				
	}

	/*
	 * =============================================================================
	 * ============== Function Name: exist CREATED BY: ACOE Team CREATED DATE:
	 * 05/03/2019 DESCRIPTION: This method is used validate object with specified
	 * locator is found Parameter: Object of class ExecutionContext RETURNS: Nothing
	 * COMMENTS: Modification Log: Revision: 1.0 Date: 05/03/2019 Comment:
	 * Implemented method with initial requirement
	 * 
	 * =============================================================================
	 * ==============
	 */
	/**
	 * <p style="font-family:Arial;">
	 * <b>DESCRIPTION: This method is used validate object with specified locator is
	 * found <br>
	 * <br>
	 * Author: - ACOE Team <br>
	 * <br>
	 * Date Created: 05/03/2019 <br>
	 * <br>
	 * Revision History: <br>
	 * 1.0: Define method and added initial code <br>
	 * 
	 * @param Object
	 *            of class ExecutionContext
	 * @return No Return Value
	 * @throws Exception
	 *             If any error occurs, reports the exception message and log the
	 *             full exception trace in log file </b>
	 *             </P>
	 * 
	 */
	public static boolean exist(ExecutionContext executionContext) {
		String expectedResult = "Object with specified locator should be found and displayed";
		String actualResult = "Object with specified locator is not found";
		boolean status = false;
		try {
			String objectXPath = executionContext.getCurrentElementXPath();
			expectedResult = "Object with locator " + objectXPath + " should be found and displayed";
			actualResult = "Object with locator " + objectXPath + " is not found";
			List<WebElement> elements = findElements(executionContext.getDriver(), objectXPath);
			if (!(elements == null || elements.size() <= 0)) {
				if (elements.get(0).isDisplayed()) {
					actualResult = "Object with locator " + objectXPath + " is found and displayed";
					status = true;
				} else {
					actualResult = "Object with locator " + objectXPath + " is found, but not displayed";
				}
			}
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
			actualResult = actualResult + ". " + e.getMessage();
		}
		ReportUtility.reportStepStatus(executionContext, expectedResult, actualResult, status);
				
		return status;
	}

	/*
	 * =============================================================================
	 * ============== Function Name: not_Exist CREATED BY: ACOE Team CREATED DATE:
	 * 05/03/2019 DESCRIPTION: This method is used validate object with specified
	 * locator is not exist Parameter: Object of class ExecutionContext RETURNS:
	 * Nothing COMMENTS: Modification Log: Revision: 1.0 Date: 05/03/2019 Comment:
	 * Implemented method with initial requirement
	 * 
	 * =============================================================================
	 * ==============
	 */
	/**
	 * <p style="font-family:Arial;">
	 * <b>DESCRIPTION: This method is used validate object with specified locator is
	 * not exist <br>
	 * <br>
	 * Author: - ACOE Team <br>
	 * <br>
	 * Date Created: 05/03/2019 <br>
	 * <br>
	 * Revision History: <br>
	 * 1.0: Define method and added initial code <br>
	 * 
	 * @param Object
	 *            of class ExecutionContext
	 * @return No Return Value
	 * @throws Exception
	 *             If any error occurs, reports the exception message and log the
	 *             full exception trace in log file </b>
	 *             </P>
	 * 
	 */
	public static boolean not_Exist(ExecutionContext executionContext) {
		String expectedResult = "Object with specified locator should not be found and displayed";
		String actualResult = "Object with specified locator is found";
		boolean status = false;
		try {
			String objectXPath = executionContext.getCurrentElementXPath();
			expectedResult = "Object with locator " + objectXPath + " should not be found and displayed";
			actualResult = "Object with locator " + objectXPath + " is not found";
			List<WebElement> elements = findElements(executionContext.getDriver(), objectXPath);
			if (!(elements == null || elements.size() <= 0)) {
				if (elements.get(0).isDisplayed()) {
					actualResult = "Object with locator " + objectXPath + " is found and displayed";

				} else {
					actualResult = "Object with locator " + objectXPath + " is found, but not displayed";
					status = true;
				}
			} else {
				actualResult = "Object with locator " + objectXPath + " is not found";
				status = true;
			}
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
			actualResult = actualResult + ". " + e.getMessage();
		}
		ReportUtility.reportStepStatus(executionContext, expectedResult, actualResult, status);return status;
				
	}

	/*
	 * =============================================================================
	 * ============== Function Name: findElements CREATED BY: ACOE Team CREATED
	 * DATE: 05/03/2019 DESCRIPTION: This method is used find list of object with
	 * specified locator Parameter: Object of class ExecutionContext RETURNS:
	 * Nothing COMMENTS: Modification Log: Revision: 1.0 Date: 05/03/2019 Comment:
	 * Implemented method with initial requirement
	 * 
	 * =============================================================================
	 * ==============
	 */
	/**
	 * <p style="font-family:Arial;">
	 * <b>DESCRIPTION: This method is used find list of object with specified
	 * locator <br>
	 * <br>
	 * Author: - ACOE Team <br>
	 * <br>
	 * Date Created: 05/03/2019 <br>
	 * <br>
	 * Revision History: <br>
	 * 1.0: Define method and added initial code <br>
	 * 
	 * @param Object
	 *            of class ExecutionContext
	 * @return No Return Value
	 * @throws Exception
	 *             If any error occurs, reports the exception message and log the
	 *             full exception trace in log file </b>
	 *             </P>
	 * 
	 */
	public static List<WebElement> findElements(WebDriver driver, String xPath) {
		List<WebElement> elements = new ArrayList<WebElement>();
		try {
			Log.writeToLogFile("XPath: " + xPath);
			elements = driver.findElements(By.xpath(xPath));
			Log.writeToLogFile("Number of objects: " + elements.size());
			int i = 0;
			while (i < 0 && (elements == null || elements.size() == 0)) {
				Log.writeToLogFile("Trying to find element in " + (i + 2) + " try...");
				elements = driver.findElements(By.xpath(xPath));
				try {
					Thread.sleep(1000);
				} catch (Exception e) {
				}
				i++;
			}
			Log.writeToLogFile("Number of objects: " + elements.size());

		} catch (Exception e) {
			ExceptionHandler.handleException(e);
		}

		return elements;
	}

	/*
	 * =============================================================================
	 * ============== Function Name: wait_For_Object CREATED BY: ACOE Team CREATED
	 * DATE: 05/03/2019 DESCRIPTION: This method is used to wait until object is not
	 * displayed or maximum wait time is reached Parameter: Object of class
	 * ExecutionContext RETURNS: Nothing COMMENTS: Modification Log: Revision: 1.0
	 * Date: 05/03/2019 Comment: Implemented method with initial requirement
	 * 
	 * =============================================================================
	 * ==============
	 */
	/**
	 * <p style="font-family:Arial;">
	 * <b>DESCRIPTION: This method is used to wait until object is not displayed or
	 * maximum wait time is reached <br>
	 * <br>
	 * Author: - ACOE Team <br>
	 * <br>
	 * Date Created: 05/03/2019 <br>
	 * <br>
	 * Revision History: <br>
	 * 1.0: Define method and added initial code <br>
	 * 
	 * @param Object
	 *            of class ExecutionContext
	 * @return No Return Value
	 * @throws Exception
	 *             If any error occurs, reports the exception message and log the
	 *             full exception trace in log file </b>
	 *             </P>
	 * 
	 */
	public static boolean wait_For_Object(ExecutionContext executionContext) {

		String expectedResult = "Object with specified locator should be found";
		String actualResult = "Object with specified locator is not found";
		boolean status = false;
		int waittime;
		try {

			String objectXPath = executionContext.getCurrentElementXPath();

			expectedResult = "Object with locator " + objectXPath + " should be found";
			actualResult = "Object with locator " + objectXPath + " is not found";

			//assigning wait time from environment.properties' WAIT_TIME_SEOCNDS property
			waittime = PropertyFileLoader.getInstance().getWAIT_TIME_SEOCNDS();

			//assigning standard wait time of 30 seconds in case no value fetched from environment.properties
			if (waittime == 0)
				waittime = 30;
			
			//converting wait time from seconds to miliseconds
			waittime=waittime*1000;
			
			Date date = new Date();
			long startTime = date.getTime();
			long endTime = date.getTime();
			List<WebElement> elements;
			int i = 1;
			try {
				Thread.sleep(2000);
			} catch (Exception e) {
			}
			while ((endTime - startTime) < waittime) {
				Log.writeToLogFile("trying to find element in " + i++);
				if (i > 2) {

				}
				elements = findElements(executionContext.getDriver(), objectXPath);
				if (elements != null && elements.size() > 0) {
					actualResult = "Object with locator " + objectXPath + " is found";
					status = true;
					break;
				}
				try {
					Thread.sleep(2000);
				} catch (Exception e) {
				}
				endTime = new Date().getTime();
			}

		} catch (Exception e) {
			ExceptionHandler.handleException(e);
			actualResult = actualResult + ". " + e.getMessage();
		}
		ReportUtility.reportStepStatus(executionContext, expectedResult, actualResult, status);
		return status;

	}

	/*
	 * =============================================================================
	 * ============== Function Name: validate_Object_Text CREATED BY: ACOE Team
	 * CREATED DATE: 05/03/2019 DESCRIPTION: This method is used to validate object
	 * text is blank Parameter: Object of class ExecutionContext RETURNS: Nothing
	 * COMMENTS: Modification Log: Revision: 1.0 Date: 05/03/2019 Comment:
	 * Implemented method with initial requirement
	 * 
	 * =============================================================================
	 * ==============
	 */
	/**
	 * <p style="font-family:Arial;">
	 * <b>DESCRIPTION: This method is used to validate object text is blank <br>
	 * <br>
	 * Author: - ACOE Team <br>
	 * <br>
	 * Date Created: 05/03/2019 <br>
	 * <br>
	 * Revision History: <br>
	 * 1.0: Define method and added initial code <br>
	 * 
	 * @param Object
	 *            of class ExecutionContext
	 * @return No Return Value
	 * @throws Exception
	 *             If any error occurs, reports the exception message and log the
	 *             full exception trace in log file </b>
	 *             </P>
	 * 
	 */
	public static boolean validate_Object_Text(ExecutionContext executionContext) {
		String actualResult = "Specified Object is not found";
		String expectedResult = "Specified object text should be validated with expected text";
		boolean status = false;
		try {
			String objectXPath = executionContext.getCurrentElementXPath();
			String data = executionContext.getCurrentElementData();
			List<WebElement> elements = findElements(executionContext.getDriver(), objectXPath);
			if (elements != null && elements.size() > 0) {
				if (!(data == null || data.equalsIgnoreCase(""))) {
					String actualText = elements.get(0).getText();
					if (actualText != null) {
						if (actualText.equalsIgnoreCase(data)) {
							actualResult = "Object with locator " + objectXPath + " actual text " + actualText
									+ " is validated successfully with expected text " + data + "";							
							status = true;
						} else {
							if (actualText.toLowerCase().contains(data.toLowerCase())) {
								actualResult = "Object with locator " + objectXPath + " actual text " + actualText
										+ " is validated successfully with expected text " + data + "";
								status = true;
							} else {
								actualResult = "Object with locator " + objectXPath + " actual text " + actualText
										+ " is not validated successfully with expected text " + data + "";
							}
						}
					} else {
						actualResult = "Object with locator " + objectXPath + " text is null";
					}
				}
				else{
					actualResult = "No data is provided, data is required to perform this operation";
				}
			} else {
				actualResult = "Object with locator " + objectXPath + " is not found";
			}

		} catch (Exception e) {
			ExceptionHandler.handleException(e);
			actualResult = actualResult + ". " + e.getMessage();
		}
		ReportUtility.reportStepStatus(executionContext, expectedResult, actualResult, status);return status;
				

	}

	/*
	 * =============================================================================
	 * ============== Function Name: validate_Object_Text_Is_Blank CREATED BY: ACOE
	 * Team CREATED DATE: 05/03/2019 DESCRIPTION: This method is used validate
	 * object text is blank Parameter: Object of class ExecutionContext RETURNS:
	 * Nothing COMMENTS: Modification Log: Revision: 1.0 Date: 05/03/2019 Comment:
	 * Implemented method with initial requirement
	 * 
	 * =============================================================================
	 * ==============
	 */
	/**
	 * <p style="font-family:Arial;">
	 * <b>DESCRIPTION: This method is used validate object text is blank <br>
	 * <br>
	 * Author: - ACOE Team <br>
	 * <br>
	 * Date Created: 05/03/2019 <br>
	 * <br>
	 * Revision History: <br>
	 * 1.0: Define method and added initial code <br>
	 * 
	 * @param Object
	 *            of class ExecutionContext
	 * @return No Return Value
	 * @throws Exception
	 *             If any error occurs, reports the exception message and log the
	 *             full exception trace in log file </b>
	 *             </P>
	 * 
	 */
	public static boolean validate_Object_Text_Is_Blank(ExecutionContext executionContext) {
		String objectXPath = executionContext.getCurrentElementXPath();
		String actualResult = "Object with locator " + objectXPath + " is not found";
		String expectedResult = "Object text with locator " + objectXPath + " should be blank";
		boolean status = false;
		try {
			List<WebElement> elements = findElements(executionContext.getDriver(), objectXPath);
			if (elements != null && elements.size() > 0) {
				String actualText = elements.get(0).getText();
				if (!(actualText == null || actualText.equalsIgnoreCase(""))) {
					actualResult = "Object text with locator " + objectXPath + " is not blank";
				} else {
					actualResult = "Object text with locator " + objectXPath + " is blank";
					status = true;
				}
			}

		} catch (Exception e) {
			ExceptionHandler.handleException(e);
			actualResult = actualResult + ". " + e.getMessage();
		}
		ReportUtility.reportStepStatus(executionContext, expectedResult, actualResult, status);return status;
				

	}

	/*
	 * =============================================================================
	 * ============== Function Name: validate_Object_Text_Is_Not_Blank CREATED BY:
	 * ACOE Team CREATED DATE: 05/03/2019 DESCRIPTION: This method is used validate
	 * object text is not blank Parameter: Object of class ExecutionContext RETURNS:
	 * Nothing COMMENTS: Modification Log: Revision: 1.0 Date: 05/03/2019 Comment:
	 * Implemented method with initial requirement
	 * 
	 * =============================================================================
	 * ==============
	 */
	/**
	 * <p style="font-family:Arial;">
	 * <b>DESCRIPTION: This method is used validate object text is not blank <br>
	 * <br>
	 * Author: - ACOE Team <br>
	 * <br>
	 * Date Created: 05/03/2019 <br>
	 * <br>
	 * Revision History: <br>
	 * 1.0: Define method and added initial code <br>
	 * 
	 * @param Object
	 *            of class ExecutionContext
	 * @return No Return Value
	 * @throws Exception
	 *             If any error occurs, reports the exception message and log the
	 *             full exception trace in log file </b>
	 *             </P>
	 * 
	 */
	public static boolean validate_Object_Text_Is_Not_Blank(ExecutionContext executionContext) {
		String objectXPath = executionContext.getCurrentElementXPath();
		String actualResult = "Object with locator " + objectXPath + " is not found";
		String expectedResult = "Object text with locator " + objectXPath + " should not be blank";
		boolean status = false;
		try {
			List<WebElement> elements = findElements(executionContext.getDriver(), objectXPath);
			if (elements != null && elements.size() > 0) {
				String actualText = elements.get(0).getText();
				if (!(actualText == null || actualText.equalsIgnoreCase(""))) {
					actualResult = "Object text with locator " + objectXPath + " is not blank";
					status = true;
				} else {
					actualResult = "Object text with locator " + objectXPath + " is blank";
				}
			}

		} catch (Exception e) {
			ExceptionHandler.handleException(e);
			actualResult = actualResult + ". " + e.getMessage();
		}
		ReportUtility.reportStepStatus(executionContext, expectedResult, actualResult, status);return status;
				

	}

	/*
	 * =============================================================================
	 * ============== Function Name: validate_Object_Value CREATED BY: ACOE Team
	 * CREATED DATE: 05/03/2019 DESCRIPTION: This method is used to validate object
	 * value attribute Parameter: Object of class ExecutionContext RETURNS: Nothing
	 * COMMENTS: Modification Log: Revision: 1.0 Date: 05/03/2019 Comment:
	 * Implemented method with initial requirement
	 * 
	 * =============================================================================
	 * ==============
	 */
	/**
	 * <p style="font-family:Arial;">
	 * <b>DESCRIPTION: This method is used to validate object value attribute <br>
	 * <br>
	 * Author: - ACOE Team <br>
	 * <br>
	 * Date Created: 05/03/2019 <br>
	 * <br>
	 * Revision History: <br>
	 * 1.0: Define method and added initial code <br>
	 * 
	 * @param Object
	 *            of class ExecutionContext
	 * @return No Return Value
	 * @throws Exception
	 *             If any error occurs, reports the exception message and log the
	 *             full exception trace in log file </b>
	 *             </P>
	 * 
	 */
	public static boolean validate_Object_Value(ExecutionContext executionContext) {
		String actualResult = "Specified Object is not found";
		String expectedResult = "Specified object value should be validated with expected value";
		boolean status = false;
		try {
			String objectXPath = executionContext.getCurrentElementXPath();
			String data = executionContext.getCurrentElementData();
			List<WebElement> elements = findElements(executionContext.getDriver(), objectXPath);
			if (elements != null && elements.size() > 0) {
				if (data == null || data.equalsIgnoreCase("")) {
					String actualText = elements.get(0).getAttribute("value");
					if (actualText != null) {
						if (actualText.equalsIgnoreCase(data)) {
							actualResult = "Object with locator " + objectXPath + " actual value " + actualText
									+ " is validated successfully with expected value " + data + "";
							status = true;
						} else {
							if (actualText.toLowerCase().contains(data.toLowerCase())) {
								actualResult = "Object with locator " + objectXPath + " actual value " + actualText
										+ " is validated successfully with expected value " + data + "";
								status = true;
							} else {
								actualResult = "Object with locator " + objectXPath + " actual value " + actualText
										+ " is not validated successfully with expected value " + data + "";
							}
						}
					} else {
						actualResult = "Object with locator " + objectXPath + " value is null";
					}
				}
			} else {
				actualResult = "Object with locator " + objectXPath + " is not found";
			}

		} catch (Exception e) {
			ExceptionHandler.handleException(e);
			actualResult = actualResult + ". " + e.getMessage();
		}
		ReportUtility.reportStepStatus(executionContext, expectedResult, actualResult, status);return status;
				

	}

	/*
	 * =============================================================================
	 * ============== Function Name: validate_Object_Value_Is_Not_Blank CREATED BY:
	 * ACOE Team CREATED DATE: 05/03/2019 DESCRIPTION: This method is used validate
	 * object attribute is not blank Parameter: Object of class ExecutionContext
	 * RETURNS: Nothing COMMENTS: Modification Log: Revision: 1.0 Date: 05/03/2019
	 * Comment: Implemented method with initial requirement
	 * 
	 * =============================================================================
	 * ==============
	 */
	/**
	 * <p style="font-family:Arial;">
	 * <b>DESCRIPTION: This method is used validate object attribute is not blank
	 * <br>
	 * <br>
	 * Author: - ACOE Team <br>
	 * <br>
	 * Date Created: 05/03/2019 <br>
	 * <br>
	 * Revision History: <br>
	 * 1.0: Define method and added initial code <br>
	 * 
	 * @param Object
	 *            of class ExecutionContext
	 * @return No Return Value
	 * @throws Exception
	 *             If any error occurs, reports the exception message and log the
	 *             full exception trace in log file </b>
	 *             </P>
	 * 
	 */
	public boolean validate_Object_Value_Is_Not_Blank(ExecutionContext executionContext) {
		String objectXPath = executionContext.getCurrentElementXPath();
		String actualResult = "Object with locator " + objectXPath + " is not found";
		String expectedResult = "Object value with locator " + objectXPath + " should not be blank";
		boolean status = false;
		try {
			String data = executionContext.getCurrentElementData();
			List<WebElement> elements = findElements(executionContext.getDriver(), objectXPath);
			if (elements != null && elements.size() > 0) {
				if (data == null || data.equalsIgnoreCase("")) {
					String actualText = elements.get(0).getAttribute("value");
					if (!(actualText == null || actualText.equalsIgnoreCase(""))) {
						actualResult = "Object value with locator " + objectXPath + " is not blank";
						status = true;
					} else {
						actualResult = "Object value with locator " + objectXPath + " is blank";
					}
				}
			} else {
				actualResult = "Object with locator " + objectXPath + " is not found";
			}

		} catch (Exception e) {
			ExceptionHandler.handleException(e);
			actualResult = actualResult + ". " + e.getMessage();
		}
		ReportUtility.reportStepStatus(executionContext, expectedResult, actualResult, status);return status;
				

	}

	/*
	 * =============================================================================
	 * ============== Function Name: validate_Object_Value_Is_Blank CREATED BY: ACOE
	 * Team CREATED DATE: 05/03/2019 DESCRIPTION: This method is used validate
	 * object value attribute is blank Parameter: Object of class ExecutionContext
	 * RETURNS: Nothing COMMENTS: Modification Log: Revision: 1.0 Date: 05/03/2019
	 * Comment: Implemented method with initial requirement
	 * 
	 * =============================================================================
	 * ==============
	 */
	/**
	 * <p style="font-family:Arial;">
	 * <b>DESCRIPTION: This method is used validate object value attribute is blank
	 * <br>
	 * <br>
	 * Author: - ACOE Team <br>
	 * <br>
	 * Date Created: 05/03/2019 <br>
	 * <br>
	 * Revision History: <br>
	 * 1.0: Define method and added initial code <br>
	 * 
	 * @param Object
	 *            of class ExecutionContext
	 * @return No Return Value
	 * @throws Exception
	 *             If any error occurs, reports the exception message and log the
	 *             full exception trace in log file </b>
	 *             </P>
	 * 
	 */
	public boolean validate_Object_Value_Is_Blank(ExecutionContext executionContext) {
		String objectXPath = executionContext.getCurrentElementXPath();
		String actualResult = "Object with locator " + objectXPath + " is not found";
		String expectedResult = "Object value with locator " + objectXPath + " should be blank";
		boolean status = false;
		try {
			String data = executionContext.getCurrentElementData();
			List<WebElement> elements = findElements(executionContext.getDriver(), objectXPath);
			if (elements != null && elements.size() > 0) {
				if (data == null || data.equalsIgnoreCase("")) {
					String actualText = elements.get(0).getAttribute("value");
					if (!(actualText == null || actualText.equalsIgnoreCase(""))) {
						actualResult = "Object value with locator " + objectXPath + " is not blank";

					} else {
						actualResult = "Object value with locator " + objectXPath + " is blank";
						status = true;
					}
				}
			} else {
				actualResult = "Object with locator " + objectXPath + " is not found";
			}

		} catch (Exception e) {
			ExceptionHandler.handleException(e);
			actualResult = actualResult + ". " + e.getMessage();
		}
		ReportUtility.reportStepStatus(executionContext, expectedResult, actualResult, status);return status;
				

	}

	/*
	 * =============================================================================
	 * ============== Function Name: validate_Checkbox CREATED BY: ACOE Team CREATED
	 * DATE: 05/03/2019 DESCRIPTION: This method is used validate specified check
	 * box is selected Parameter: Object of class ExecutionContext RETURNS: Nothing
	 * COMMENTS: Modification Log: Revision: 1.0 Date: 05/03/2019 Comment:
	 * Implemented method with initial requirement
	 * 
	 * =============================================================================
	 * ==============
	 */
	/**
	 * <p style="font-family:Arial;">
	 * <b>DESCRIPTION: This method is used validate specified check box is selected
	 * <br>
	 * <br>
	 * Author: - ACOE Team <br>
	 * <br>
	 * Date Created: 05/03/2019 <br>
	 * <br>
	 * Revision History: <br>
	 * 1.0: Define method and added initial code <br>
	 * 
	 * @param Object
	 *            of class ExecutionContext
	 * @return No Return Value
	 * @throws Exception
	 *             If any error occurs, reports the exception message and log the
	 *             full exception trace in log file </b>
	 *             </P>
	 * 
	 */
	public static boolean validate_Checkbox(ExecutionContext executionContext) {
		String actualResult = "Checkbox with specified locator is not found";
		String expectedResult = "Checkbox with specified locator should be found and selected";
		boolean status = false;
		try {
			String objectXPath = executionContext.getCurrentElementXPath();
			actualResult = "Checkbox with locator " + objectXPath + " is not found";
			expectedResult = "Checkbox with locator " + objectXPath + " should be found and selected";
			List<WebElement> elements = findElements(executionContext.getDriver(), objectXPath);
			if (elements.size() > 0) {
				if (elements.get(0).isSelected()) {
					actualResult = "Checkbox with locator " + objectXPath + " is found and selected";
					status = true;
				} else {
					actualResult = "Checkbox with locator " + objectXPath + " is found and not selected";
				}
			} else {
				actualResult = "Checkbox with locator " + objectXPath + " is not found";
			}
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
			actualResult = actualResult + ". " + e.getMessage();
		}
		ReportUtility.reportStepStatus(executionContext, expectedResult, actualResult, status);return status;
				
	}

	/*
	 * =============================================================================
	 * ============== Function Name: validate_Checkbox_Selected CREATED BY: ACOE
	 * Team CREATED DATE: 05/03/2019 DESCRIPTION: This method is used validate
	 * checkbox object is selected Parameter: Object of class ExecutionContext
	 * RETURNS: Nothing COMMENTS: Modification Log: Revision: 1.0 Date: 05/03/2019
	 * Comment: Implemented method with initial requirement
	 * 
	 * =============================================================================
	 * ==============
	 */
	/**
	 * <p style="font-family:Arial;">
	 * <b>DESCRIPTION: This method is used validate checkbox object is selected <br>
	 * <br>
	 * Author: - ACOE Team <br>
	 * <br>
	 * Date Created: 05/03/2019 <br>
	 * <br>
	 * Revision History: <br>
	 * 1.0: Define method and added initial code <br>
	 * 
	 * @param Object
	 *            of class ExecutionContext
	 * @return No Return Value
	 * @throws Exception
	 *             If any error occurs, reports the exception message and log the
	 *             full exception trace in log file </b>
	 *             </P>
	 * 
	 */
	public static boolean validate_Checkbox_Selected(ExecutionContext executionContext) {
		String actualResult = "Checkbox with specified locator is not found";
		String expectedResult = "Checkbox with specified locator should be found and selected";
		boolean status = false;
		try {
			String objectXPath = executionContext.getCurrentElementXPath();
			actualResult = "Checkbox with locator " + objectXPath + " is not found";
			expectedResult = "Checkbox with locator " + objectXPath + " should be found and selected";
			List<WebElement> elements = findElements(executionContext.getDriver(), objectXPath);
			if (elements.size() > 0) {
				if (elements.get(0).isSelected()) {
					actualResult = "Checkbox with locator " + objectXPath + " is found and selected";
					status = true;
				} else {
					actualResult = "Checkbox with locator " + objectXPath + " is found and not selected";
				}
			} else {
				actualResult = "Checkbox with locator " + objectXPath + " is not found";
			}
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
			actualResult = actualResult + ". " + e.getMessage();
		}
		ReportUtility.reportStepStatus(executionContext, expectedResult, actualResult, status);return status;
				
	}

	/*
	 * =============================================================================
	 * ============== Function Name: validate_Checkbox_Is_Not_Selected CREATED BY:
	 * ACOE Team CREATED DATE: 05/03/2019 DESCRIPTION: This method is used to
	 * validate check box object is not selected Parameter: Object of class
	 * ExecutionContext RETURNS: Nothing COMMENTS: Modification Log: Revision: 1.0
	 * Date: 05/03/2019 Comment: Implemented method with initial requirement
	 * 
	 * =============================================================================
	 * ==============
	 */
	/**
	 * <p style="font-family:Arial;">
	 * <b>DESCRIPTION: This method is used to validate check box object is not
	 * selected <br>
	 * <br>
	 * Author: - ACOE Team <br>
	 * <br>
	 * Date Created: 05/03/2019 <br>
	 * <br>
	 * Revision History: <br>
	 * 1.0: Define method and added initial code <br>
	 * 
	 * @param Object
	 *            of class ExecutionContext
	 * @return No Return Value
	 * @throws Exception
	 *             If any error occurs, reports the exception message and log the
	 *             full exception trace in log file </b>
	 *             </P>
	 * 
	 */
	public static boolean validate_Checkbox_Is_Not_Selected(ExecutionContext executionContext) {
		String actualResult = "Checkbox with specified locator is not found";
		String expectedResult = "Checkbox with specified locator should be found and not selected";
		boolean status = false;
		try {
			String objectXPath = executionContext.getCurrentElementXPath();
			actualResult = "Checkbox with locator " + objectXPath + " is not found";
			expectedResult = "Checkbox with locator " + objectXPath + " should be found and not selected";
			List<WebElement> elements = findElements(executionContext.getDriver(), objectXPath);
			if (elements.size() > 0) {
				if (elements.get(0).isSelected()) {
					actualResult = "Checkbox with locator " + objectXPath + " is found and selected";
				} else {
					actualResult = "Checkbox with locator " + objectXPath + " is found and not selected";
					status = true;
				}
			} else {
				actualResult = "Checkbox with locator " + objectXPath + " is not found";
			}
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
			actualResult = actualResult + ". " + e.getMessage();
		}
		ReportUtility.reportStepStatus(executionContext, expectedResult, actualResult, status);return status;
				
	}

	/*
	 * =============================================================================
	 * ============== Function Name: select_Listbox_Option_By_Partial_Text CREATED
	 * BY: ACOE Team CREATED DATE: 05/03/2019 DESCRIPTION: This method is used to
	 * select list box option by using list box option partial text Parameter:
	 * Object of class ExecutionContext RETURNS: Nothing COMMENTS: Modification Log:
	 * Revision: 1.0 Date: 05/03/2019 Comment: Implemented method with initial
	 * requirement
	 * 
	 * =============================================================================
	 * ==============
	 */
	/**
	 * <p style="font-family:Arial;">
	 * <b>DESCRIPTION: This method is used to select list box option by using list
	 * box option partial text <br>
	 * <br>
	 * Author: - ACOE Team <br>
	 * <br>
	 * Date Created: 05/03/2019 <br>
	 * <br>
	 * Revision History: <br>
	 * 1.0: Define method and added initial code <br>
	 * 
	 * @param Object
	 *            of class ExecutionContext
	 * @return No Return Value
	 * @throws Exception
	 *             If any error occurs, reports the exception message and log the
	 *             full exception trace in log file </b>
	 *             </P>
	 * 
	 */
	public static boolean select_Listbox_Option_By_Partial_Text(ExecutionContext executionContext) {
		String actualResult = "Specified option is not selected in listbox";
		String expectedResult = "Specified option should be selected selected in listbox";
		boolean status = false;
		try {
			String objectXPath = executionContext.getCurrentElementXPath();
			String data = executionContext.getCurrentElementData();
			List<WebElement> elements = findElements(executionContext.getDriver(), objectXPath);
			if (elements != null && elements.size() > 0) {
				if (data == null || data.equalsIgnoreCase("")) {
					Select selectItem = new Select(elements.get(0));
					List<WebElement> options = selectItem.getOptions();
					String OptionValue = "";
					
					for (int i = 0; i < options.size(); i++) {
						OptionValue = options.get(i).getText();
						Log.writeToLogFile("Options: " + OptionValue);
						if (OptionValue.toLowerCase().contains(data.toLowerCase())) {
							selectItem.selectByIndex(i);
							status = true;
							actualResult = "Option " + data + " is selected in listbox with locator " + objectXPath;
							break;
						}
					}
					if (!status) {
						actualResult = "Option " + data
								+ " is not selected as it is not found in listbox with locator " + objectXPath;
						
					}
				} else {
					actualResult = "No data specified. Data is required for selecting Option in listbox with locator "
							+ objectXPath;
				}

			} else {
				actualResult = "No object found with object name locator " + objectXPath;
			}

		} catch (Exception e) {
			ExceptionHandler.handleException(e);
			actualResult = actualResult + ". " + e.getMessage();
		}
		ReportUtility.reportStepStatus(executionContext, expectedResult, actualResult, status);return status;
				

	}

	/*
	 * =============================================================================
	 * ============== Function Name: select_Listbox_Option_By_Index CREATED BY: ACOE
	 * Team CREATED DATE: 05/03/2019 DESCRIPTION: This method is used to select list
	 * box option by using index Parameter: Object of class ExecutionContext
	 * RETURNS: Nothing COMMENTS: Modification Log: Revision: 1.0 Date: 05/03/2019
	 * Comment: Implemented method with initial requirement
	 * 
	 * =============================================================================
	 * ==============
	 */
	/**
	 * <p style="font-family:Arial;">
	 * <b>DESCRIPTION: This method is used to select list box option by using index
	 * <br>
	 * <br>
	 * Author: - ACOE Team <br>
	 * <br>
	 * Date Created: 05/03/2019 <br>
	 * <br>
	 * Revision History: <br>
	 * 1.0: Define method and added initial code <br>
	 * 
	 * @param Object
	 *            of class ExecutionContext
	 * @return No Return Value
	 * @throws Exception
	 *             If any error occurs, reports the exception message and log the
	 *             full exception trace in log file </b>
	 *             </P>
	 * 
	 */
	public static boolean select_Listbox_Option_By_Index(ExecutionContext executionContext) {
		String objectXPath = executionContext.getCurrentElementXPath();
		String data = executionContext.getCurrentElementData();
		String actualResult = "Option with index " + data + " is not selected in listbox with locator "
				+ objectXPath;
		String expectedResult = "Option with index " + data + " should be selected in listbox with locator "
				+ objectXPath;
		boolean status = false;
		try {
			List<WebElement> elements = findElements(executionContext.getDriver(), objectXPath);
			if (elements != null && elements.size() > 0) {
				if (!(data == null || data.equalsIgnoreCase(""))) {
					int index = -1;
					try {
						index = Integer.parseInt(data);
						Select selectItem = new Select(elements.get(0));
						selectItem.getOptions().size();
						selectItem.selectByIndex(index);
						actualResult = "Option with index " + index + " is selected in listbox with locator "
								+ objectXPath;
						status = true;
					} catch (Exception e) {
						ExceptionHandler.handleException(e);
						actualResult = "Option with index " + data + " is not selected in listbox with locator "
								+ objectXPath + " " + e.getMessage();
					}
					if (index == -1) {
						actualResult = "Option with index " + data + " is not selected in listbox with locator "
								+ objectXPath + " as index is not integer";
					}

				} else {
					actualResult = "No data specified. Data is required for selecting Option in listbox with locator "
							+ objectXPath;
				}

			} else {
				actualResult = "Option with index " + data
						+ " is not selected in listbox as no object found with locator " + objectXPath;
			}

		} catch (Exception e) {
			ExceptionHandler.handleException(e);
			actualResult = actualResult + ". " + e.getMessage();
		}
		ReportUtility.reportStepStatus(executionContext, expectedResult, actualResult, status);return status;
				

	}

	/*
	 * =============================================================================
	 * ============== Function Name: select_Listbox_Option_By_Value CREATED BY: ACOE
	 * Team CREATED DATE: 05/03/2019 DESCRIPTION: This method is used select list
	 * box option by using value attribute Parameter: Object of class
	 * ExecutionContext RETURNS: Nothing COMMENTS: Modification Log: Revision: 1.0
	 * Date: 05/03/2019 Comment: Implemented method with initial requirement
	 * 
	 * =============================================================================
	 * ==============
	 */
	/**
	 * <p style="font-family:Arial;">
	 * <b>DESCRIPTION: This method is used select list box option by using value
	 * attribute <br>
	 * <br>
	 * Author: - ACOE Team <br>
	 * <br>
	 * Date Created: 05/03/2019 <br>
	 * <br>
	 * Revision History: <br>
	 * 1.0: Define method and added initial code <br>
	 * 
	 * @param Object
	 *            of class ExecutionContext
	 * @return No Return Value
	 * @throws Exception
	 *             If any error occurs, reports the exception message and log the
	 *             full exception trace in log file </b>
	 *             </P>
	 * 
	 */
	public static boolean select_Listbox_Option_By_Value(ExecutionContext executionContext) {
		String objectXPath = executionContext.getCurrentElementXPath();
		String data = executionContext.getCurrentElementData();
		String actualResult = "Option with value " + data + " is not selected in listbox with locator "
				+ objectXPath;
		String expectedResult = "Option with value " + data + " should be selected in listbox with locator "
				+ objectXPath;
		boolean status = false;
		try {
			List<WebElement> elements = findElements(executionContext.getDriver(), objectXPath);
			if (elements != null && elements.size() > 0) {
				if (!(data == null || data.equalsIgnoreCase(""))) {
					try {
						Select selectItem = new Select(elements.get(0));
						selectItem.selectByValue(data);
						status = true;
						actualResult = "Option with value " + data + " is selected in listbox with locator "
								+ objectXPath;
					} catch (Exception e) {
						ExceptionHandler.handleException(e);
						actualResult = "Option with value " + data + " is not selected in listbox with locator "
								+ objectXPath + " " + e.getMessage();
					}
				} else {
					actualResult = "No data specified. Data is required for selecting option in listbox with locator "
							+ objectXPath + " with value";
				}

			} else {
				actualResult = "Option with value " + data + " is not selected in listbox with locator "
						+ objectXPath + " as no object is found with the locator";
			}

		} catch (Exception e) {
			ExceptionHandler.handleException(e);
			actualResult = actualResult + ". " + e.getMessage();
		}
		ReportUtility.reportStepStatus(executionContext, expectedResult, actualResult, status);return status;
				

	}

	/*
	 * =============================================================================
	 * ============== Function Name: validate_Selected_List_Box_Option CREATED BY:
	 * ACOE Team CREATED DATE: 05/03/2019 DESCRIPTION: This method is used validate
	 * selected list box option Parameter: Object of class ExecutionContext RETURNS:
	 * Nothing COMMENTS: Modification Log: Revision: 1.0 Date: 05/03/2019 Comment:
	 * Implemented method with initial requirement
	 * 
	 * =============================================================================
	 * ==============
	 */
	/**
	 * <p style="font-family:Arial;">
	 * <b>DESCRIPTION: This method is used validate selected list box option <br>
	 * <br>
	 * Author: - ACOE Team <br>
	 * <br>
	 * Date Created: 05/03/2019 <br>
	 * <br>
	 * Revision History: <br>
	 * 1.0: Define method and added initial code <br>
	 * 
	 * @param Object
	 *            of class ExecutionContext
	 * @return No Return Value
	 * @throws Exception
	 *             If any error occurs, reports the exception message and log the
	 *             full exception trace in log file </b>
	 *             </P>
	 * 
	 */
	public static boolean validate_Selected_List_Box_Option(ExecutionContext executionContext) {
		String objectXPath = executionContext.getCurrentElementXPath();
		String data = executionContext.getCurrentElementData();
		String actualResult = "Option " + data + " is not selected in listbox with locator " + objectXPath;
		String expectedResult = "Option " + data + " should be selected in listbox with locator " + objectXPath;
		boolean status = false;
		try {
			List<WebElement> elements = findElements(executionContext.getDriver(), objectXPath);
			if (elements != null && elements.size() > 0) {
				if (data == null || data.equalsIgnoreCase("")) {
					Select selectItem = new Select(elements.get(0));
					List<WebElement> selectedOptions = selectItem.getAllSelectedOptions();
					if (selectedOptions.size() > 0) {
						String selectedOption = selectedOptions.get(0).getText();
						if (selectedOption != null && selectedOption.equalsIgnoreCase(data)) {
							actualResult = "Option " + selectedOption + " is selected in listbox with locator "
									+ objectXPath;
							status = true;
						} else {
							actualResult = "No option selected in listbox with locator " + objectXPath;
						}
					} else {
						actualResult = "No option selected in listbox with locator " + objectXPath;
					}

				} else {
					actualResult = "No data specified. Data is required for validating selected value in listbox";
				}

			} else {
				actualResult = "Value " + data + " is not selected in listbox with locator " + objectXPath
						+ " as no object is found";
			}

		} catch (Exception e) {
			ExceptionHandler.handleException(e);
			actualResult = actualResult + ". " + e.getMessage();
		}
		ReportUtility.reportStepStatus(executionContext, expectedResult, actualResult, status);return status;
				
	}

	/*
	 * =============================================================================
	 * ============== Function Name: validate_Listbox_Options CREATED BY: ACOE Team
	 * CREATED DATE: 05/03/2019 DESCRIPTION: This method is used validate list box
	 * options Parameter: Object of class ExecutionContext RETURNS: Nothing
	 * COMMENTS: Modification Log: Revision: 1.0 Date: 05/03/2019 Comment:
	 * Implemented method with initial requirement
	 * 
	 * =============================================================================
	 * ==============
	 */
	/**
	 * <p style="font-family:Arial;">
	 * <b>DESCRIPTION: This method is used validate list box options <br>
	 * <br>
	 * Author: - ACOE Team <br>
	 * <br>
	 * Date Created: 05/03/2019 <br>
	 * <br>
	 * Revision History: <br>
	 * 1.0: Define method and added initial code <br>
	 * 
	 * @param Object
	 *            of class ExecutionContext
	 * @return No Return Value
	 * @throws Exception
	 *             If any error occurs, reports the exception message and log the
	 *             full exception trace in log file </b>
	 *             </P>
	 * 
	 */
	public static boolean validate_Listbox_Options(ExecutionContext executionContext) {
		String objectXPath = executionContext.getCurrentElementXPath();
		String data = executionContext.getCurrentElementData();
		String expectedResult = "List box values for object with locator " + objectXPath
				+ " should be compared with expected list box values " + data + "";
		String actualResult = "List box values for object with locator " + objectXPath + " values are not compared";
		boolean status = false;
		try {
			List<WebElement> elements = findElements(executionContext.getDriver(), objectXPath);
			if (elements != null && elements.size() > 0) {
				if (!(data == null || data.equalsIgnoreCase(""))) {
					Select selectItem = new Select(elements.get(0));
					List<WebElement> elements1 = selectItem.getOptions();
					String actualData = "";
					int i = 0;
					for (WebElement e : elements1) {
						String text = e.getText();
						if (text == null) {
							text = "";
						}
						text = text.trim();
						if (i == 0) {
							actualData = text;
							i++;
						} else {
							actualData = actualData + "," + text;
						}
					}

					actualData = actualData.trim();
					data = data.trim();
					if (actualData.equals(data)) {
						actualResult = "List box values with locator " + objectXPath + " actual values '"
								+ actualData + "' are matched with expected list box values " + data;
						status = true;
					} else {
						actualResult = "List box values with locator " + objectXPath + " actual values "
								+ actualData + " are not matched with expected list box values " + data + "'";
					}
				} else {
					actualResult = "No data specified. Data is required for validating list box values with locator "
							+ objectXPath;
				}

			} else {
				actualResult = "No object found with locator " + objectXPath;
			}

		} catch (Exception e) {
			ExceptionHandler.handleException(e);
			actualResult = actualResult + ". " + e.getMessage();
		}
		ReportUtility.reportStepStatus(executionContext, expectedResult, actualResult, status);return status;
				
	}

	/*
	 * =============================================================================
	 * ============== Function Name: validate_Selected_Listbox_Option_Is_Blank
	 * CREATED BY: ACOE Team CREATED DATE: 05/03/2019 DESCRIPTION: This method is
	 * used no option is selected in specified list box Parameter: Object of class
	 * ExecutionContext RETURNS: Nothing COMMENTS: Modification Log: Revision: 1.0
	 * Date: 05/03/2019 Comment: Implemented method with initial requirement
	 * 
	 * =============================================================================
	 * ==============
	 */
	/**
	 * <p style="font-family:Arial;">
	 * <b>DESCRIPTION: This method is used no option is selected in specified list
	 * box <br>
	 * <br>
	 * Author: - ACOE Team <br>
	 * <br>
	 * Date Created: 05/03/2019 <br>
	 * <br>
	 * Revision History: <br>
	 * 1.0: Define method and added initial code <br>
	 * 
	 * @param Object
	 *            of class ExecutionContext
	 * @return No Return Value
	 * @throws Exception
	 *             If any error occurs, reports the exception message and log the
	 *             full exception trace in log file </b>
	 *             </P>
	 * 
	 */
	public static boolean validate_Selected_Listbox_Option_Is_Blank(ExecutionContext executionContext) {
		String objectXPath = executionContext.getCurrentElementXPath();
		String actualResult = "Value is selected in listbox with locator " + objectXPath;
		String expectedResult = "No value should be selected in listbox with locator " + objectXPath;
		boolean status = false;
		try {
			List<WebElement> elements = findElements(executionContext.getDriver(), objectXPath);

			if (elements != null && elements.size() > 0) {
				Select selectItem = new Select(elements.get(0));
				List<WebElement> selectedOptions = selectItem.getAllSelectedOptions();
				if (selectedOptions.size() > 0) {
					String selectedOption = "";
					try {
						selectedOption = selectedOptions.get(0).getText();
					} catch (Exception e) {
					}
					;
					Log.writeToLogFile("Selected Listbox Option: " + selectedOption);
					if (selectedOption != null) {
						selectedOption = selectedOption.trim();
					}
					Log.writeToLogFile("Selected Listbox Option: " + selectedOption);
					if (selectedOption == null || selectedOption.equalsIgnoreCase("")) {
						actualResult = "No option selected in listbox with locator " + objectXPath + "";
						status = true;
					} else {
						actualResult = "Option " + selectedOption + " is selected in listbox with locator "
								+ objectXPath;
					}
				} else {
					actualResult = "No option selected in listbox with locator " + objectXPath;
					status = true;
				}

			} else {
				actualResult = "No object found with locator " + objectXPath + " for listbox";
			}

		} catch (Exception e) {
			ExceptionHandler.handleException(e);
			actualResult = actualResult + ". " + e.getMessage();
		}
		ReportUtility.reportStepStatus(executionContext, expectedResult, actualResult, status);return status;
				

	}

	/*
	 * =============================================================================
	 * ============== Function Name: scroll_To_Object CREATED BY: ACOE Team CREATED
	 * DATE: 05/03/2019 DESCRIPTION: This method is used scroll specified object
	 * Parameter: Object of class ExecutionContext RETURNS: Nothing COMMENTS:
	 * Modification Log: Revision: 1.0 Date: 05/03/2019 Comment: Implemented method
	 * with initial requirement
	 * 
	 * =============================================================================
	 * ==============
	 */
	/**
	 * <p style="font-family:Arial;">
	 * <b>DESCRIPTION: This method is used scroll specified object <br>
	 * <br>
	 * Author: - ACOE Team <br>
	 * <br>
	 * Date Created: 05/03/2019 <br>
	 * <br>
	 * Revision History: <br>
	 * 1.0: Define method and added initial code <br>
	 * 
	 * @param Object
	 *            of class ExecutionContext
	 * @return No Return Value
	 * @throws Exception
	 *             If any error occurs, reports the exception message and log the
	 *             full exception trace in log file </b>
	 *             </P>
	 * 
	 */
	public static boolean scroll_To_Object(ExecutionContext executionContext) {
		String objectXPath = executionContext.getCurrentElementXPath();
		String expected = "Object with locator " + objectXPath + " should be scrolled to front";
		String actual = "Object with locator " + objectXPath + " is not scrolled to front";
		boolean status = false;
		try {
			String xPath = objectXPath;
			try {
				Log.writeToLogFile("XPath: " + xPath);
				List<WebElement> elements = executionContext.getDriver().findElements(By.xpath(xPath));
				Log.writeToLogFile("Element Size: " + elements.size());
				long defaultTime = 100;
				if ((elements.size() > 0)) {
					Log.writeToLogFile("Moving Scroll to Element Status....");
					int locationY = elements.get(0).getLocation().y;
					int locationX = elements.get(0).getLocation().x;
					String javaScriptCommand = "window.scrollTo(" + locationX + "," + (locationY - 5) + ");";
					String javaScriptCommandDefault = "window.scrollTo(0,0);";
					JavascriptExecutor jse = (JavascriptExecutor) executionContext.getDriver();
					try {
						Thread.sleep(defaultTime);
					} catch (Exception e) {
					}
					Log.writeToLogFile("Going to execute JAVA Script Command: " + javaScriptCommandDefault);
					jse.executeScript(javaScriptCommandDefault);
					try {
						Thread.sleep(defaultTime);
					} catch (Exception e) {
					}
					Log.writeToLogFile("JAVA Script Command '" + javaScriptCommandDefault + "' executed successfuly");
					Log.writeToLogFile("Going to execute JAVA Script Command: " + javaScriptCommand);
					jse.executeScript(javaScriptCommand);
					Log.writeToLogFile("JAVA Script Command '" + javaScriptCommand + "' executed successfuly");
					status = true;
					actual = "Object with locator " + xPath + " is scrolled to front";
				} else {
					actual = "No object is found with the locator '" + xPath + "'";
				}
			} catch (Exception ee) {

			}
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
			actual = actual + ". " + e.getMessage();
		}
		ReportUtility.reportStepStatus(executionContext, expected, actual, status); return status;
				
	}

	/*
	 * =============================================================================
	 * ============== Function Name: switch_To_Frame_By_Object CREATED BY: ACOE Team
	 * CREATED DATE: 05/03/2019 DESCRIPTION: This method is used switch to iFrame
	 * using object Parameter: Object of class ExecutionContext RETURNS: Nothing
	 * COMMENTS: Modification Log: Revision: 1.0 Date: 05/03/2019 Comment:
	 * Implemented method with initial requirement
	 * 
	 * =============================================================================
	 * ==============
	 */
	/**
	 * <p style="font-family:Arial;">
	 * <b>DESCRIPTION: This method is used switch to iFrame using object <br>
	 * <br>
	 * Author: - ACOE Team <br>
	 * <br>
	 * Date Created: 05/03/2019 <br>
	 * <br>
	 * Revision History: <br>
	 * 1.0: Define method and added initial code <br>
	 * 
	 * @param Object
	 *            of class ExecutionContext
	 * @return No Return Value
	 * @throws Exception
	 *             If any error occurs, reports the exception message and log the
	 *             full exception trace in log file </b>
	 *             </P>
	 * 
	 */
	public static boolean switch_To_Frame_By_Object(ExecutionContext executionContext) {
		String objectXPath = executionContext.getCurrentElementXPath();
		String actualResult = "No object found with object locator " + objectXPath;
		String expectedResult = "iFrame should be switched using object locator " + objectXPath;
		boolean status = false;
		try {
			List<WebElement> elements = findElements(executionContext.getDriver(), objectXPath);
			if (elements != null && elements.size() > 0) {
				executionContext.getDriver().switchTo().frame(elements.get(0));
				status = true;
				actualResult = "iFrame is switched using object with locator " + objectXPath;
			}
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
			actualResult = actualResult + ". " + e.getMessage();
		}
		ReportUtility.reportStepStatus(executionContext, expectedResult, actualResult, status);return status;
				
	}

	/*
	 * =============================================================================
	 * ============== Function Name: validate_Window_Handle_Count CREATED BY: ACOE
	 * Team CREATED DATE: 05/03/2019 DESCRIPTION: This method is used validate
	 * window handle count Parameter: Object of class ExecutionContext RETURNS:
	 * Nothing COMMENTS: Modification Log: Revision: 1.0 Date: 05/03/2019 Comment:
	 * Implemented method with initial requirement
	 * 
	 * =============================================================================
	 * ==============
	 */
	/**
	 * <p style="font-family:Arial;">
	 * <b>DESCRIPTION: This method is used validate window handle count <br>
	 * <br>
	 * Author: - ACOE Team <br>
	 * <br>
	 * Date Created: 05/03/2019 <br>
	 * <br>
	 * Revision History: <br>
	 * 1.0: Define method and added initial code <br>
	 * 
	 * @param Object
	 *            of class ExecutionContext
	 * @return No Return Value
	 * @throws Exception
	 *             If any error occurs, reports the exception message and log the
	 *             full exception trace in log file </b>
	 *             </P>
	 * 
	 */
	public static boolean validate_Window_Handle_Count(ExecutionContext executionContext) {
		String data = executionContext.getCurrentElementData();
		String actualResult = "Actual window handle count is: not found";
		String expectedResult = "Expected window handle count should be: " + data + "";
		boolean status = false;
		try {
			int count = 1;
			try {
				count = Integer.parseInt(data);
			} catch (Exception e) {
			}
			int currentCount = executionContext.getDriver().getWindowHandles().size();
			actualResult = "Actual window handle count is: " + currentCount;
			if (count == currentCount) {
				status = true;
			}

		} catch (Exception e) {
			ExceptionHandler.handleException(e);
			actualResult = actualResult + ". " + e.getMessage();
		}
		ReportUtility.reportStepStatus(executionContext, expectedResult, actualResult, status);return status;
				

	}

	/*
	 * =============================================================================
	 * ============== Function Name: validate_Object_Count CREATED BY: ACOE Team
	 * CREATED DATE: 05/03/2019 DESCRIPTION: This method is used validate object
	 * count based on provided comparison option Parameter: Object of class
	 * ExecutionContext RETURNS: Nothing COMMENTS: Modification Log: Revision: 1.0
	 * Date: 05/03/2019 Comment: Implemented method with initial requirement
	 * 
	 * =============================================================================
	 * ==============
	 */
	/**
	 * <p style="font-family:Arial;">
	 * <b>DESCRIPTION: This method is used validate object count based on provided
	 * comparision option <br>
	 * <br>
	 * Author: - ACOE Team <br>
	 * <br>
	 * Date Created: 05/03/2019 <br>
	 * <br>
	 * Revision History: <br>
	 * 1.0: Define method and added initial code <br>
	 * 
	 * @param Object
	 *            of class ExecutionContext
	 * @return No Return Value
	 * @throws Exception
	 *             If any error occurs, reports the exception message and log the
	 *             full exception trace in log file </b>
	 *             </P>
	 * 
	 */
	public static boolean validate_Object_Count(ExecutionContext executionContext) throws Exception {
		String objectXPath = executionContext.getCurrentElementXPath();
		String data = executionContext.getCurrentElementData();
		String actualResult = "No object found with locator " + objectXPath;
		String expectedResult = "Object count should be validated with expected object count " + data;
		boolean status = false;
		try {
			List<WebElement> elements = findElements(executionContext.getDriver(), objectXPath);
			int expectedcount = 0;
			String validationOperation = "EQUAL";
			if (!(data == null || data.equalsIgnoreCase(""))) {
				String[] d = data.split(":");
				if (d.length > 1) {
					try {
						expectedcount = Integer.parseInt(d[0]);
					} catch (Exception e) {
					}
					validationOperation = d[1];
					expectedResult = "Expected object count with locator " + objectXPath + "is: " + expectedcount
							+ "and validation operation is " + validationOperation;
					if (d[1].equalsIgnoreCase("EQUAL")) {
						if (expectedcount == elements.size()) {
							status = true;
						}
					} else if (d[1].equalsIgnoreCase("NOTEQUAL")) {
						if (expectedcount != elements.size()) {
							status = true;
						}
					} else if (d[1].equalsIgnoreCase("LESS")) {
						if (expectedcount > elements.size()) {
							status = true;
						}
					} else if (d[1].equalsIgnoreCase("LESSTHAN")) {
						if (expectedcount > elements.size()) {
							status = true;
						}
					} else if (d[1].equalsIgnoreCase("GREATER")) {
						if (expectedcount < elements.size()) {
							status = true;
						}
					} else if (d[1].equalsIgnoreCase("GREATERTHAN")) {
						if (expectedcount < elements.size()) {
							status = true;
						}
					}
				} else {
					try {
						expectedcount = Integer.parseInt(d[0]);
					} catch (Exception e) {
					}
					if (expectedcount == elements.size()) {
						status = true;
					}
				}
			}
			actualResult = "Actual object count with locator " + objectXPath + " is " + elements.size()
					+ " and validation operation is " + validationOperation;

		} catch (Exception e) {
			ExceptionHandler.handleException(e);
			actualResult = actualResult + ". " + e.getMessage();
		}
		ReportUtility.reportStepStatus(executionContext, expectedResult, actualResult, status);return status;
				

	}

	/*
	 * =============================================================================
	 * ============== Function Name: switch_To_Window CREATED BY: ACOE Team CREATED
	 * DATE: 05/03/2019 DESCRIPTION: This method is used switch to window based on
	 * provided window title Parameter: Object of class ExecutionContext RETURNS:
	 * Nothing COMMENTS: Modification Log: Revision: 1.0 Date: 05/03/2019 Comment:
	 * Implemented method with initial requirement
	 * 
	 * =============================================================================
	 * ==============
	 */
	/**
	 * <p style="font-family:Arial;">
	 * <b>DESCRIPTION: This method is used switch to window based on provided window
	 * title <br>
	 * <br>
	 * Author: - ACOE Team <br>
	 * <br>
	 * Date Created: 05/03/2019 <br>
	 * <br>
	 * Revision History: <br>
	 * 1.0: Define method and added initial code <br>
	 * 
	 * @param Object
	 *            of class ExecutionContext
	 * @return No Return Value
	 * @throws Exception
	 *             If any error occurs, reports the exception message and log the
	 *             full exception trace in log file </b>
	 *             </P>
	 * 
	 */
	public static boolean switch_To_Window(ExecutionContext executionContext) {
		String data = executionContext.getCurrentElementData();
		String expectedResult = "Driver should switch to window with title " + data + "";
		String actualResult = "Driver is not switched to window with title " + data + "";
		boolean status = false;
		try {
			String defaultTitle = executionContext.getDriver().getWindowHandle();
			if (data == null || data.equalsIgnoreCase("")) {
				actualResult = "Data is required to switch to window, no data specified. Provided Data: " + data
						+ "";
			} else {
				Set<String> handles = executionContext.getDriver().getWindowHandles();
				for (String title : handles) {
					executionContext.getDriver().switchTo().window(title);
					String currentTitle = executionContext.getDriver().getTitle();
					Log.writeToLogFile("Current Window Title: " + currentTitle);
					Log.writeToLogFile("Expected Window Title: " + data);
					if (currentTitle.toLowerCase().contains(data.toLowerCase())) {
						executionContext.getDriver().switchTo().window(title);
						actualResult = "Driver is switched to window with " + title + " successfully";
						status = true;
						break;
					}
				}
			}
			if (!status) {
				executionContext.getDriver().switchTo().window(defaultTitle);
			}
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
			actualResult = actualResult + ". " + e.getMessage();
		}
		ReportUtility.reportStepStatus(executionContext, expectedResult, actualResult, status);return status;
				
	}

	/*
	 * =============================================================================
	 * ============== Function Name: switch_To_Last_Window CREATED BY: ACOE Team
	 * CREATED DATE: 05/03/2019 DESCRIPTION: This method is used to switch to last
	 * window Parameter: Object of class ExecutionContext RETURNS: Nothing COMMENTS:
	 * Modification Log: Revision: 1.0 Date: 05/03/2019 Comment: Implemented method
	 * with initial requirement
	 * 
	 * =============================================================================
	 * ==============
	 */
	/**
	 * <p style="font-family:Arial;">
	 * <b>DESCRIPTION: This method is used to switch to last window <br>
	 * <br>
	 * Author: - ACOE Team <br>
	 * <br>
	 * Date Created: 05/03/2019 <br>
	 * <br>
	 * Revision History: <br>
	 * 1.0: Define method and added initial code <br>
	 * 
	 * @param Object
	 *            of class ExecutionContext
	 * @return No Return Value
	 * @throws Exception
	 *             If any error occurs, reports the exception message and log the
	 *             full exception trace in log file </b>
	 *             </P>
	 * 
	 */
	public static boolean switch_To_Last_Window(ExecutionContext executionContext) throws Exception {
		String expectedResult = "Driver should switch to last window";
		String actualResult = "Driver is not switched to last window";
		boolean status = false;
		try {
			Set<String> handles = executionContext.getDriver().getWindowHandles();
			int j = 1;
			String handle = "";
			for (String s : handles) {
				handle = s;
				j++;
			}
			if (j > 1 && (!handle.equalsIgnoreCase(""))) {
				executionContext.getDriver().switchTo().window(handle);
				status = true;
				actualResult = "Driver is switched to last window";
			}

		} catch (Exception e) {
			ExceptionHandler.handleException(e);
			actualResult = actualResult + ". " + e.getMessage();
		}
		ReportUtility.reportStepStatus(executionContext, expectedResult, actualResult, status);return status;
				
	}

	/*
	 * =============================================================================
	 * ============== Function Name: switch_To_Window_By_Index CREATED BY: ACOE Team
	 * CREATED DATE: 05/03/2019 DESCRIPTION: This method is used to switch window by
	 * index Parameter: Object of class ExecutionContext RETURNS: Nothing COMMENTS:
	 * Modification Log: Revision: 1.0 Date: 05/03/2019 Comment: Implemented method
	 * with initial requirement
	 * 
	 * =============================================================================
	 * ==============
	 */
	/**
	 * <p style="font-family:Arial;">
	 * <b>DESCRIPTION: This method is used to switch window by index <br>
	 * <br>
	 * Author: - ACOE Team <br>
	 * <br>
	 * Date Created: 05/03/2019 <br>
	 * <br>
	 * Revision History: <br>
	 * 1.0: Define method and added initial code <br>
	 * 
	 * @param Object
	 *            of class ExecutionContext
	 * @return No Return Value
	 * @throws Exception
	 *             If any error occurs, reports the exception message and log the
	 *             full exception trace in log file </b>
	 *             </P>
	 * 
	 */
	public static boolean switch_To_Window_By_Index(ExecutionContext executionContext) throws Exception {
		String data = executionContext.getCurrentElementData();
		String expectedResult = "Driver should switch to window with index " + data;
		String actualResult = "Driver is not switched to window with index " + data;
		boolean status = false;
		try {
			int index = -1;
			try {
				index = Integer.parseInt(data);
			} catch (Exception e) {
				
				actualResult = "Driver is not switched to window with index " + data
						+ ". Index should be integer value greater than 0";
			}
			if (index > 0) {
				Set<String> handles = executionContext.getDriver().getWindowHandles();
				int j = 1;
				for (String s : handles) {
					if (j == index) {
						executionContext.getDriver().switchTo().window(s);
						status = true;
						actualResult = "Driver is switched to window with index " + data + "";
						break;
					}
					j++;
				}
			} else {
				actualResult = "Driver is not switched to window with index " + data
						+ ". Index should be integer value greater than 0";
			}
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
			actualResult = actualResult + ". " + e.getMessage();
		}
		ReportUtility.reportStepStatus(executionContext, expectedResult, actualResult, status);return status;
				
	}
	
	/*
	 * =============================================================================
	 * Function Name: switch_To_Child_Browser_Window_ByTitle CREATED BY: ACOE Team
	 * CREATED DATE: 05/03/2019 DESCRIPTION: This method is used to switch window by
	 * title Parameter: Object of class ExecutionContext RETURNS: Nothing COMMENTS:
	 * Modification Log: Revision: 1.0 Date: 05/03/2019 Comment: Implemented method
	 * with initial requirement
	 * 
	 * =============================================================================
	 * ==============
	 */
	/**
	 * <p style="font-family:Arial;">
	 * <b>DESCRIPTION: This method is used to switch window by title <br>
	 * <br>
	 * Author: - ACOE Team <br>
	 * <br>
	 * Date Created: 05/03/2019 <br>
	 * <br>
	 * Revision History: <br>
	 * 1.0: Define method and added initial code <br>
	 * 
	 * @param Object
	 *            of class ExecutionContext
	 * @return No Return Value
	 * @throws Exception
	 *             If any error occurs, reports the exception message and log the
	 *             full exception trace in log file </b>
	 *             </P>
	 * 
	 */
	
	public static boolean switch_To_Child_Browser_Window_ByTitle(ExecutionContext executionContext) {

		String data = executionContext.getCurrentElementData();
		boolean status = false;

		String expectedResult = "Driver should switch to window with title " + data;
		String actualResult = "Driver is not switched to window with title " + data;

		try {

			for (String winHandle : executionContext.getDriver().getWindowHandles()) {

				executionContext.getDriver().switchTo().window(winHandle);

				Log.writeToLogFile(executionContext.getDriver().getTitle());

				if ((executionContext.getDriver().getTitle()).contains(data)) {
					status = true;
					actualResult = "Driver is successfully switched to window with title " + data;

					break;
				} else {
					status = false;

				}
			}
			if (!status) {
				actualResult = "Driver could not find any child window with title " + data;
			}
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
			actualResult = actualResult + ". " + e.getMessage();
		}
		ReportUtility.reportStepStatus(executionContext, expectedResult, actualResult, status);return status;
	}

	/*
	 * =============================================================================
	 * ============== Function Name: is_Object_Enabled CREATED BY: ACOE Team CREATED
	 * DATE: 05/03/2019 DESCRIPTION: This method is used object is enabled
	 * Parameter: Object of class ExecutionContext RETURNS: Nothing COMMENTS:
	 * Modification Log: Revision: 1.0 Date: 05/03/2019 Comment: Implemented method
	 * with initial requirement
	 * 
	 * =============================================================================
	 * ==============
	 */
	/**
	 * <p style="font-family:Arial;">
	 * <b>DESCRIPTION: This method is used object is enabled <br>
	 * <br>
	 * Author: - ACOE Team <br>
	 * <br>
	 * Date Created: 05/03/2019 <br>
	 * <br>
	 * Revision History: <br>
	 * 1.0: Define method and added initial code <br>
	 * 
	 * @param Object
	 *            of class ExecutionContext
	 * @return No Return Value
	 * @throws Exception
	 *             If any error occurs, reports the exception message and log the
	 *             full exception trace in log file </b>
	 *             </P>
	 * 
	 */
	public static boolean is_Object_Enabled(ExecutionContext executionContext) throws Exception {
		String objectXPath = executionContext.getCurrentElementXPath();
		String actualResult = "Object with locator " + objectXPath + " is not found";
		String expectedResult = "Object with locator " + objectXPath + " is found and enabled";
		boolean status = false;
		try {
			List<WebElement> elements = findElements(executionContext.getDriver(), objectXPath);
			if (elements.size() > 0) {
				if (elements.get(0).isEnabled()) {
					actualResult = "Object with locator " + objectXPath + " is found and enabled";
					status = true;
				} else {
					actualResult = "Object " + objectXPath + " is found and disabled";
				}
			}
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
			actualResult = actualResult + ". " + e.getMessage();
		}
		ReportUtility.reportStepStatus(executionContext, expectedResult, actualResult, status);return status;
				
	}

	/*
	 * =============================================================================
	 * ============== Function Name: is_Object_Disabled CREATED BY: ACOE Team
	 * CREATED DATE: 05/03/2019 DESCRIPTION: This method is used to validate object
	 * is disabled Parameter: Object of class ExecutionContext RETURNS: Nothing
	 * COMMENTS: Modification Log: Revision: 1.0 Date: 05/03/2019 Comment:
	 * Implemented method with initial requirement
	 * 
	 * =============================================================================
	 * ==============
	 */
	/**
	 * <p style="font-family:Arial;">
	 * <b>DESCRIPTION: This method is used to validate object is disabled <br>
	 * <br>
	 * Author: - ACOE Team <br>
	 * <br>
	 * Date Created: 05/03/2019 <br>
	 * <br>
	 * Revision History: <br>
	 * 1.0: Define method and added initial code <br>
	 * 
	 * @param Object
	 *            of class ExecutionContext
	 * @return No Return Value
	 * @throws Exception
	 *             If any error occurs, reports the exception message and log the
	 *             full exception trace in log file </b>
	 *             </P>
	 * 
	 */
	public static boolean is_Object_Disabled(ExecutionContext executionContext) throws Exception {
		String objectXPath = executionContext.getCurrentElementXPath();
		String actualResult = "Object with locator " + objectXPath + " is not found";
		String expectedResult = "Object with locator " + objectXPath + " should be found and disabled";
		boolean status = false;
		try {
			List<WebElement> elements = findElements(executionContext.getDriver(), objectXPath);
			if (elements.size() > 0) {
				if (elements.get(0).isEnabled()) {
					actualResult = "Object with locator " + objectXPath + " is found and enabled";
				} else {
					actualResult = "Object with locator " + objectXPath + " is found and disabled";
					status = true;
				}
			}
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
			actualResult = actualResult + ". " + e.getMessage();
		}
		ReportUtility.reportStepStatus(executionContext, expectedResult, actualResult, status);return status;
				
	}

	/*
	 * =============================================================================
	 * ============== Function Name: wait CREATED BY: ACOE Team CREATED DATE:
	 * 05/03/2019 DESCRIPTION: This method is used perform hard wait for specified
	 * time (Default is 5000 MS) Parameter: Object of class ExecutionContext
	 * RETURNS: Nothing COMMENTS: Modification Log: Revision: 1.0 Date: 05/03/2019
	 * Comment: Implemented method with initial requirement
	 * 
	 * =============================================================================
	 * ==============
	 */
	/**
	 * <p style="font-family:Arial;">
	 * <b>DESCRIPTION: This method is used perform hard wait for specified time
	 * (Default is 5000 MS) <br>
	 * <br>
	 * Author: - ACOE Team <br>
	 * <br>
	 * Date Created: 05/03/2019 <br>
	 * <br>
	 * Revision History: <br>
	 * 1.0: Define method and added initial code <br>
	 * 
	 * @param Object
	 *            of class ExecutionContext
	 * @return No Return Value
	 * @throws Exception
	 *             If any error occurs, reports the exception message and log the
	 *             full exception trace in log file </b>
	 *             </P>
	 * 
	 */
	public static boolean wait(ExecutionContext executionContext) throws Exception {
		String data = executionContext.getCurrentElementData();
		String expectedResult = "Hard wait for 5000 MS should be performed";
		String actualResult = "Hard wait for 5000 MS is not performed";
		boolean status = false;
		try {
			long waitTime = 5000;
			if (!(data == null || data.equalsIgnoreCase(""))) {
				try {
					waitTime = Integer.parseInt(data);
				} catch (Exception e) {
					ExceptionHandler.handleException(e);
				}
			}
			expectedResult = "Hard wait for " + waitTime + " MS should be performed";
			actualResult = "Hard wait for " + waitTime + " MS is not performed";
			Thread.sleep(waitTime);
			status = true;
			actualResult = "Hard wait for " + waitTime + " MS is performed";
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
			actualResult = actualResult + ". " + e.getMessage();
		}
		ReportUtility.reportStepStatus(executionContext, expectedResult, actualResult, status);return status;
				
	}

	/*
	 * =============================================================================
	 * ============== Function Name: close_Browser CREATED BY: ACOE Team CREATED
	 * DATE: 05/03/2019 DESCRIPTION: This method is used close the browser
	 * Parameter: Object of class ExecutionContext RETURNS: Nothing COMMENTS:
	 * Modification Log: Revision: 1.0 Date: 05/03/2019 Comment: Implemented method
	 * with initial requirement
	 * 
	 * =============================================================================
	 * ==============
	 */
	/**
	 * <p style="font-family:Arial;">
	 * <b>DESCRIPTION: This method is used close the browser <br>
	 * <br>
	 * Author: - ACOE Team <br>
	 * <br>
	 * Date Created: 05/03/2019 <br>
	 * <br>
	 * Revision History: <br>
	 * 1.0: Define method and added initial code <br>
	 * 
	 * @param Object
	 *            of class ExecutionContext
	 * @return No Return Value
	 * @throws Exception
	 *             If any error occurs, reports the exception message and log the
	 *             full exception trace in log file </b>
	 *             </P>
	 * 
	 */
	public static boolean close_Browser(ExecutionContext executionContext) throws Exception {
		String expectedResult = "Browser should be closed successfully";
		String actualResult = "Browser is not closed successfully";
		boolean status = false;
		try {
			try{executionContext.getDriver().close();}catch(Exception e) {ExceptionHandler.handleException(e);}
			status = true;
			actualResult = "Browser is closed successfully";
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
			actualResult = actualResult + ". " + e.getMessage();
		}
		ReportUtility.reportStepStatusWithoutScreenshot(executionContext, expectedResult, actualResult, status); return status;	
	}

	/*
	 * =============================================================================
	 * ============== Function Name: select_Radio_Button CREATED BY: ACOE Team
	 * CREATED DATE: 05/03/2019 DESCRIPTION: This method is used select radio button
	 * Parameter: Object of class ExecutionContext RETURNS: Nothing COMMENTS:
	 * Modification Log: Revision: 1.0 Date: 05/03/2019 Comment: Implemented method
	 * with initial requirement
	 * 
	 * =============================================================================
	 * ==============
	 */
	/**
	 * <p style="font-family:Arial;">
	 * <b>DESCRIPTION: This method is used select radio button <br>
	 * <br>
	 * Author: - ACOE Team <br>
	 * <br>
	 * Date Created: 05/03/2019 <br>
	 * <br>
	 * Revision History: <br>
	 * 1.0: Define method and added initial code <br>
	 * 
	 * @param Object
	 *            of class ExecutionContext
	 * @return No Return Value
	 * @throws Exception
	 *             If any error occurs, reports the exception message and log the
	 *             full exception trace in log file </b>
	 *             </P>
	 * 
	 */
	public static boolean select_Radio_Button(ExecutionContext executionContext) throws Exception {
		String objectXPath = executionContext.getCurrentElementXPath();
		String actualResult = "Radio button with object locator " + objectXPath + " is not selected";
		String expectedResult = "Radio button with locator " + objectXPath + " should be selected";
		boolean status = false;
		try {
			List<WebElement> elements = findElements(executionContext.getDriver(), objectXPath);
			if (elements != null && elements.size() > 0) {
				if (!elements.get(0).isSelected()) {
					elements.get(0).click();
				}
				elements = findElements(executionContext.getDriver(), objectXPath);
				if (!elements.get(0).isSelected()) {
					elements.get(0).click();
				}
				elements = findElements(executionContext.getDriver(), objectXPath);
				if (elements.get(0).isSelected()) {
					status = true;
					actualResult = "Radio button with locator " + objectXPath + " is selected";
				} else {
					actualResult = "Radio button with object locator " + objectXPath + " is not selected";
				}
			} else {
				actualResult = "No object found with locator " + objectXPath;
			}

		} catch (Exception e) {
			ExceptionHandler.handleException(e);
			actualResult = actualResult + ". " + e.getMessage();
		}
		ReportUtility.reportStepStatus(executionContext, expectedResult, actualResult, status);return status;
				

	}

	/*
	 * =============================================================================
	 * ============== Function Name: deselect_Checkbox CREATED BY: ACOE Team CREATED
	 * DATE: 05/03/2019 DESCRIPTION: This method is used de-select checkbox if it is
	 * selected Parameter: Object of class ExecutionContext RETURNS: Nothing
	 * COMMENTS: Modification Log: Revision: 1.0 Date: 05/03/2019 Comment:
	 * Implemented method with initial requirement
	 * 
	 * =============================================================================
	 * ==============
	 */
	/**
	 * <p style="font-family:Arial;">
	 * <b>DESCRIPTION: This method is used de-select checkbox if it is selected <br>
	 * <br>
	 * Author: - ACOE Team <br>
	 * <br>
	 * Date Created: 05/03/2019 <br>
	 * <br>
	 * Revision History: <br>
	 * 1.0: Define method and added initial code <br>
	 * 
	 * @param Object
	 *            of class ExecutionContext
	 * @return No Return Value
	 * @throws Exception
	 *             If any error occurs, reports the exception message and log the
	 *             full exception trace in log file </b>
	 *             </P>
	 * 
	 */
	public static boolean deselect_Checkbox(ExecutionContext executionContext) {
		String objectXPath = executionContext.getCurrentElementXPath();
		String actualResult = "Checkbox object with locator " + objectXPath + " is not found";
		String expectedResult = "Checkbox object with locator " + objectXPath + " should not be selected";
		boolean status = false;
		try {
			for (int i = 0; i < 2; i++) {
				List<WebElement> elements = findElements(executionContext.getDriver(), objectXPath);
				if (elements != null && elements.size() > 0) {
					if (elements.get(0).isSelected()) {
						elements.get(0).click();
					}
					elements = findElements(executionContext.getDriver(), objectXPath);
					if (!elements.get(0).isSelected()) {
						status = true;
						actualResult = "Checkbox object with locator " + objectXPath + " is not selected";
						break;
					} else {
						Thread.sleep(1000);
					}
				}
			}
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
			actualResult = actualResult + ". " + e.getMessage();
		}
		ReportUtility.reportStepStatus(executionContext, expectedResult, actualResult, status);return status;
				
	}

	/*
	 * =============================================================================
	 * ============== Function Name: select_Checkbox CREATED BY: ACOE Team CREATED
	 * DATE: 05/03/2019 DESCRIPTION: This method is used select checkbox if it is
	 * not selected Parameter: Object of class ExecutionContext RETURNS: Nothing
	 * COMMENTS: Modification Log: Revision: 1.0 Date: 05/03/2019 Comment:
	 * Implemented method with initial requirement
	 * 
	 * =============================================================================
	 * ==============
	 */
	/**
	 * <p style="font-family:Arial;">
	 * <b>DESCRIPTION: This method is used select checkbox if it is not seelcted
	 * <br>
	 * <br>
	 * Author: - ACOE Team <br>
	 * <br>
	 * Date Created: 05/03/2019 <br>
	 * <br>
	 * Revision History: <br>
	 * 1.0: Define method and added initial code <br>
	 * 
	 * @param Object
	 *            of class ExecutionContext
	 * @return No Return Value
	 * @throws Exception
	 *             If any error occurs, reports the exception message and log the
	 *             full exception trace in log file </b>
	 *             </P>
	 * 
	 */
	public static boolean select_Checkbox(ExecutionContext executionContext) {
		String objectXPath = executionContext.getCurrentElementXPath();
		String actualResult = "Checkbox object with locator " + objectXPath + " is not selected";
		String expectedResult = "Checkbox object with locator " + objectXPath + " should be selected";
		boolean status = false;
		try {
			for (int i = 0; i < 2; i++) {
				List<WebElement> elements = findElements(executionContext.getDriver(), objectXPath);
				if (elements != null && elements.size() > 0) {
					if (!elements.get(0).isSelected()) {
						elements.get(0).click();
					}
					elements = findElements(executionContext.getDriver(), objectXPath);
					if (elements.get(0).isSelected()) {
						status = true;
						actualResult = "Checkbox object with locator " + objectXPath + " is selected";
						break;
					} else {
						Thread.sleep(1000);
					}

				} else {
					actualResult = "No object found with locator " + objectXPath;
				}
			}
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
			actualResult = actualResult + ". " + e.getMessage();
		}
		ReportUtility.reportStepStatus(executionContext, expectedResult, actualResult, status);return status;
				

	}
	/*
	 * =============================================================================
	 * ============== Function Name: Select_Multichoice_Answers 
	 * CREATED BY: ACOE Team 
	 * DATE: 05/03/2019 DESCRIPTION: This method is used select multi-choice answers 
	 * if  these are not selected
	 * Parameter: Object of class ExecutionContext 
	 * RETURNS: boolean status
	 * COMMENTS: Modification Log: Revision: 1.0 Date: 05/03/2019 Comment:
	 * Implemented method with initial requirement
	 * 
	 * =============================================================================
	 * ==============
	 */
	/**
	 * <p style="font-family:Arial;">
	 * <b>DESCRIPTION: This method is used select multi-choice answers if  these are not selected
	 * <br>
	 * <br>
	 * Author: - ACOE Team <br>
	 * <br>
	 * Date Created: 05/03/2019 <br>
	 * <br>
	 * Revision History: <br>
	 * 1.0: Define method and added initial code <br>
	 * 
	 * @param Object
	 *            of class ExecutionContext
	 * @return No Return Value
	 * @throws Exception
	 *             If any error occurs, reports the exception message and log the
	 *             full exception trace in log file </b>
	 *             </P>
	 * 
	 */
	
	public static boolean Select_Multichoice_Answers(ExecutionContext executionContext) {

		String objectXPath = executionContext.getCurrentElementXPath();
		String data = executionContext.getCurrentElementData();
		boolean status = false;
		
		String expectedResult ="Multichoice_Answer with locator " + objectXPath + " and data "+data+" should be selected";
		String actualResult = "Multichoice_Answer with locator " + objectXPath + " and data "+data+" is not selected";
		
		try {
			
			List<WebElement> elementList = executionContext.getDriver().findElements(By.xpath(objectXPath));

			if (elementList.size() > 0 && data != null) {

				if (data.contains(";")) {

					String sValuesToCheck[] = data.split(";");

					for (String s : sValuesToCheck) {

						for (WebElement e : elementList) {

							if (e.getText().trim().toLowerCase().contains(s.trim().toLowerCase())) {

								e.click();
								status=true;
								Log.writeToLogFile("Multichoice_Answer with locator " + objectXPath + " and data "+s+" is selected");
								break;
							}
						}
					}

				} else {

					for (WebElement e : elementList) {

						if (e.getText().trim().toLowerCase().contains(data.trim().toLowerCase())) {

							e.click();
							status=true;
							Log.writeToLogFile("Multichoice_Answer with locator " + objectXPath + " and data "+data+" is selected");
							break;
						}

					}
				}
				if(status)
					actualResult = "Multichoice_Answer/s with locator " + objectXPath + " and data "+data+" is/are selected successfully";
			}
			else
				actualResult = "Either elemnt could not be found with locator " + objectXPath + " or data is null: data retrieved is: "+data;
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
			actualResult = actualResult + ". " + e.getMessage();
		}
		ReportUtility.reportStepStatus(executionContext, expectedResult, actualResult, status);return status;

	}

	/**
	 * <p style="font-family:Arial;">
	 * <b>Method Name:INPUT</b> <b>Method Description: This method retrieves text
	 * w.r.t. locator type Author: - Nitesh Jangid <br>
	 * <br>
	 * Date Created: Apr-2019 <br>
	 * <br>
	 * Revision History: <br>
	 * 1.0: Define method and added initial code <br>
	 * 
	 * @param driver,executionContext,scenario
	 * @return No Return Value
	 * @throws Exception
	 *             If any error if not able to input an value </b>
	 *             </P>
	 */
	public static String retrieveText(ExecutionContext executionContext) {
		String expectedResult = "Text should be retrieved";
		String actualResult = "Text is not retrieved";
		boolean status = false;
		String text="";
		try {
			String objectXPath = executionContext.getCurrentElementXPath();
			String data = executionContext.getCurrentElementData();
			if (data == null || data.equalsIgnoreCase("")) {

			} else {
				objectXPath = objectXPath.replaceAll("####", data);
			}
			expectedResult = "Text for object '" + objectXPath + "' should be retrieved";
			List<WebElement> elements = findElements(executionContext.getDriver(), objectXPath);
			if (!(elements == null || elements.size() <= 0)) {
				text=elements.get(0).getText();
				status = true;
				actualResult = "Text for object " + objectXPath + " is retrieved and object text is "+text;
			} else {
				actualResult = "Text for object " + objectXPath + " is not retrieved. Element could not be found with xPath '"
						+ objectXPath + "'";
			}
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
			actualResult = actualResult + ". " + e.getMessage();
		}
		ReportUtility.reportStepStatus(executionContext, expectedResult, actualResult, status);
		return text;
	}
	
	/**
	 * <p style="font-family:Arial;">
	 * <b>Method Name:retrieveAttribute</b> <b>Method Description: This method retrieves attribute
	 * w.r.t. locator type Author: - Nitesh Jangid <br>
	 * <br>
	 * Date Created: Apr-2019 <br>
	 * <br>
	 * Revision History: <br>
	 * 1.0: Define method and added initial code <br>
	 * 
	 * @param driver,executionContext,scenario
	 * @return No Return Value
	 * @throws Exception
	 *             If any error if not able to input an value </b>
	 *             </P>
	 */
	
	public static String retrieveAttribute(ExecutionContext executionContext) {
		String expectedResult = "Attribute should be retrieved";
		String actualResult = "Attribute is not retrieved";
		String value="";
		boolean status = false;
		try {
			String objectXPath = executionContext.getCurrentElementXPath();
			String data = executionContext.getCurrentElementData();
			if (data == null || data.equalsIgnoreCase("")) {
				
			} else {
				//objectXPath = objectXPath.replaceAll("####", data);
			}
			expectedResult = "Attribute for object '" + objectXPath + "' should be retrieved";
			List<WebElement> elements = findElements(executionContext.getDriver(), objectXPath);
			if (!(elements == null || elements.size() <= 0)) {
				value=elements.get(0).getAttribute(data);
				status = true;
				actualResult = "Attribute "+data+" for object " + objectXPath + " is retrieved and value of attaribute "+data+" is: "+value;
			} else {
				actualResult = "Attribute "+data+" for object " + objectXPath + " is not retrieved. Element could not be found with xPath '"
						+ objectXPath + "'";
			}
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
			actualResult = actualResult + ". " + e.getMessage();
		}
		ReportUtility.reportStepStatus(executionContext, expectedResult, actualResult, status);
		return value;		
	}
	
	/*
	 * Method Name: click_Java_Script
	 * Method Description: This method is used to click on first found object using java script
	 * Modified BY: ACOE Team
	 * Parameter: Object of executionContext
	 * Return: None
	 * Created On: May 2019
	 * Revision History: 
	 * 1.0: Define method and added initial code
	 */
	/** 
	 * <p style="font-family:Arial;">
	 * <b>Method Description: This method is used to click on first found object using java script
	 * <br><br>
	 * Author: ACOE Team
	 * <br><br>
	 * Date Created: May 2019
	 * <br><br>Revision History: 
	 * <br>1.0: Define method and added initial code
	 * <br>
	 * Return: First found object should be clicked
	 * @param  Object of executionContext
	 * @return No Return Value
	 * @throws Exception  If any error reports the MD.exception message and sets bOperationStatus as false for reporting and log the full MD.exception trace in log file
	 * </b></P> 
	 * 
	 */
	public static boolean click_Java_Script(ExecutionContext executionContext) 
	{
		String objectXPath = executionContext.getCurrentElementXPath();
		String logActualMessage="Object with locator "+objectXPath+" is not found";
		String logExpectedMessage="Object with locator "+objectXPath+" should be clicked";
		boolean status=false;
		try{
		List<WebElement> elements=findElements(executionContext.getDriver(), objectXPath);
		if(elements!=null && elements.size()>0){
			((JavascriptExecutor)executionContext.getDriver()).executeScript("var el = arguments[0];setTimeout(function(){el.click();},100);",elements.get(0));
			Thread.sleep(2000);
			status=true;
			logActualMessage="Object with locator "+objectXPath+" is clicked";
		}
		}catch (Exception e) {
			ExceptionHandler.handleException(e);
			logActualMessage = logActualMessage + ". " + e.getMessage();
		}
		ReportUtility.reportStepStatus(executionContext, logExpectedMessage, logActualMessage, status); return status;
	}
	
	/*
	 * Method Name: input_Java_Script 
	 * Method Description: This method is used to input data in specified object using JAVA Script
	 * Author: ACOE Team
	 * Parameter: Object of executionContext
	 * Return: None
	 * Created On: May 2019
	 * Revision History: 
	 * 1.0: Define method and added initial code
	 */
	/** 
	 * <p style="font-family:Arial;">
	 * <b>Method Description: This method is used to input data in specified object using JAVA Script
	 * <br><br>
	 * Author: ACOE Team
	 * <br><br>
	 * Date Created: May 2019
	 * <br><br>Revision History: 
	 * <br>1.0: Define method and added initial code
	 * <br>
	 * Return: Data should be inputted in specified object
	 * @param  Object of executionContext
	 * @return No Return Value
	 * @throws Exception  If any error reports the MD.exception message and sets bOperationStatus as false for reporting and log the full MD.exception trace in log file
	 * </b></P> 
	 * 
	 */
	public static boolean input_Java_Script(ExecutionContext executionContext) 
	{
		String objectXPath = executionContext.getCurrentElementXPath();
		String data = executionContext.getCurrentElementData();
		String logActualMessage="Data "+data+" is not entered in object with locator "+objectXPath+" as no object found with provided xPath";
		String logExpectedMessage="Data "+data+" should be entered in object in object with locator "+objectXPath;
		boolean status=false;
		try{
			List<WebElement> elements=findElements(executionContext.getDriver(), objectXPath);
			if(elements!=null && elements.size()>0){
				if(data==null || data.equalsIgnoreCase("")){
					elements.get(0).clear();
					Log.writeToLogFile("Trying to input with the help of java script");
					JavascriptExecutor executor = (JavascriptExecutor)executionContext.getDriver();				
					executor.executeScript("arguments[0].value='"+data+"';", elements.get(0));
					String enteredData=elements.get(0).getAttribute("value");
					if(enteredData!=null && (!enteredData.equalsIgnoreCase(data))){
						executor.executeScript("arguments[0].value='"+data+"';", elements.get(0));
					}

					enteredData=elements.get(0).getAttribute("value");
					Log.writeToLogFile("Entered Value using Java Script: "+enteredData);
					logActualMessage="Data "+data+" is entered in object with locator "+objectXPath;
					status=true;					
				}
			}				
		}catch (Exception e) {
			ExceptionHandler.handleException(e);
			logActualMessage = logActualMessage + ". " + e.getMessage();
		}
		ReportUtility.reportStepStatus(executionContext, logExpectedMessage, logActualMessage, status); return status;
	}
	/*===============================================================================================================================
	Function Name:              clickByBrowser
	CREATED BY:                 Nitesh Jangid
	DATE CREATED:               05/26/2016
	DESCRIPTION:                 This function clicks according to browser
	PARAMETERS:                
	RETURNS:          <No Return Value>                         
	COMMENTS:                                                                                    
	Modification Log:
	Date                                     Initials                                                       Modification
	-------------        ------------    ------------------------------------------------------------------------------------------------------------------------------*/
	/** 
	 * <p style="font-family:Arial;">
	 * <b>Method Description: This function clicks according to browser
	 * <br><br>
	 * Author: ACOE Team
	 * <br><br>
	 * Date Created: May 2019
	 * <br><br>Revision History: 
	 * <br>1.0: Define method and added initial code
	 * <br>
	 * Return: Data should be inputted in specified object
	 * @param  Object of executionContext
	 * @return No Return Value
	 * </b></P> 
	 * 
	 */
	public  boolean clickByBrowser(ExecutionContext executionContext)
	{
		boolean status=false;
		try {
			if(ExecutionContext.getBrowser().equalsIgnoreCase("IE"))
				click_Java_Script(executionContext);
			else
				click(executionContext);
			status=true;
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
		}
		return status;
	}
	/*
	 * Method Name: click_JavaScript
	 * Method Description: This method is used to click an object if it is exist
	 * Author: Mohammad Shahid Jamal
	 * Parameter: None
	 * Return: 
	 * Created On: Nov 2018
	 * Revision History: 
	 * 1.0: Define method and added initial code
	 */
	/** 
	 * <p style="font-family:Arial;">
	 * <b>Method Description: This method is used to click an object if it is exist
	 * <br><br>
	 * Author: - Mohammad Shahid Jamal
	 * <br><br>
	 * Date Created: Nov-2018
	 * <br><br>Revision History: 
	 * <br>1.0: Define method and added initial code
	 * <br>
	 * @param  No Parameters
	 * @return No Return Value
	 * @throws Exception  If any error reports the exception message and sets bOperationStatus as false for reporting and log the full exception trace in log file
	 * </b></P> 
	 * 
	 */
	public  boolean click_JavaScript(ExecutionContext executionContext) throws Exception
	{
		String expectedResult = "Object should be clicked";
		String actualResult = "Object is not clicked";
		boolean status = false;
		try {
			String objectXPath = executionContext.getCurrentElementXPath();
			String data = executionContext.getCurrentElementData();
			if (data == null || data.equalsIgnoreCase("")) {

			} else {
				objectXPath = objectXPath.replaceAll("####", data);
			}
			expectedResult = "Locator '" + objectXPath + "' should be clicked";
			List<WebElement> elements = findElements(executionContext.getDriver(), objectXPath);
			if (!(elements == null || elements.size() <= 0)) {
				((JavascriptExecutor) executionContext.getDriver()).executeScript("var el = arguments[0];setTimeout(function(){el.click();},100);",elements.get(0));
				actualResult = "Locator '" + objectXPath + "' is clicked";
				status = true;
			} else {
				actualResult = "Locator '" + objectXPath + "' is not clicked. Element could not be found with xPath '"
						+ objectXPath + "'";
			}
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
			actualResult = actualResult + ". " + e.getMessage();
		}
		ReportUtility.reportStepStatus(executionContext, expectedResult, actualResult, status);return status;
	}
	/*===============================================================================================================================
	  Function Name: 	CLOSECURRENTBROWSERTAB
	  CREATED BY: 		Ravi Kiran Kanala
	  DATE CREATED:  	May 2015
	  DESCRIPTION:		Closes the current opened browser tab                	                  
	  PARAMETERS: <No Parameters>
	  RETURNS: 	<No Return Value>		 
	  COMMENTS: 						
	  Modification Log:
	  Date         	                 Initials     	                                     Modification
	  
	  -------------    	------------    ------------------------------------------------------------------------------------------------------------------------------*/
	
	/** 
	 * <p style="font-family:Arial;">
	 * <b>Method Description - Closes the current opened browser tab
	 * <br>
	 * <br>
	 * Author - Ravi Kiran Kanala
	 * <br>
	 * <br>
	 * Date Created - May 2015
	 * </b>
	 * </P> 
	 * @param No Parameters
	 * @return No Return Value
	 * @throws Exception  If any error reports the exception message and sets bOperationStatus as false for reporting
	 * 
	 */
	public static boolean closeCurrentBrowserTabs(ExecutionContext executionContext) throws Exception {
		String expectedResult = "Object should be clicked";
		String actualResult = "Object is not clicked";
		boolean status = false;
		try {
			ArrayList<String> tabs = new ArrayList<String> (executionContext.getDriver().getWindowHandles());
			executionContext.getDriver().switchTo().window(tabs.get(0));
			executionContext.getDriver().findElement(By.cssSelector("body")).sendKeys(Keys.CONTROL +"w");
			Thread.sleep(200);
			expectedResult = "Browser tab should be closed";				
			actualResult = "Closed the browser tab";
			
		} catch(Exception e){			
			ExceptionHandler.handleException(e);
			actualResult = actualResult + ". " + e.getMessage();
		}
		ReportUtility.reportStepStatus(executionContext, expectedResult, actualResult, status);return status;
	} //public static boolean CLOSECURRENTBROWSERTAB(String Object) throws Exception {
	/*'=====================================End of CLOSECURRENTBROWSERTAB ============================================================================*/
	/*===============================================================================================================================
	  Function Name: 	closeWindow
	  CREATED BY: 		Ravi Kiran Kanala
	  DATE CREATED:  	May 2015
	  DESCRIPTION:		Identifies the child window,and closes the window                  
	  PARAMETERS: Value
	  RETURNS: 	<No Return Value>		 
	  COMMENTS: 						
	  Modification Log:
	  Date         	                 Initials     	                                     Modification
	  -------------    	------------    ------------------------------------------------------------------------------------------------------------------------------*/
	/** 
	 * <p style="font-family:Arial;">
	 * <b>Method Description - Identifies the child window,and closes the window
	 * <br>
	 * <br>
	 * Author - ACOE Team
	 * <br>
	 * <br>
	 * Date Created - May 2015
	 * </b>
	 * </P> 
	 * @param No Parameters
	 * @return No Return Value
	 * @throws Exception  If any error reports the exception message and sets bOperationStatus as false for reporting
	 * 
	 */
	public static boolean closeWindow (ExecutionContext executionContext) throws Exception {
		String expectedResult = "Object should be clicked";
		String actualResult = "Object is not clicked";
		String objectXPath = executionContext.getCurrentElementXPath();
		String data = executionContext.getCurrentElementData();
		boolean status = false;
		try{
			for(String winHandle : executionContext.getDriver().getWindowHandles()) {
				executionContext.getDriver().switchTo().window(winHandle);
				System.out.println(executionContext.getDriver().getTitle());
				if(data == null){
					if(executionContext.getDriver().findElements(By.xpath(objectXPath)).size()>0){
						if ((ExecutionContext.getBrowser().equalsIgnoreCase("FIREFOX")) || (ExecutionContext.getBrowser() .equalsIgnoreCase("IE") )){
							executionContext.getDriver().close();
							status = true;
							break;
						}else{
							//executionContext.getDriver().findElement(By.cssSelector("body")).sendKeys(Keys.CONTROL +"w");
							closeCurrentBrowserTabs(executionContext);
							status = true;
							break;
						}
					}
				}else if ((executionContext.getDriver().getTitle()).contains(data)) {
					if ((ExecutionContext.getBrowser().equalsIgnoreCase("FIREFOX")) || (ExecutionContext.getBrowser() .equalsIgnoreCase("IE") )){
						executionContext.getDriver().close();
						status = true;
						break;
					}else{
						//executionContext.getDriver().findElement(By.cssSelector("body")).sendKeys(Keys.CONTROL +"w");
						closeCurrentBrowserTabs(executionContext);
						status = true;
						break;
					}
				}else {
					//executionContext.getDriver().findElement(By.cssSelector("body")).sendKeys(Keys.CONTROL +"w");
					status = false;
				}
			}			
		}catch (Exception e) {
			ExceptionHandler.handleException(e);
			actualResult = actualResult + ". " + e.getMessage();
		}
		ReportUtility.reportStepStatus(executionContext, expectedResult, actualResult, status);return status;
	}
	/*'=====================================End of closeWindow ============================================================================*/
	/*================================================================================================================
	 Function Name:              navigateBack
	CREATED BY:                Shiva Khurana
	DATE CREATED:               14/03/2017
	DESCRIPTION:                 This function gets user to previous page
	PARAMETERS:                
	RETURNS:          <No Return Value>                         
	COMMENTS:                                                                                    
	Modification Log:
	Date                                     Initials                                                       Modification
	*/
	/** 
	 * <p style="font-family:Arial;">
	 * <b>Method Description - This function gets user to previous page
	 * <br>
	 * <br>
	 * Author - ACOE Team
	 * <br>
	 * <br>
	 * Date Created - May 2015
	 * </b>
	 * </P> 
	 * @param No Parameters
	 * @return No Return Value
	 * @throws Exception  If any error reports the exception message and sets bOperationStatus as false for reporting
	 * 
	 */
	public static boolean navigateBack(ExecutionContext executionContext) throws Exception {		
		String expectedResult = "Navigate back";
		String actualResult = "Did not navigate back";
		boolean status = false;
		try {
			executionContext.getDriver().navigate().back();
			actualResult = "navigated back";
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
			actualResult = actualResult + ". " + e.getMessage();
		}
		ReportUtility.reportStepStatus(executionContext, expectedResult, actualResult, status);return status;
	}
	/*===============================================================================================================================
	Function Name: 	selectListBox
	CREATED BY: 	Francis Erdman
	DATE CREATED:  	May 2018
	DESCRIPTION:    Selects list box option but does not fetch the option it selects after it is selected due to a spacing issue in the generic method for this action
	PARAMETERS: 	<No Parameters>									     
	RETURNS: 		<no return value>		 
	COMMENTS: 						
	Modification Log:
	Date         	                 Initials     	                                     Modification
	===============================================================================================================================*/
	/** 
	 * <p style="font-family:Arial;">
	 * <b>Method Description - Selects list box option but does not fetch the option it selects after it is selected due to a spacing issue in the generic method for this action
	 * <br>
	 * <br>
	 * Author - ACOE Team
	 * <br>
	 * <br>
	 * Date Created - May 2015
	 * </b>
	 * </P> 
	 * @param No Parameters
	 * @return No Return Value
	 * @throws Exception  If any error reports the exception message and sets bOperationStatus as false for reporting
	 * 
	 */
	public static boolean selectListBox(ExecutionContext executionContext) throws Exception
	{
		String objectXPath = executionContext.getCurrentElementXPath();
		String data = executionContext.getCurrentElementData();
		String expectedResult = "Navigate back";
		String actualResult = "Did not navigate back";
		boolean status = false;
		try{
			if (data == null || data.equalsIgnoreCase("")) {

			} else {
				objectXPath = objectXPath.replaceAll("####", data);
			}
			expectedResult = "Locator '" + objectXPath + "' should be clicked";
			List<WebElement> elements=findElements(executionContext.getDriver(), objectXPath);
			if(elements!=null && elements.size()>0){
				Select selectItem = new Select(elements.get(0));
				selectItem.selectByVisibleText(data);
			    actualResult="Option "+data+" is selected in listbox";
				status=true;
			}else{
				actualResult="No data specified. Data is required for selecting Option in listbox";
			}			
		}catch (Exception e) {
			ExceptionHandler.handleException(e);
			actualResult = actualResult + ". " + e.getMessage();
		}
		ReportUtility.reportStepStatus(executionContext, expectedResult, actualResult, status);return status;
	}
	 /**
	  * =========================================================================================== 
	  * Function Name: C_COMPAREELEMENTPROPERTY 
	  * CREATED BY: Mohammad Shahid Jamal
	  * CREATED DATE: 09-Dec-2016
	  * DESCRIPTION: This method is used to compare element property before and after the operation
	  * Parameter: This method accept string parameter
	  * RETURNS: Nothing
	  * COMMENTS: 
	  * Modification Log: 
	  * Revision: 1.0
	  * Date: 09-Dec-2016
	  * Comment: Implemented method with initial requirement
	  *  
	  * ===========================================================================================
	  */
	 public static  boolean compareElementProperty(ExecutionContext executionContext) {
		 String expectedResult = "Element property should match";
		  String actualResult = "Element property did not matc";
		 boolean status=false;  
	  try {
		  String xPath=executionContext.getCurrentElementXPath();
		  String Prop_State=executionContext.getRuntimeProperty();
		  String Prop_Name=executionContext.getCurrentElementData();
		  String Prop_Operation="==";
		  int tableRows=-1;
		  String Prop_Value="UnDefinedPropertyState";
	     
	   if(Prop_State.equalsIgnoreCase("ROWCOUNT"))
	   {
	    String xPath_Row = xPath + "/tr";
	    List<WebElement> elementList = executionContext.getDriver().findElements(By.xpath(xPath_Row));
	    tableRows = elementList.size();
	    Prop_Value=""+tableRows;
	   }
	   
	   if(Prop_State.equalsIgnoreCase("TEXT"))
	   {
	    List<WebElement> elements = executionContext.getDriver().findElements(By.xpath(xPath));
	    if (elements.size() != 0) {
	     Prop_Value = elements.get(0).getText();
	    } else {
	     Prop_Value = "null";
	    }
	   }  

	   if(Prop_State.equalsIgnoreCase("SIZE"))
	   {
	    List<WebElement> elements = executionContext.getDriver().findElements(By.xpath(xPath));
	    Prop_Value = ""+elements.size();
	   }
	   
	   if(Prop_Name.contains(";;"))
	   {
	    String[] prop_NameList=Prop_Name.split(";;");
	    Prop_Name=prop_NameList[0];
	    Prop_Operation=prop_NameList[1];
	   }
	   
	   String default_Prop_Value=Prop_Name;
	   String expected=default_Prop_Value;
	   boolean compareStatus=true;
	   if(Prop_Operation.startsWith("-"))
	   {    
	    int def=Integer.parseInt(default_Prop_Value);
	    int exp=Integer.parseInt(Prop_Operation.substring(1));
	    def=def-exp;
	    expected=""+def;
	   }
	   else if(Prop_Operation.startsWith("+"))
	   {    
	    int def=Integer.parseInt(default_Prop_Value);
	    int exp=Integer.parseInt(Prop_Operation.substring(1));
	    def=def+exp;
	    expected=""+def;
	   } else if(Prop_Operation.startsWith("!="))
	   {
	    compareStatus=false;
	    if(!(expected.equalsIgnoreCase(Prop_Value)))
	    {
	     status=true;        
	    }    
	   }

	   if(compareStatus && expected.equalsIgnoreCase(Prop_Value))
	   {
	    status=true;   
	   }   
	   
	  } catch (Exception e) {
		  actualResult="Exception "+e.getMessage()+" has occurred and step is not verified with actual condition ";
		  ExceptionHandler.handleException(e);
	}
		ReportUtility.reportStepStatus(executionContext, expectedResult, actualResult, status);return status;
	 }
	 /**===============================================================================================================================
	  Function Name: 	verifyDynamicText
	  CREATED BY: 		Ekta Goyal
	  DATE CREATED:  	Nov 2016
	  DESCRIPTION:		Verfifies the text value of the Dynamic text object               	                  
	  PARAMETERS: <No Parameters>
	  RETURNS: 	<No Return Value>		 
	  COMMENTS: 						
	  Modification Log:
	  Date         	                 Initials     	                                     Modification

	  -------------    	------------    ------------------------------------------------------------------------------------------------------------------------------*/
	public static boolean verifyDynamicText(ExecutionContext executionContext)
	{
		String expectedResult = "Text should match";
		String actualResult = "Text should not match";
		String data = executionContext.getCurrentElementData();
		String objectXPath = executionContext.getCurrentElementXPath();
		boolean status = false;
		try {
			if (data == null || data.equalsIgnoreCase("")) {

			} else {
				objectXPath = objectXPath.replaceAll("####", data);
			}
			String objXpath = executionContext.getCurrentElementXPath().replace("TEXT", executionContext.getCurrentElementData());
			executionContext.setCurrentElementXPath(objXpath);
			exist(executionContext);
			status = true;
	    } catch (Exception e) {
	    	actualResult="Exception "+e.getMessage()+" has occurred and step is not verified with actual condition ";
			ExceptionHandler.handleException(e);
		}
			ReportUtility.reportStepStatus(executionContext, expectedResult, actualResult, status);return status;
	}
/*'=====================================End of verifyDynamicText ============================================================================*/
	/*
	 * =============================================================================
	 * ============== Function Name: setElementProperty 
	 * CREATED BY: ACOE Team 
	 * DATE: 05/03/2019 DESCRIPTION: This method is used to set ElementProperty 
	 * Parameter: Object of class ExecutionContext 
	 * RETURNS: boolean status
	 * COMMENTS: Modification Log: Revision: 1.0 Date: 05/03/2019 Comment:
	 * Implemented method with initial requirement
	 * 
	 * =============================================================================
	 * ==============
	 */
	/**
	 * <p style="font-family:Arial;">
	 * <b>DESCRIPTION: This method is used to set ElementProperty and it uses type of property and property name as data separated by semicolon(;)
	 * <br>
	 * <br>
	 * Author: - ACOE Team <br>
	 * <br>
	 * Date Created: 05/03/2019 <br>
	 * <br>
	 * Revision History: <br>
	 * 1.0: Define method and added initial code <br>
	 * 
	 * @param Object
	 *            of class ExecutionContext
	 * @return No Return Value
	 * @throws Exception
	 *             If any error occurs, reports the exception message and log the
	 *             full exception trace in log file </b>
	 *             </P>
	 * 
	 */
	public static boolean setElementProperty(ExecutionContext executionContext) {

		boolean status = false;
		int tableRows = -1;
		String prop_Value = "UnDefinedPropertyState";
		Properties properties = new Properties();

		String expectedResult = "Value " + prop_Value + " should be set in property with name: for element state :";
		String actualResult = "Value " + prop_Value + " is not set in property with name: for element state: ";
		try {

			String objectXPath = executionContext.getCurrentElementXPath();
			String[] rawData = executionContext.getCurrentElementData().split(";");
			String data = rawData[0];
			String prop_Name = rawData[1];

			if (data.equalsIgnoreCase("ROWCOUNT")) {
				String xPath_Row = objectXPath + "/tr";

				List<WebElement> elementList = executionContext.getDriver().findElements(By.xpath(xPath_Row));

				tableRows = elementList.size();
				prop_Value = "" + tableRows;
			}

			if (data.equalsIgnoreCase("TEXT")) {
				List<WebElement> elements = executionContext.getDriver().findElements(By.xpath(objectXPath));
				if (elements.size() > 0) {
					prop_Value = elements.get(0).getText();
				} else {
					prop_Value = "UnDefinedPropertyValue";
				}
			}

			if (data.equalsIgnoreCase("SIZE")) {
				List<WebElement> elements = executionContext.getDriver().findElements(By.xpath(objectXPath));
				prop_Value = "" + elements.size();
			}

			properties.setProperty(prop_Name, prop_Value);
			String recorded = properties.getProperty(prop_Name);

			expectedResult = "Value " + prop_Value + " should be set in property with name " + prop_Name
					+ " for element state " + data;
			actualResult = "Value " + prop_Value + " is not set in property with name " + prop_Name
					+ " for element state " + data;

			if (recorded.equalsIgnoreCase(prop_Value)) {
				actualResult = "Value " + prop_Value + " is successfully set in property with name " + prop_Name
						+ " for element state " + data;
				status = true;

			}

		} catch (Exception e) {
			actualResult = "Exception " + e.getMessage()
					+ " has occurred and step is not verified with actual condition ";
			ExceptionHandler.handleException(e);
		}
		ReportUtility.reportStepStatus(executionContext, expectedResult, actualResult, status);
		return status;
	}
	/*===============================================================================================================================
	Function Name:              verifySuccessMessage
	CREATED BY:                 Shyam Dheer
	DATE CREATED:               05/01/2018
	DESCRIPTION:                This function is used to verify the success message after applying Coupon
	PARAMETERS:                 None                                                                                                                                          
	RETURNS:                    <No Return Value>     Object text should be validated                    
	COMMENTS:                                                                                    
	Modification Log:
	Date                                     Initials                                                       Modification
	                                  
	-------------        ------------    ------------------------------------------------------------------------------------------------------------------------------*/



	public static boolean verifySuccessMessage(ExecutionContext executionContext)
	{
		String expectedResult = "Object should be displayed";
		String actualResult = "Object is not displayed";
		String objectXPath = executionContext.getCurrentElementXPath();
		String data = executionContext.getCurrentElementData();
		boolean status = false;
		try{
			if (data == null || data.equalsIgnoreCase("")) {

			} else {
				objectXPath = objectXPath.replaceAll("####", data);
			}
			expectedResult = "Locator '" + objectXPath + "' should be visible";
			List<WebElement> elements=findElements(executionContext.getDriver(), objectXPath);
			if (elements!=null && elements.size() > 0) {
				String actualText=elements.get(0).getText();
				if (actualText.equalsIgnoreCase(data)) {
					actualResult = "Object with locator " + objectXPath + " actual text " + actualText
							+ " is visible with expected text " + data + "";
					status = true;
				}      else {
					actualResult = "Object with locator " + objectXPath + " actual text " + actualText
							+ " is not viisble with expected text " + data + "";
				}
			}else {
				actualResult = "Object with locator " + objectXPath + " text is null";
			}

		}catch (Exception e) {
			ExceptionHandler.handleException(e);
			actualResult = actualResult + ". " + e.getMessage();
		}
		ReportUtility.reportStepStatus(executionContext, expectedResult, actualResult, status);
		return status;
	}
	/*===============================================================================================================================
	Function Name:              verfiyItemLevelCalculationSavingsApplied
	CREATED BY:                 Shyam Dheer
	DATE CREATED:               June-2018
	DESCRIPTION:                This function is used to verify the Item level calculation in Model pop up
	PARAMETERS:                 No Parameters                                                                                                                                          
	RETURNS:                    <No Return Value>                    
	COMMENTS:                                                                                    
	Modification Log:
	Date                                     Initials                                                       Modification
	                                  
	-------------        ------------    ------------------------------------------------------------------------------------------------------------------------------*/


	public  static boolean verfiyItemLevelCalculationSavingsApplied(ExecutionContext executionContext)
	{
		String expectedResult = "Saving and Amount Calculation are Correct Including Saving Applied";
		String actualResult = "Saving and Amount Calculation are not Correct Including Saving Applied";
		String data = executionContext.getCurrentElementData();
		String objectXPath = executionContext.getCurrentElementXPath();
		boolean status = false;
		try {
			String itemLevel = objectXPath;
			double itemLevel3 =0.0;
			double itemSavingAm3=0.0;
			double expectedSavingAmount = 0.0;
			boolean val=false;
			/**************Get  Item Level Verify Amount *******************/
			List<WebElement> elements=findElements(executionContext.getDriver(), objectXPath);
			if (elements!=null && elements.size() > 0) {
				String itemLevel1=elements.get(0).getText();

				//String itemLevel1=MD.driver.findElement(By.xpath(itemLevel)).getText();

				String  itemLevel2 = itemLevel1.replaceAll("[$ You're saving]","");
				itemLevel3= Double.parseDouble(itemLevel2);

				if(itemLevel3 - expectedSavingAmount<=.01)
				{
					actualResult = "Saving and Amount Calculation are Correct Including Saving Applied ";
				}
				else 
				{
					actualResult = "Saving and Amount Calculation are not Correct Including Saving Applied "; 
				}
				String itemSavingAmt="(//*[@class='item__savings-amt'])";
				elements=findElements(executionContext.getDriver(), objectXPath);
				// List<WebElement> wE = MD.driver.findElements(By.xpath(itemSavingAmt));
				for(WebElement el:elements)
				{
					String itemSavingAmt1=el.getText();;
					String  itemSavingAm2 = itemSavingAmt1.replaceAll("[- $]","");
					itemSavingAm3 = itemSavingAm3 + Double.parseDouble(itemSavingAm2);
					val=true;
				}
				/**************Get the Click Saving Applied Amount  of Item Level And Verify Amount *******************/
				if(val==true)
				{
					if(itemSavingAm3 - expectedSavingAmount<=0.01)
					{
						expectedResult = "Saving and Amount Calculation are Correct Including Saving Applied ";

					}
					else 
					{
						expectedResult = "Saving and Amount Calculation are not Correct Including Saving Applied ";

					}
				}
				else
				{
					actualResult = "Object with locator " + objectXPath + " text is null";
				}
			}
		}


		catch (Exception e) {
			ExceptionHandler.handleException(e);
			actualResult = actualResult + ". " + e.getMessage();
		}
		ReportUtility.reportStepStatus(executionContext, expectedResult, actualResult, status);
		return status;

	}
	
	public static boolean navigateCustomURL(ExecutionContext executionContext) {
		String expectedResult = "";
		String actualResult = "";
		boolean status = false;
		try {
			Log.writeToLogFile("Executing menthod navigateURL....");
			String URL = executionContext.getCurrentElementData();
			expectedResult = "URL '" + URL + "' should be navigated";
			executionContext.getDriver().get(URL);
			wait_Page_Load(executionContext);
			Cookie cookieBB = new Cookie("bbcart", "on");
			executionContext.getDriver().manage().addCookie(cookieBB);
			actualResult = "URL '" + URL + "' is navigated";
			status = true;
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
			actualResult = actualResult + e.getMessage();
		}
		ReportUtility.reportStepStatus(executionContext, expectedResult, actualResult, status);
		return status;
	}


}// public class OperationsDesktop {
