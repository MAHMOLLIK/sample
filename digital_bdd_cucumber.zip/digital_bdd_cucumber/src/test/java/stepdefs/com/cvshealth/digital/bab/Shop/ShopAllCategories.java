package test.java.stepdefs.com.cvshealth.digital.bab.Shop;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import test.java.stepdefs.com.cvshealth.digital.library.AbstractStepDefinition;
import test.java.stepdefs.com.cvshealth.digital.library.ExceptionHandler;
import test.java.stepdefs.com.cvshealth.digital.library.ExecutionContext;
import test.java.stepdefs.com.cvshealth.digital.library.OperationsDesktop;

public class ShopAllCategories extends AbstractStepDefinition {

	@Given("^click on Shop link from CVS home page$")
	public void click_on_Shop_link_from_CVS_home_page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		reportUtility.performInitialSetupForStep(executionContext);
		try {
			
					System.out.println(System.getProperties());
					
					//Click on Shop link
					String ShopLink = ExecutionContext.getObjectLocator("CVS_HomePage", "wLnk_Shop", Browser);
					executionContext.setXpathDataPair(ShopLink,"");
					OperationsDesktop.wait_For_Object(executionContext);
					OperationsDesktop.click(executionContext);
					OperationsDesktop.wait_Page_Load(executionContext);
					
					String ShopBreadcrumb = ExecutionContext.getObjectLocator("CVS_Shop_BB", "wLnk_Shop_Breadcrumb", Browser);
					executionContext.setXpathDataPair(ShopBreadcrumb,"");
					OperationsDesktop.wait_Page_Load(executionContext);
					OperationsDesktop.wait_For_Object(executionContext);
					
					String ShopAllCategories = ExecutionContext.getObjectLocator("CVS_Shop_BB", "wLnk_ShopAllCategories", Browser);
					executionContext.setXpathDataPair(ShopAllCategories,"");
					OperationsDesktop.wait_Page_Load(executionContext);
					OperationsDesktop.wait_For_Object(executionContext);
					
				}
				catch (Exception e) {
					ExceptionHandler.handleException(e);
					reportUtility.setStatusOfOperationForStep(executionContext, false);
				}
				reportUtility.finalStatusSetupToExecuteForEveryStep(executionContext);
			  
	}

	@Then("^click on Shop all categories link and validate the subcategories links$")
	public void click_on_Shop_all_categories_link_and_validate_the_subcategories_links() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		reportUtility.performInitialSetupForStep(executionContext);
		try {
			
					System.out.println(System.getProperties());
					
					//Click on Shop All Categories link
					String ShopAllCategories = ExecutionContext.getObjectLocator("CVS_Shop_BB", "wLnk_ShopAllCategories", Browser);
					executionContext.setXpathDataPair(ShopAllCategories,"");
					OperationsDesktop.wait_For_Object(executionContext);
					OperationsDesktop.click(executionContext);
					OperationsDesktop.wait_Page_Load(executionContext);
					
					//Validate the all sub categories link
					String Departments = ExecutionContext.getObjectLocator("CVS_ShopAllCategories_BB", "wTxt_Departments", Browser);
					executionContext.setXpathDataPair(Departments,"");
					OperationsDesktop.wait_For_Object(executionContext);
					
					String BabyChild = ExecutionContext.getObjectLocator("CVS_ShopAllCategories_BB", "wLnk_BabyChild", Browser);
					executionContext.setXpathDataPair(BabyChild,"");
					OperationsDesktop.exist(executionContext);
					
					String Beauty = ExecutionContext.getObjectLocator("CVS_ShopAllCategories_BB", "wLnk_Beauty", Browser);
					executionContext.setXpathDataPair(Beauty,"");
					OperationsDesktop.exist(executionContext);
					
					String Diet = ExecutionContext.getObjectLocator("CVS_ShopAllCategories_BB", "wLnk_Diet", Browser);
					executionContext.setXpathDataPair(Diet,"");
					OperationsDesktop.exist(executionContext);
					
					String Health = ExecutionContext.getObjectLocator("CVS_ShopAllCategories_BB", "wLnk_Health", Browser);
					executionContext.setXpathDataPair(Health,"");
					OperationsDesktop.exist(executionContext);
					
					String Household = ExecutionContext.getObjectLocator("CVS_ShopAllCategories_BB", "wLnk_Household", Browser);
					executionContext.setXpathDataPair(Household,"");
					OperationsDesktop.exist(executionContext);
					
					String Personal = ExecutionContext.getObjectLocator("CVS_ShopAllCategories_BB", "wLnk_Personal", Browser);
					executionContext.setXpathDataPair(Personal,"");
					OperationsDesktop.exist(executionContext);
					
					String Sexual = ExecutionContext.getObjectLocator("CVS_ShopAllCategories_BB", "wLnk_Sexual", Browser);
					executionContext.setXpathDataPair(Sexual,"");
					OperationsDesktop.exist(executionContext);
					
					String Vitamins = ExecutionContext.getObjectLocator("CVS_ShopAllCategories_BB", "wLnk_Vitamins", Browser);
					executionContext.setXpathDataPair(Vitamins,"");
					OperationsDesktop.exist(executionContext);
					
					String FSA = ExecutionContext.getObjectLocator("CVS_ShopAllCategories_BB", "wLnk_FSA", Browser);
					executionContext.setXpathDataPair(FSA,"");
					OperationsDesktop.exist(executionContext);
					
					String Brand = ExecutionContext.getObjectLocator("CVS_ShopAllCategories_BB", "wLnk_Brand", Browser);
					executionContext.setXpathDataPair(Brand,"");
					OperationsDesktop.exist(executionContext);
						
					
				}
				catch (Exception e) {
					ExceptionHandler.handleException(e);
					reportUtility.setStatusOfOperationForStep(executionContext, false);
				}
				reportUtility.finalStatusSetupToExecuteForEveryStep(executionContext);
	}

	@Then("^traverse sub categories from Shop all categories link$")
	public void traverse_sub_categories_from_Shop_all_categories_link() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		reportUtility.performInitialSetupForStep(executionContext);
		try {
			
					System.out.println(System.getProperties());
		//traverse sub category BabyChild from Shop all categories link
		String Departments = ExecutionContext.getObjectLocator("CVS_ShopAllCategories_BB", "wTxt_Departments", Browser);
		executionContext.setXpathDataPair(Departments,"");
		OperationsDesktop.wait_For_Object(executionContext);
		
		String BabyChild = ExecutionContext.getObjectLocator("CVS_ShopAllCategories_BB", "wLnk_BabyChild", Browser);
		executionContext.setXpathDataPair(BabyChild,"");
		OperationsDesktop.click(executionContext);
		
		String BathSkin = ExecutionContext.getObjectLocator("CVS_ShopAllCategories_BB", "wLnk_Bath", Browser);
		executionContext.setXpathDataPair(BathSkin,"");
		OperationsDesktop.wait_For_Object(executionContext);
		OperationsDesktop.click(executionContext);
		
		String BabyOil = ExecutionContext.getObjectLocator("CVS_ShopAllCategories_BB", "wLnk_BabyOil", Browser);
		executionContext.setXpathDataPair(BabyOil,"");
		OperationsDesktop.wait_For_Object(executionContext);
		
		}
		catch (Exception e) {
			ExceptionHandler.handleException(e);
			reportUtility.setStatusOfOperationForStep(executionContext, false);
		}
		reportUtility.finalStatusSetupToExecuteForEveryStep(executionContext);
		
	}
		

	@Then("^click the one sub categories from Shop all categories link$")
	public void click_the_one_sub_categories_from_Shop_all_categories_link() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		reportUtility.performInitialSetupForStep(executionContext);
		try {
			
					System.out.println(System.getProperties());
					
					//Click on Sub Cat Baby Oil link
					String BabyOil = ExecutionContext.getObjectLocator("CVS_ShopAllCategories_BB", "wLnk_BabyOil", Browser);
					executionContext.setXpathDataPair(BabyOil,"");
					OperationsDesktop.wait_For_Object(executionContext);
					OperationsDesktop.click(executionContext);
					OperationsDesktop.wait_Page_Load(executionContext);
					
				}
				catch (Exception e) {
					ExceptionHandler.handleException(e);
					reportUtility.setStatusOfOperationForStep(executionContext, false);
				}
				reportUtility.finalStatusSetupToExecuteForEveryStep(executionContext);
			  
	}

	@Then("^validate the PLP Page as per selected sub categories$")
	public void validate_the_PLP_Page_as_per_selected_sub_categories() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		reportUtility.performInitialSetupForStep(executionContext);
		try {
			
					System.out.println(System.getProperties());
					
					//Validate the PLP page as per SubCat Baby Oil 
					String BabyOil = ExecutionContext.getObjectLocator("CVS_ShopAllCategories_BB", "wLnk_BabyOil", Browser);
					executionContext.setXpathDataPair(BabyOil,"");
					OperationsDesktop.wait_For_Object(executionContext);
					OperationsDesktop.click(executionContext);
					OperationsDesktop.wait_Page_Load(executionContext);
					
					String BabyOilHeader = ExecutionContext.getObjectLocator("CVS_PLP_BB", "wTxt_BabyOil", Browser);
					executionContext.setXpathDataPair(BabyOilHeader,"");
					OperationsDesktop.wait_For_Object(executionContext);
					
					String Shop_Breadcrumb = ExecutionContext.getObjectLocator("CVS_PLP_BB", "wLnk_Shop_Breadcrumb", Browser);
					executionContext.setXpathDataPair(Shop_Breadcrumb,"");
					OperationsDesktop.wait_For_Object(executionContext);
					
					String Baby_Breadcrumb = ExecutionContext.getObjectLocator("CVS_PLP_BB", "wLnk_Baby_Breadcrumb", Browser);
					executionContext.setXpathDataPair(Baby_Breadcrumb,"");
					OperationsDesktop.exist(executionContext);
					
					String Bath_Breadcrumb = ExecutionContext.getObjectLocator("CVS_PLP_BB", "wLnk_Bath_Breadcrumb", Browser);
					executionContext.setXpathDataPair(Bath_Breadcrumb,"");
					OperationsDesktop.exist(executionContext);
					
					String BabyOil_Breadcrumb = ExecutionContext.getObjectLocator("CVS_PLP_BB", "wLnk_BabyOil_Breadcrumb", Browser);
					executionContext.setXpathDataPair(BabyOil_Breadcrumb,"");
					OperationsDesktop.exist(executionContext);
					
					String Baby_Filter = ExecutionContext.getObjectLocator("CVS_PLP_BB", "wLnk_Baby_Filter", Browser);
					executionContext.setXpathDataPair(Baby_Filter,"");
					OperationsDesktop.exist(executionContext);
					
					String Bath_Filter = ExecutionContext.getObjectLocator("CVS_PLP_BB", "wLnk_Bath_Filter", Browser);
					executionContext.setXpathDataPair(Bath_Filter,"");
					OperationsDesktop.exist(executionContext);
					
					String BabyOil_Filter = ExecutionContext.getObjectLocator("CVS_PLP_BB", "wLnk_BabyOil_Filter", Browser);
					executionContext.setXpathDataPair(BabyOil_Filter,"");
					OperationsDesktop.exist(executionContext);
					
					String ClearAll_Filter = ExecutionContext.getObjectLocator("CVS_PLP_BB", "wLnk_ClearAll_Filter", Browser);
					executionContext.setXpathDataPair(ClearAll_Filter,"");
					OperationsDesktop.exist(executionContext);
					
					String PLP1stProduct = ExecutionContext.getObjectLocator("CVS_PLP", "wLnk_ProductName_PLP", Browser);
					executionContext.setXpathDataPair(PLP1stProduct,"");
					OperationsDesktop.wait_For_Object(executionContext);
					OperationsDesktop.scroll_To_Object(executionContext);
					
				}
				catch (Exception e) {
					ExceptionHandler.handleException(e);
					reportUtility.setStatusOfOperationForStep(executionContext, false);
				}
				reportUtility.finalStatusSetupToExecuteForEveryStep(executionContext);
	}
	
	@Then("^click on Vitamins under Shop by category$")
	public void click_on_Vitamins_under_Shop_by_category() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		reportUtility.performInitialSetupForStep(executionContext);
		try {
			
					System.out.println(System.getProperties());
					
					//Click on Sub Cat Vitamins
					String Vitamins = ExecutionContext.getObjectLocator("CVS_PLP_BB", "wLnk_Vitamins", Browser);
					executionContext.setXpathDataPair(Vitamins,"");
					OperationsDesktop.wait_For_Object(executionContext);
					OperationsDesktop.click(executionContext);
					OperationsDesktop.wait_Page_Load(executionContext);
					
					String VitaminsSup_Hamburger = ExecutionContext.getObjectLocator("CVS_PLP_BB", "wLnk_VitaminsSup_Hamburger", Browser);
					executionContext.setXpathDataPair(VitaminsSup_Hamburger,"");
					OperationsDesktop.wait_For_Object(executionContext);
					
					String VitaminsSup_Header = ExecutionContext.getObjectLocator("CVS_PLP_BB", "wTxt_VitaminsSup_Header", Browser);
					executionContext.setXpathDataPair(VitaminsSup_Header,"");
					OperationsDesktop.wait_For_Object(executionContext);
					
					String Multivitamins = ExecutionContext.getObjectLocator("CVS_PLP_BB", "wLnk_Multivitamins", Browser);
					executionContext.setXpathDataPair(Multivitamins,"");
					OperationsDesktop.wait_For_Object(executionContext);
					
				}
				catch (Exception e) {
					ExceptionHandler.handleException(e);
					reportUtility.setStatusOfOperationForStep(executionContext, false);
				}
				reportUtility.finalStatusSetupToExecuteForEveryStep(executionContext);
	}

	
}
