package test.java.stepdefs.com.cvshealth.digital.library;

import java.io.IOException;
import java.net.URL;

import org.openqa.selenium.Capabilities;
import org.openqa.selenium.UnexpectedAlertBehaviour;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.firefox.ProfilesIni;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.BrowserType;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.safari.SafariDriver;

public class BrowserInvocation {

	String URL = null, FIREFOX_BROWSER_PATH = null, GECKO_DRIVER_PATH = null, IE_DRIVER_PATH = null,
			CHROME_DRIVER_PATH = null, EDGE_DRIVER_PATH = null, SAFARI_DRIVER_PATH = null;

	/** 
	* <p style="font-family:Arial;">
	* <b>DESCRIPTION: This constructor is used to launch new browser session to start executing a scenario
	* <br><br>
	* Author: - ACOE Team
	* <br><br>
	* Date Created: 05/03/2019
	* <br><br>Revision History: 
	* <br>1.0: Define method and added initial code
	* <br>
	* @param  String browserName, Object of ExecutionContext class
	* @return No Return Value
	* @throws Exception  If any error occurs, reports the exception message and logs the full exception trace in log file
	* </b></P> 
	* 
	*/
	
	@SuppressWarnings("deprecation")
	public BrowserInvocation(String browserName, ExecutionContext executionContext) throws IOException {
		// TODO Auto-generated constructor stub
		fetchAttributesFromPropertyLoader();
		System.out.println(browserName);
		switch (browserName) {
		case "FIREFOX":
			ProfilesIni profile = new ProfilesIni();
			FirefoxProfile myProfile = profile.getProfile("default");
			FirefoxProfile firefoxProfile = new FirefoxProfile();
			firefoxProfile.setPreference("media.navigator.streams.fake", true);
			FirefoxOptions foptions = new FirefoxOptions();
			foptions.setBinary(FIREFOX_BROWSER_PATH);
			//Log.writeToLogFile("Firefox path: "+FIREFOX_BROWSER_PATH);
			foptions.setProfile(firefoxProfile);
			System.setProperty("webdriver.gecko.driver", GECKO_DRIVER_PATH);
			//Log.writeToLogFile("Gecko Driver Path: "+GECKO_DRIVER_PATH);
			DesiredCapabilities capabilities = new DesiredCapabilities();
			capabilities.setCapability(CapabilityType.UNEXPECTED_ALERT_BEHAVIOUR, UnexpectedAlertBehaviour.IGNORE);
			executionContext.setDriver(new FirefoxDriver(foptions));
			Capabilities caps = ((RemoteWebDriver) executionContext.getDriver()).getCapabilities();
			browserName = caps.getBrowserName();
			System.out.println("Browser  " + browserName);
			String browserVersion = caps.getVersion();
			System.out.println("BrowserVersion  " + browserVersion);
			executionContext.getDriver().manage().window().maximize();
			break;
		case "IE":
			DesiredCapabilities desCaps = DesiredCapabilities.internetExplorer();
			desCaps.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
			desCaps.setCapability("ignoreZoomSetting", true);
			desCaps.setCapability("CapabilityType.SUPPORTS_NETWORK_CONNECTION", true);
			desCaps.setCapability("CapabilityType.HAS_NATIVE_EVENTS", true);
			desCaps.setCapability(InternetExplorerDriver.IE_ENSURE_CLEAN_SESSION, true);
			desCaps.setCapability(InternetExplorerDriver.IE_SWITCHES, true);
			desCaps.setCapability(InternetExplorerDriver.NATIVE_EVENTS, true);
			desCaps.setCapability("ignoreProtectedModeSettings", true);
			desCaps.setCapability("ie.ensureCleanSession", true);
			desCaps.setCapability("EnableNativeEvents", false);
			 System.setProperty("webdriver.ie.driver", IE_DRIVER_PATH);
			Runtime.getRuntime().exec("RunDll32.exe InetCpl.cpl,ClearMyTracksByProcess 255");
			DesiredCapabilities iecapabilities = DesiredCapabilities.internetExplorer();
			iecapabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
			executionContext.setDriver(new InternetExplorerDriver(desCaps));
			Capabilities iecaps = ((RemoteWebDriver) executionContext.getDriver()).getCapabilities();
			String iebrowserName = iecaps.getBrowserName();
			String iebrowserVersion = iecaps.getVersion();
			System.out.println("BrowserVersion  " + iebrowserName);
			System.out.println("BrowserVersion  " + iebrowserVersion);
			executionContext.getDriver().manage().window().maximize();
			break;
		case "GOOGLECHROME123":
			DesiredCapabilities dc = new DesiredCapabilities();
			dc.setCapability("username", "admin");
			dc.setCapability("password", "");
			dc.setCapability("projectName", "Default");
			dc.setCapability(CapabilityType.BROWSER_NAME, BrowserType.CHROME);
			dc.setCapability(CapabilityType.BROWSER_VERSION, "67.0.3396");
			dc.setCapability("newCommandTimeout", 500);
			dc.setCapability("newSessionWaitTimeout", 500);
			// dc.setCapability("accessKey", ACCESSKEY);
			dc.setCapability("generateReport", true);
			dc.setCapability("testName", "Selenium Test on Chrome");
			executionContext.setDriver(new RemoteWebDriver(new URL("http://10.93.9.152:8080" + "/wd/hub/"), dc));
			String testReportUrl = (String) ((RemoteWebDriver) executionContext.getDriver()).getCapabilities()
					.getCapability("reportUrl");
			System.out.println(testReportUrl);

			break;
		case "GOOGLECHROME":
			System.setProperty("webdriver.chrome.driver", CHROME_DRIVER_PATH);
			DesiredCapabilities capability = DesiredCapabilities.chrome();
			if (System.getProperty("os.name").contains("Mac")) {
				capability.setPlatform(org.openqa.selenium.Platform.MAC);
			} else {
				capability.setPlatform(org.openqa.selenium.Platform.WINDOWS);
			} // if(System.getProperty("os.name").contains("Mac")) {
			ChromeOptions coptions = new ChromeOptions();
			coptions.setExperimentalOption("useAutomationExtension", false);
			// coptions.addArguments("--disable-extensions");
			// coptions.addArguments("test-type");
			coptions.addArguments("--start-maximized");
			// coptions.addArguments("-incognito");
			// coptions.addArguments("--disable-popup-blocking");
			// coptions.addArguments("use-fake-ui-for-media-stream");
			executionContext.setDriver(new ChromeDriver(coptions));
			// driver = new WebDriver(new URL("http://10.124.253.91:4444/wd/hub"), options);
			String chbrowserName = capability.getBrowserName();
			System.out.println("Browser  " + chbrowserName);
			String chbrowserVersion = capability.getVersion();
			System.out.println("Browser  " + chbrowserVersion);
			executionContext.getDriver().manage().window().maximize();
			break;
		case "SAFARI":
			// File file = new File("/usr/bin/safaridriver");
			System.setProperty("webdriver.safari.driver", SAFARI_DRIVER_PATH);
			DesiredCapabilities safaridesCaps = new DesiredCapabilities();
			safaridesCaps.setCapability("handlesAlerts", true);
			//SafariOptions soptions = new SafariOptions();
			executionContext.setDriver(new SafariDriver());
			executionContext.getDriver().manage().window().maximize();
			String sbrowserName = safaridesCaps.getBrowserName();
			System.out.println("Browser  " + sbrowserName);
			String sbrowserVersion = safaridesCaps.getVersion();
			System.out.println("Browser  " + sbrowserVersion);
			break;
		case "EDGE":
			System.setProperty("webdriver.edge.driver", EDGE_DRIVER_PATH);
			//EdgeOptions options = new EdgeOptions();
			DesiredCapabilities edgedesCaps = DesiredCapabilities.edge();
			edgedesCaps.setCapability("ignoreZoomSetting", true);
			executionContext.setDriver(new EdgeDriver(edgedesCaps));
			executionContext.getDriver().manage().window().maximize();
			break;
		case "MOBILEWEB":

			break;
		case "MOBILEAPP":

			break;
		default:
			executionContext.setDriver(new FirefoxDriver());
			break;
		}// switch (Browser.valueOf(browserName.toUpperCase())) {
		executionContext.getDriver().manage().window().maximize();
		// return driver;
	}// public WebDriver createInstance(String browserName) {

	private void fetchAttributesFromPropertyLoader() {
		// TODO Auto-generated method stub

		URL = PropertyFileLoader.getInstance().getURL();
		FIREFOX_BROWSER_PATH = PropertyFileLoader.getInstance().getFIREFOX_BROWSER_PATH();
		GECKO_DRIVER_PATH = PropertyFileLoader.getInstance().getGECKO_DRIVER_PATH();
		IE_DRIVER_PATH = PropertyFileLoader.getInstance().getIE_DRIVER_PATH();
		CHROME_DRIVER_PATH = PropertyFileLoader.getInstance().getCHROME_DRIVER_PATH();
		EDGE_DRIVER_PATH = PropertyFileLoader.getInstance().getEDGE_DRIVER_PATH();
		SAFARI_DRIVER_PATH = PropertyFileLoader.getInstance().getSAFARI_DRIVER_PATH();

	}

}
