package test.java.stepdefs.com.cvshealth.digital.cat.savingtools;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.List;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import cucumber.api.DataTable;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import test.java.stepdefs.com.cvshealth.digital.library.AbstractStepDefinition;
import test.java.stepdefs.com.cvshealth.digital.library.DBCacheSingleton;
import test.java.stepdefs.com.cvshealth.digital.library.ExceptionHandler;
import test.java.stepdefs.com.cvshealth.digital.library.ExecutionContext;
import test.java.stepdefs.com.cvshealth.digital.library.OperationsDesktop;
import test.java.stepdefs.com.cvshealth.digital.library.PropertyFileLoader;
import test.java.stepdefs.com.cvshealth.digital.library.ReportUtility;

public class RequestSavingOpportunities extends AbstractStepDefinition {
	@Given("^clicks on the \"([^\"]*)\" which has TALT opportutnity$")
	public void clicks_on_the_which_has_TALT_opportutnity(String drugName) {
		reportUtility.performInitialSetupForStep(executionContext);
		try {
			//click on the drug
			String drugNamexPath = ExecutionContext.getObjectLocator("MyPrescriptionsFinderPage", "wTxt_prescriptionSavingsNames", Browser);
			drugNamexPath = drugNamexPath.replace("dynamic_prescSavingsNames", drugName.trim());
			executionContext.setXpathDataPair(drugNamexPath, "");
			OperationsDesktop.click(executionContext);
			
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
			reportUtility.setStatusOfOperationForStep(executionContext, false);
		}
		reportUtility.finalStatusSetupToExecuteForEveryStep(executionContext);
	    
	}
	
	@Given("^clicks on the \"([^\"]*)\" which has GALT opportutnity$")
	public void clicks_on_the_which_has_GALT_opportutnity(String drugName) {
		clicks_on_the_which_has_TALT_opportutnity(drugName);
	}
	
	@Given("^clicks on the \"([^\"]*)\" which has 90-day opportutnity$")
	public void clicks_on_the_which_has_day_opportutnity(String drugName) throws Throwable {
		clicks_on_the_which_has_TALT_opportutnity(drugName);
	}
	
	@Given("^clicks on the \"([^\"]*)\" which has CDC opportutnity$")
	public void clicks_on_the_which_has_CDC_opportutnity(String drugName) throws Throwable {
		clicks_on_the_which_has_TALT_opportutnity(drugName);
	}
	
	@When("^user requested proactive TALT savings opportunity and request has been confirmed$")
	public void user_requested_proactive_TALT_savings_opportunity_and_request_has_been_confirmed() {
		reportUtility.performInitialSetupForStep(executionContext);
		try {
			//click on consult my prescriber
			String requestTALTxPath = ExecutionContext.getObjectLocator("SavingsOpportunitiesPage", "wBtn_RequestTALT", Browser);
			executionContext.setXpathDataPair(requestTALTxPath, "");
			OperationsDesktop.click(executionContext);
			//wait for object
			String wBtn_SubmitSavingsRequest = ExecutionContext.getObjectLocator("SavingsOpportunitiesPage","wBtn_SubmitSavingsRequest", Browser);
			executionContext.setXpathDataPair(wBtn_SubmitSavingsRequest, "");
			OperationsDesktop.wait_For_Object(executionContext);
			//click on submit in modal pop up
			//String wBtn_SubmitSavingsRequest = ExecutionContext.getObjectLocator("SavingsOpportunitiesPage","wBtn_SubmitSavingsRequest", Browser);
			executionContext.setXpathDataPair(wBtn_SubmitSavingsRequest, "");
			OperationsDesktop.click_Java_Script(executionContext);
			//check for congratulations text for confirmation
			String wMsg_Congratulations = ExecutionContext.getObjectLocator("Savings status","wMsg_Congratulations", Browser);
			executionContext.setXpathDataPair(wMsg_Congratulations, "");
			OperationsDesktop.wait_For_Object(executionContext);
						
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
			reportUtility.setStatusOfOperationForStep(executionContext, false);
		}
		reportUtility.finalStatusSetupToExecuteForEveryStep(executionContext);
	    
	}

	
	@When("^user requested proactive GALT savings opportunity and request has been confirmed$")
	public void user_requested_proactive_GALT_savings_opportunity_and_request_has_been_confirmed() {
		reportUtility.performInitialSetupForStep(executionContext);
		try {
			//click on consult my prescriber
			String requestTALTxPath = ExecutionContext.getObjectLocator("SavingsOpportunitiesPage", "wBtn_RequestGeneric", Browser);
			executionContext.setXpathDataPair(requestTALTxPath, "");
			OperationsDesktop.click(executionContext);
			//wait for modal
			String wBtn_SubmitSavingsRequest = ExecutionContext.getObjectLocator("SavingsOpportunitiesPage","wBtn_SubmitSavingsRequest", Browser);
			executionContext.setXpathDataPair(wBtn_SubmitSavingsRequest, "");
			OperationsDesktop.wait_For_Object(executionContext);
			//click on submit in modal pop up
			//String wBtn_SubmitSavingsRequest = ExecutionContext.getObjectLocator("SavingsOpportunitiesPage","wBtn_SubmitSavingsRequest", Browser);
			executionContext.setXpathDataPair(wBtn_SubmitSavingsRequest, "");
			OperationsDesktop.click(executionContext);
			//check for congratulations text for confirmation
			String wMsg_Congratulations = ExecutionContext.getObjectLocator("Savings status","wMsg_Congratulations", Browser);
			executionContext.setXpathDataPair(wMsg_Congratulations, "");
			OperationsDesktop.wait_For_Object(executionContext);
						
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
			reportUtility.setStatusOfOperationForStep(executionContext, false);
		}
		reportUtility.finalStatusSetupToExecuteForEveryStep(executionContext);
	}
	
	@When("^user requested proactive CDC savings opportunity and request has been confirmed$")
	public void user_requested_proactive_CDC_savings_opportunity_and_request_has_been_confirmed() throws Throwable {
		reportUtility.performInitialSetupForStep(executionContext);
		try {
			//click on consult my prescriber
			String requestTALTxPath = ExecutionContext.getObjectLocator("SavingsOpportunitiesPage", "wBtn_RequestCDC", Browser);
			executionContext.setXpathDataPair(requestTALTxPath, "");
			OperationsDesktop.click(executionContext);
			//wait for modal
			String wBtn_SubmitSavingsRequest = ExecutionContext.getObjectLocator("SavingsOpportunitiesPage","wBtn_SubmitSavingsRequest", Browser);
			executionContext.setXpathDataPair(wBtn_SubmitSavingsRequest, "");
			OperationsDesktop.wait_For_Object(executionContext);
			//click on submit in modal pop up
			//String wBtn_SubmitSavingsRequest = ExecutionContext.getObjectLocator("SavingsOpportunitiesPage","wBtn_SubmitSavingsRequest", Browser);
			executionContext.setXpathDataPair(wBtn_SubmitSavingsRequest, "");
			OperationsDesktop.click(executionContext);
			//check for congratulations text for confirmation
			String wMsg_Congratulations = ExecutionContext.getObjectLocator("Savings status","wMsg_Congratulations", Browser);
			executionContext.setXpathDataPair(wMsg_Congratulations, "");
			OperationsDesktop.wait_For_Object(executionContext);
						
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
			reportUtility.setStatusOfOperationForStep(executionContext, false);
		}
		reportUtility.finalStatusSetupToExecuteForEveryStep(executionContext);
	}
	
	@When("^user requested proactive 90-day savings opportunity and request has been confirmed$")
	public void user_requested_proactive_day_savings_opportunity_and_request_has_been_confirmed() throws Throwable {
		reportUtility.performInitialSetupForStep(executionContext);
		try {
			//click on consult my prescriber
			String requestTALTxPath = ExecutionContext.getObjectLocator("SavingsOpportunitiesPage", "wBtn_Request90Day", Browser);
			executionContext.setXpathDataPair(requestTALTxPath, "");
			OperationsDesktop.click(executionContext);
			//wait for object
			String wBtn_SubmitSavingsRequest = ExecutionContext.getObjectLocator("SavingsOpportunitiesPage","wBtn_SubmitSavingsRequest", Browser);
			executionContext.setXpathDataPair(wBtn_SubmitSavingsRequest, "");
			OperationsDesktop.wait_For_Object(executionContext);
			//click on submit in modal pop up
			//String wBtn_SubmitSavingsRequest = ExecutionContext.getObjectLocator("SavingsOpportunitiesPage","wBtn_SubmitSavingsRequest", Browser);
			executionContext.setXpathDataPair(wBtn_SubmitSavingsRequest, "");
			OperationsDesktop.click_Java_Script(executionContext);
			//check for congratulations text for confirmation
			String wMsg_Congratulations = ExecutionContext.getObjectLocator("Savings status","wMsg_Congratulations", Browser);
			executionContext.setXpathDataPair(wMsg_Congratulations, "");
			OperationsDesktop.wait_For_Object(executionContext);
						
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
			reportUtility.setStatusOfOperationForStep(executionContext, false);
		}
		reportUtility.finalStatusSetupToExecuteForEveryStep(executionContext);
	}

	
	@Then("^it is sent into the QT of Rx connect system \"([^\"]*)\", \"([^\"]*)\"$")
	public void it_is_sent_into_the_QT_of_Rx_connect_system(String patientId, String rxNumber){
		reportUtility.performInitialSetupForStep(executionContext);
		
		String query = "select * from (select rp.PATIENT_ID, rp.RX_NUMBER, rt.employee_id, rt.facility_id from rxp_triage_queue rp"
				+ " INNER JOIN rxp_triage_attr rt ON rp.TRIAGE_QUEUE_ID = rt.TRIAGE_QUEUE_ID"
				+ " WHERE rp.PATIENT_ID = " + patientId + " and rp.RX_NUMBER = " + rxNumber + " and rp.TRIAGE_INDUCTION_TIME >= sysdate - 2/(24*60) order by rp.TRIAGE_INDUCTION_TIME desc) where rownum = 1";
		System.out.println("query " + query);
		try {	
				Class.forName("oracle.jdbc.driver.OracleDriver");
				
				String dbURL = "jdbc:oracle:thin:@rri2rxdbda401:1521:NOJ3";
	            String username = "rxread";
	            String password = "rxread";
	            Connection conn = DriverManager.getConnection(dbURL, username, password);
				
	            if (conn != null) {
	                System.out.println("Connected with oracle");
	            }
	            
				Statement statement = conn.createStatement();
				//PreparedStatement statement = conn.prepareStatement(query);
				ResultSet resultset = statement.executeQuery(query);
				System.out.println("resultset: " + resultset);
				String expectedValue = "DIGITAL";
				String employeeId = "";
				if(resultset != null && resultset.getFetchSize() > 0)
				{
					System.out.println("in if loop");
					//while(resultset.next())
					if(resultset.next())
					{
						employeeId = resultset.getString("employee_id");
						System.out.println("employeeId " + employeeId);
						Assert.assertEquals(employeeId, expectedValue);
						ReportUtility.reportStepStatus(executionContext, "expected value: " + expectedValue, "actual value: " + employeeId, expectedValue.equalsIgnoreCase(employeeId)?true:false);
					}
					else {
						System.out.println("inner else loop");
						ReportUtility.reportStepStatus(executionContext, "expected value: " + expectedValue, "actual value: " + employeeId, false);
					}
				}
				else {
					System.out.println("in else loop");
					ReportUtility.reportStepStatus(executionContext, "expected value: " + expectedValue, "actual value: " + employeeId, false);
				}
				
				conn.close();
	            
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
			reportUtility.setStatusOfOperationForStep(executionContext, false);
			
		}
		reportUtility.finalStatusSetupToExecuteForEveryStep(executionContext);
	    
	}
	
	@Then("^it should not sent into the QT of Rx connect system \"([^\"]*)\", \"([^\"]*)\"$")
	public void it_should_not_sent_into_the_QT_of_Rx_connect_system(String patientId, String rxNumber) throws Throwable {
		reportUtility.performInitialSetupForStep(executionContext);
		
		String query = "select * from (select rp.PATIENT_ID, rp.RX_NUMBER, rt.employee_id, rt.facility_id from rxp_triage_queue rp"
				+ " INNER JOIN rxp_triage_attr rt ON rp.TRIAGE_QUEUE_ID = rt.TRIAGE_QUEUE_ID"
				+ " WHERE rp.PATIENT_ID = " + patientId + " and rp.RX_NUMBER = " + rxNumber + " and rp.TRIAGE_INDUCTION_TIME >= sysdate - 2/(24*60) order by rp.TRIAGE_INDUCTION_TIME desc) where rownum =1";
		System.out.println("query " + query);
		try {	
				Class.forName("oracle.jdbc.driver.OracleDriver");
				
				String dbURL = "jdbc:oracle:thin:@rri2rxdbda401:1521:NOJ3";
	            String username = "rxread";
	            String password = "rxread";
	            Connection conn = DriverManager.getConnection(dbURL, username, password);
				
	            if (conn != null) {
	                System.out.println("Connected with oracle");
	            }
	            
				Statement statement = conn.createStatement();
				ResultSet resultset = statement.executeQuery(query);
				
				String expectedValue = "";
				String employeeId = "";
				System.out.println("resultset: " + resultset);
				if(resultset != null)
				{
					while(resultset.next())
					{
						employeeId = resultset.getString("employee_id");
						System.out.println("employeeId " + employeeId);
						Assert.assertEquals(employeeId, expectedValue);
						ReportUtility.reportStepStatus(executionContext, "expected value is null", "actual value" + employeeId, expectedValue.equalsIgnoreCase(employeeId)?true:false);
					}
				}
				else {
					System.out.println("in else loop");
					ReportUtility.reportStepStatus(executionContext, "expected value: " + expectedValue, "actual value is null" + employeeId, true);
				}
				
				conn.close();
	            
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
			reportUtility.setStatusOfOperationForStep(executionContext, false);
			
		}
		reportUtility.finalStatusSetupToExecuteForEveryStep(executionContext);
		
	}
/*	@Given("^CVS dot com user logged into ICE Pharmacy using valid credentials$")
	public void cvs_dot_com_user_logged_into_ICE_Pharmacy_using_valid_credentials(DataTable objDataTable) {
		
		reportUtility.performInitialSetupForStep(executionContext);
		try {
			//get data
			String userName=executionContext.getExecutionData(objDataTable, "username");
			String password=executionContext.getExecutionData(objDataTable, "password");

			for each method call, user should set xpath-data pair and then call method
			pass empty string respectively when xpath/data is not required to call the method
			
			executionContext.setXpathDataPair("", PropertyFileLoader.getInstance().getURL());
			
			//in this example only URL is expected
			//execute generic method inside the assert statement to terminate in case of failure
			Assert.assertTrue(OperationsDesktop.navigateURL(executionContext));

			//set current xpath and data for input method
			String userNameXPath = ExecutionContext.getObjectLocator(DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "ICE_PharmacyPage", "wEdt_EmailAddress", Browser);
			executionContext.setXpathDataPair(userNameXPath, userName);
			
			//both the operations can be invoked sequentially as both require same xPath and data which has been set already
			OperationsDesktop.wait_For_Object(executionContext);
			OperationsDesktop.input(executionContext);
			
			String userPassword = ExecutionContext.getObjectLocator(DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), 
					"ICE_PharmacyPage",	"wEdt_Password", Browser);
			executionContext.setXpathDataPair(userPassword, password);
			OperationsDesktop.input(executionContext);

			String signInButtonXPath = ExecutionContext.getObjectLocator(DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "ICE_PharmacyPage", "wBtn_SignIn",	Browser);
			executionContext.setXpathDataPair(signInButtonXPath, "");
			OperationsDesktop.click(executionContext);

			String signoutButtonXPath = ExecutionContext.getObjectLocator(DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "ICE_Pharmacy_LoginPage", "wLnk_SignOut", Browser);
			executionContext.setXpathDataPair(signoutButtonXPath, "");
			OperationsDesktop.wait_For_Object(executionContext);
			
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
			reportUtility.setStatusOfOperationForStep(executionContext, false);
		}
		reportUtility.finalStatusSetupToExecuteForEveryStep(executionContext);

	}

	@Given("^navigates to prescription savings screen using savings banner on ICE home page$")
	public void navigates_to_prescription_savings_screen_using_savings_banner_on_ICE_home_page() {
		// Write code here that turns the phrase above into concrete actions

		reportUtility.performInitialSetupForStep(executionContext);
		try {

			String SearchForSavingsxPath = ExecutionContext.getObjectLocator(
					DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "ICE_Pharmacy_LoginPage",
					"wBtn_SearchForSavings", Browser);
			executionContext.setXpathDataPair(SearchForSavingsxPath, "");
			OperationsDesktop.wait_For_Object(executionContext);
			OperationsDesktop.click(executionContext);

			String howCVS_findsMySavingsxPath = ExecutionContext.getObjectLocator(
					DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "MyPrescriptionsFinderPage",
					"wTxt_howCVS_findsMySavings", Browser);
			executionContext.setXpathDataPair(howCVS_findsMySavingsxPath, "");			
			
			OperationsDesktop.wait_For_Object(executionContext);

		} catch (Exception e) {
			ExceptionHandler.handleException(e);
			reportUtility.setStatusOfOperationForStep(executionContext, false);
		}
		reportUtility.finalStatusSetupToExecuteForEveryStep(executionContext);
	}

	@When("^user clicks on each prescription they should see correct opportunities$")
	public void user_clicks_on_each_prescription_they_should_see_correct_opportunities(DataTable objDataTable) {

		reportUtility.performInitialSetupForStep(executionContext);
		try {

			List<String> prescriptionList=executionContext.getExecutionDataList(objDataTable, "prescription");
			List<String> savingOpportunityList=executionContext.getExecutionDataList(objDataTable, "savings_opportunities");
			List<String> alternativeList=executionContext.getExecutionDataList(objDataTable, "alternatives");

			for (int i=0;i<prescriptionList.size();i++) {

				String currentPrescription=prescriptionList.get(i);

				String[] currentSavingOptionsList=savingOpportunityList.get(i).split(",");
				String[] currentAlternativeOptionList=alternativeList.get(i).split(",");

				String searchForSavingsxPath = ExecutionContext.getObjectLocator(
						DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(),
						"MyPrescriptionsFinderPage", "wTxt_prescriptionSavingsNames", Browser);
				searchForSavingsxPath = searchForSavingsxPath.replace("dynamic_prescSavingsNames",
						currentPrescription.trim());
				executionContext.setXpathDataPair(searchForSavingsxPath, "");

				if (OperationsDesktop.exist(executionContext)) {

					OperationsDesktop.click(executionContext);

					String savings_OpportunitiesxPath = ExecutionContext.getObjectLocator(
							DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(),
							"SavingsOpportunitiesPage", "wTxt_Savings opportunities", Browser);
					executionContext.setXpathDataPair(savings_OpportunitiesxPath, "");

					OperationsDesktop.wait_For_Object(executionContext);

					for (String string : currentSavingOptionsList) {

						String wHeading_Savings_Opportunities = ExecutionContext.getObjectLocator(
								DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(),
								"SavingsOpportunitiesPage", "wHeading_Savings opportunities", Browser);
						wHeading_Savings_Opportunities = wHeading_Savings_Opportunities
								.replace("dynamic_SavingsOpportunities", string.trim());
						executionContext.setXpathDataPair(wHeading_Savings_Opportunities, "");
						OperationsDesktop.exist(executionContext);

					}

					String wBtn_ShowAlternative = ExecutionContext.getObjectLocator(
							DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(),
							"MyPrescriptionsFinderPage", "wBtn_ShowAlternative", Browser);
					executionContext.setXpathDataPair(wBtn_ShowAlternative, "");

					if (OperationsDesktop.exist(executionContext)) {

						OperationsDesktop.click(executionContext);

						for (String string : currentAlternativeOptionList) {

							String wHeading_Alternatives = ExecutionContext.getObjectLocator(
									DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(),
									"SavingsOpportunitiesPage", "wHeading_Alternatives", Browser);
							wHeading_Alternatives = wHeading_Alternatives.replace("dynamic_Alternatives",
									string.trim());
							executionContext.setXpathDataPair(wHeading_Alternatives, "");

							OperationsDesktop.exist(executionContext);

						}
					}
				}
				String wBreadCrumb_PrescriptionSavingsFinder = ExecutionContext.getObjectLocator(
						DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(),
						"SavingsOpportunitiesPage", "wBreadCrumb_PrescriptionSavingsFinder", Browser);
				executionContext.setXpathDataPair(wBreadCrumb_PrescriptionSavingsFinder, "");

				OperationsDesktop.click_Java_Script(executionContext);
			} 
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
			reportUtility.setStatusOfOperationForStep(executionContext, false);
		}
		reportUtility.finalStatusSetupToExecuteForEveryStep(executionContext);

	}*/
	
}
	

