package test.java.stepdefs.com.cvshealth.digital.cat.savingtools;

import org.junit.Assert;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import test.java.stepdefs.com.cvshealth.digital.library.AbstractStepDefinition;
import test.java.stepdefs.com.cvshealth.digital.library.DBCacheSingleton;
import test.java.stepdefs.com.cvshealth.digital.library.ExceptionHandler;
import test.java.stepdefs.com.cvshealth.digital.library.ExecutionContext;
import test.java.stepdefs.com.cvshealth.digital.library.OperationsDesktop;
import test.java.stepdefs.com.cvshealth.digital.library.PropertyFileLoader;

public class SavingsToolErrorMessages extends AbstractStepDefinition {

	@Given("^navigates to prescription savings screen using prescription savings finder option under My Prescriptions for error$")
	public void navigates_to_prescription_savings_screen_using_prescription_savings_finder_option_under_My_Prescriptions_for_error() {
		// Write code here that turns the phrase above into concrete actions
		reportUtility.performInitialSetupForStep(executionContext);
		try {

			String myPrescriptionXPath=ExecutionContext.getObjectLocator(DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "ICE_Pharmacy_LoginPage","wLnk_MyPrescriptions",Browser);
			executionContext.setXpathDataPair(myPrescriptionXPath, "");
			OperationsDesktop.mouse_Hover(executionContext);
			
			String prescriptionSavingFinderLinks=ExecutionContext.getObjectLocator(DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "ICE_Pharmacy_LoginPage","wLnk_PrescriptionsSavingsFinder",Browser);
			executionContext.setXpathDataPair(prescriptionSavingFinderLinks, "");
			OperationsDesktop.click(executionContext);
			
			String messageXpath = ExecutionContext.getObjectLocator(
					DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "MyPrescriptionsFinderPage",
					"wTxt_prescriptionSavingsNames", Browser);
			String updatedmessageXpath = messageXpath.replaceAll("dynamic_prescSavingsNames", "Please try again later");
			executionContext.setXpathDataPair(updatedmessageXpath, "");
			OperationsDesktop.wait_For_Object(executionContext);

		} catch (Exception e) {
			ExceptionHandler.handleException(e);
			reportUtility.setStatusOfOperationForStep(executionContext, false);

		}
		reportUtility.finalStatusSetupToExecuteForEveryStep(executionContext);
	}

	

	@Then("^user should see correct erorr message on the UI \"([^\"]*)\", \"([^\"]*)\"$")
	public void user_should_see_correct_erorr_message_on_the_UI(String messageHeader, String messageBody) {
		// Write code here that turns the phrase above into concrete actions
		reportUtility.performInitialSetupForStep(executionContext);
		try {

			// System.out.println(System.getProperties());
			String messageHeaderXpath = ExecutionContext.getObjectLocator(
					DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "MyPrescriptionsFinderPage",
					"wTxt_prescriptionSavingsNames", Browser);
			String updatedmessageHeaderXpath = messageHeaderXpath.replaceAll("dynamic_prescSavingsNames", messageHeader.trim());
			executionContext.setXpathDataPair(updatedmessageHeaderXpath, "");
			OperationsDesktop.exist(executionContext);
			
			String messageBodyXpath = ExecutionContext.getObjectLocator(
					DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "MyPrescriptionsFinderPage",
					"wTxt_prescriptionSavingsNames", Browser);
			String updatedmessageBodyXpath = messageBodyXpath.replaceAll("dynamic_prescSavingsNames", messageBody.trim());
			executionContext.setXpathDataPair(updatedmessageBodyXpath, "");
			OperationsDesktop.exist(executionContext);

		} catch (Exception e) {
			ExceptionHandler.handleException(e);
			reportUtility.setStatusOfOperationForStep(executionContext, false);

		}
		reportUtility.finalStatusSetupToExecuteForEveryStep(executionContext);
	}
	
	@Then("^user should not see erorr message on the UI \"([^\"]*)\", \"([^\"]*)\"$")
	public void user_should_not_see_erorr_message_on_the_UI(String messageHeader, String messageBody) {
		// Write code here that turns the phrase above into concrete actions
		reportUtility.performInitialSetupForStep(executionContext);
		try {

			// System.out.println(System.getProperties());
			String messageHeaderXpath = ExecutionContext.getObjectLocator(
					DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "MyPrescriptionsFinderPage",
					"wTxt_prescriptionSavingsNames", Browser);
			String updatedmessageHeaderXpath = messageHeaderXpath.replaceAll("dynamic_prescSavingsNames", messageHeader.trim());
			executionContext.setXpathDataPair(updatedmessageHeaderXpath, "");
			OperationsDesktop.not_Exist(executionContext);
			
			String messageBodyXpath = ExecutionContext.getObjectLocator(
					DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "MyPrescriptionsFinderPage",
					"wTxt_prescriptionSavingsNames", Browser);
			String updatedmessageBodyXpath = messageBodyXpath.replaceAll("dynamic_prescSavingsNames", messageBody.trim());
			executionContext.setXpathDataPair(updatedmessageBodyXpath, "");
			OperationsDesktop.not_Exist(executionContext);

		} catch (Exception e) {
			ExceptionHandler.handleException(e);
			reportUtility.setStatusOfOperationForStep(executionContext, false);

		}
		reportUtility.finalStatusSetupToExecuteForEveryStep(executionContext);
	}
	
	@When("^user requested proactive TALT savings opportunity and request has been confirmed to get error$")
	public void user_requested_proactive_TALT_savings_opportunity_and_request_has_been_confirmed_to_get_error() {

		reportUtility.performInitialSetupForStep(executionContext);
		try {
			//click on consult my prescriber
			String requestTALTxPath = ExecutionContext.getObjectLocator("SavingsOpportunitiesPage", "wBtn_RequestGeneric", Browser);
			executionContext.setXpathDataPair(requestTALTxPath, "");
			OperationsDesktop.click(executionContext);
			//wait for modal
			String wBtn_SubmitSavingsRequest = ExecutionContext.getObjectLocator("SavingsOpportunitiesPage","wBtn_SubmitSavingsRequest", Browser);
			executionContext.setXpathDataPair(wBtn_SubmitSavingsRequest, "");
			OperationsDesktop.wait_For_Object(executionContext);
			//click on submit in modal pop up
			//String wBtn_SubmitSavingsRequest = ExecutionContext.getObjectLocator("SavingsOpportunitiesPage","wBtn_SubmitSavingsRequest", Browser);
			executionContext.setXpathDataPair(wBtn_SubmitSavingsRequest, "");
			OperationsDesktop.click(executionContext);
			//check for congratulations text for confirmation
			/*String wMsg_Congratulations = ExecutionContext.getObjectLocator("Savings status","wMsg_Congratulations", Browser);
			executionContext.setXpathDataPair(wMsg_Congratulations, "");
			OperationsDesktop.wait_For_Object(executionContext);*/
						
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
			reportUtility.setStatusOfOperationForStep(executionContext, false);
		}
		reportUtility.finalStatusSetupToExecuteForEveryStep(executionContext);
	}

}
