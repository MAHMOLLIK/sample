package test.java.stepdefs.com.cvshealth.digital.cat.savingtools;

import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import test.java.stepdefs.com.cvshealth.digital.library.AbstractStepDefinition;

public class OpinionLabSurvey extends AbstractStepDefinition {

	@When("^user navigates to \"([^\"]*)\"$")
	public void user_navigates_to(String arg1) {
		// Write code here that turns the phrase above into concrete actions
		
	}

	@Then("^user should not get opinion lab survey modal on the screen$")
	public void user_should_not_get_opinion_lab_survey_modal_on_the_screen() {
	    // Write code here that turns the phrase above into concrete actions
	}
	
	@When("^user navigates to \"([^\"]*)\" using menu option under My Prescriptions$")
	public void user_navigates_to_using_menu_option_under_My_Prescriptions(String arg1) {
		// Write code here that turns the phrase above into concrete actions

	}

	@Then("^user should get opinion lab survey modal on the screen$")
	public void user_should_get_opinion_lab_survey_modal_on_the_screen() {
		// Write code here that turns the phrase above into concrete actions

	}

	@Then("^submit the survey$")
	    public void submit_the_survey() {
	        // Write code here that turns the phrase above into concrete actions
	}

}
