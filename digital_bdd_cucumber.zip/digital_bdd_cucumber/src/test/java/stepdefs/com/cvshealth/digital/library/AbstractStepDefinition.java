package test.java.stepdefs.com.cvshealth.digital.library;

import test.java.stepdefs.com.cvshealth.digital.library.ExecutionContext;
import test.java.stepdefs.com.cvshealth.digital.library.OperationsDesktop;

/** 
* <p style="font-family:Arial;">
* <b>DESCRIPTION: This Class calls instances of required classes and should be extended by every StepDefinition Class
* <br><br>
* Author: - ACOE Team
* <br><br>
* Date Created: 05/03/2019
* <br><br>Revision History: 
* <br>1.0: 
* <br>
* </b></P> 
* 
*/
public abstract class AbstractStepDefinition {

	//This member is used to store object of operationDesktop class
	public OperationsDesktop operationsdesktop = new OperationsDesktop();
	
	//This member is used to store object of report utility class
	public ReportUtility reportUtility = new ReportUtility();

	//This member is used to store object of execution context class
	public ExecutionContext executionContext = ExecutionContext.getStore_ExecutionContextInstanceForThread().get(Thread.currentThread().getId());

	//This member is used to store current browser name
	public String Browser = ExecutionContext.getBrowser();
	


	//Need to check the purpose of this method
	protected void populateExecutionContectfromDBCach(String objID) {
		DBCacheSingleton.getInstance().getHashMapObjectRepositoryData().get(objID + "|" + Browser);		
	}

}



