package test.java.stepdefs.com.cvshealth.digital.cat.savingtools;



import java.util.List;

import org.junit.Assert;
import org.openqa.selenium.WebElement;

import cucumber.api.DataTable;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import test.java.stepdefs.com.cvshealth.digital.library.AbstractStepDefinition;
import test.java.stepdefs.com.cvshealth.digital.library.DBCacheSingleton;
import test.java.stepdefs.com.cvshealth.digital.library.ExceptionHandler;
import test.java.stepdefs.com.cvshealth.digital.library.ExecutionContext;
import test.java.stepdefs.com.cvshealth.digital.library.OperationsDesktop;
import test.java.stepdefs.com.cvshealth.digital.library.PropertyFileLoader;
import test.java.stepdefs.com.cvshealth.digital.library.ReportUtility;
 

public class SavingTools extends AbstractStepDefinition {
	
	@Given("^CVS dot com user logged into ICE Pharmacy using valid credentials \"([^\"]*)\", \"([^\"]*)\"$")
	public void cvs_dot_com_user_logged_into_ICE_Pharmacy_using_valid_credentials(String userName, String password) {
		// Write code here that turns the phrase above into concrete actions
		reportUtility.performInitialSetupForStep(executionContext);
		try {
			
			System.out.println(System.getProperties());
			//Get required data from data base
			userName=executionContext.getExecutionData("username", userName);
			password=executionContext.getExecutionData("password", password);	
			
			/*for each method call, user should set xpath-data pair and then call method
			pass empty string respectively when xpath/data is not required to call the method*/
			
			//navigateUrl - set url to execution context
			//set current execution data
			executionContext.setXpathDataPair("", PropertyFileLoader.getInstance().getURL());
			
			//in this example only URL is expected
			//execute generic method inside the assert statement to terminate in case of failure
			Assert.assertTrue("URL "+PropertyFileLoader.getInstance().getURL()+ " navigated successfully", OperationsDesktop.navigateURL(executionContext));
			
			//read xpath for email address edit box object
			//String userNameXPath=ExecutionContext.getObjectLocator(DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "ICE_PharmacyPage","wEdt_EmailAddress",Browser);			
			String userNameXPath=ExecutionContext.getObjectLocator("ICE_PharmacyPage","wEdt_EmailAddress",Browser);
			//set current object xpath, data is not required for "wait_for_object" method
			executionContext.setXpathDataPair(userNameXPath, "");			
			//set current execution context and advance to the next working element
			OperationsDesktop.wait_For_Object(executionContext);
			
			executionContext.setXpathDataPair(userNameXPath, userName);
			//set current xpath and data for input method
			OperationsDesktop.input(executionContext);
			
			//set current xpath and current data for input function
			//String userPasswordxPath=ExecutionContext.getObjectLocator(DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "ICE_PharmacyPage","wEdt_Password",Browser);
			String userPasswordxPath = ExecutionContext.getObjectLocator("ICE_PharmacyPage", "wEdt_Password", Browser);
			executionContext.setXpathDataPair(userPasswordxPath, password);
			OperationsDesktop.input(executionContext);

			
			//click
			String signInButtonXPath=ExecutionContext.getObjectLocator(DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "ICE_PharmacyPage","wBtn_SignIn",Browser);
			executionContext.setXpathDataPair(signInButtonXPath, "");
			OperationsDesktop.click(executionContext);
			
			//wait_For_Object
			String signoutButtonXPath=ExecutionContext.getObjectLocator(DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "ICE_Pharmacy_LoginPage","wLnk_SignOut",Browser);
			executionContext.setXpathDataPair(signoutButtonXPath, "");
			OperationsDesktop.wait_For_Object(executionContext);
						
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
			reportUtility.setStatusOfOperationForStep(executionContext, false);

		}
		reportUtility.finalStatusSetupToExecuteForEveryStep(executionContext);
	}


	@Given("^navigates to prescription savings screen using prescription savings finder option under My Prescriptions$")
	public void navigates_to_prescription_savings_screen_using_prescription_savings_finder_option_under_My_Prescriptions() {
		// Write code here that turns the phrase above into concrete actions
		reportUtility.performInitialSetupForStep(executionContext);
		try {
			String myPrescriptionXPath=ExecutionContext.getObjectLocator(DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "ICE_Pharmacy_LoginPage","wLnk_MyPrescriptions",Browser);
			executionContext.setXpathDataPair(myPrescriptionXPath, "");
			OperationsDesktop.mouse_Hover(executionContext);
			
			String prescriptionSavingFinderLinks=ExecutionContext.getObjectLocator(DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "ICE_Pharmacy_LoginPage","wLnk_PrescriptionsSavingsFinder",Browser);
			executionContext.setXpathDataPair(prescriptionSavingFinderLinks, "");
			OperationsDesktop.click(executionContext);
			
			String howCVSFindsMySavings=ExecutionContext.getObjectLocator(DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "MyPrescriptionsFinderPage","wTxt_howCVS_findsMySavings",Browser);
			executionContext.setXpathDataPair(howCVSFindsMySavings, "");
			OperationsDesktop.wait_For_Object(executionContext);
			
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
			reportUtility.setStatusOfOperationForStep(executionContext, false);

		}
		reportUtility.finalStatusSetupToExecuteForEveryStep(executionContext);
	}

	@Then("^User is able to see savings options for these prescriptions \"([^\"]*)\"$")
	public void user_is_able_to_see_savings_options_for_these_prescriptions(String prescription_saving) {
		// Write code here that turns the phrase above into concrete actions

		reportUtility.performInitialSetupForStep(executionContext);
		try {
			prescription_saving=executionContext.getExecutionData("prescription_savings", prescription_saving);
			String[] prescription_savings = prescription_saving.split(",");

			String drugXPath=ExecutionContext.getObjectLocator(DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "MyPrescriptionsFinderPage","wTxt_prescriptionSavingsNames",Browser);
			for (String string : prescription_savings) {

				String updatedDrugXPath=drugXPath.replaceAll("dynamic_prescSavingsNames", string.trim());
				executionContext.setXpathDataPair(updatedDrugXPath, "");
				OperationsDesktop.exist(executionContext);

			}
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
			reportUtility.setStatusOfOperationForStep(executionContext, false);

		}
		reportUtility.finalStatusSetupToExecuteForEveryStep(executionContext);

	}

	@Then("^user can logout and close the browser$")
	public void user_can_logout_and_close_the_browser() {
		// Write code here that turns the phrase above into concrete actions

		reportUtility.performInitialSetupForStep(executionContext);
		try {
			String signOutXPath=ExecutionContext.getObjectLocator(DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "ICE_Pharmacy_LoginPage","wLnk_SignOut",Browser);
			executionContext.setXpathDataPair(signOutXPath, "");
			OperationsDesktop.click(executionContext);
			
			String signOutConfirmationXPath=ExecutionContext.getObjectLocator(DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "ICE_PharmacyPage","wTxt_You_are_SignedOut",Browser);
			executionContext.setXpathDataPair(signOutConfirmationXPath, "");
			OperationsDesktop.wait_For_Object(executionContext);
			
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
			reportUtility.setStatusOfOperationForStep(executionContext, false);

		}
		reportUtility.finalStatusSetupToExecuteForEveryStep(executionContext);

	}
	
	/***********************************************************************************************************************
	 * Second Scenario
	 * 
	 ************************************************************************************************************************/

	@Given("^CVS dot com user logged into ICE Pharmacy using valid credentials$")
	public void cvs_dot_com_user_logged_into_ICE_Pharmacy_using_valid_credentials(DataTable objDataTable) {
		
		reportUtility.performInitialSetupForStep(executionContext);
		try {
			//get data
			String userName=executionContext.getExecutionData(objDataTable, "username");
			String password=executionContext.getExecutionData(objDataTable, "password");

			/*for each method call, user should set xpath-data pair and then call method
			pass empty string respectively when xpath/data is not required to call the method*/
			
			executionContext.setXpathDataPair("", PropertyFileLoader.getInstance().getURL());
			
			//in this example only URL is expected
			//execute generic method inside the assert statement to terminate in case of failure
			Assert.assertTrue("URL "+PropertyFileLoader.getInstance().getURL()+ " navigated successfully",OperationsDesktop.navigateURL(executionContext));

			//set current xpath and data for input method
			String userNameXPath = ExecutionContext.getObjectLocator(DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "ICE_PharmacyPage", "wEdt_EmailAddress", Browser);
			executionContext.setXpathDataPair(userNameXPath, userName);
			
			//both the operations can be invoked sequentially as both require same xPath and data which has been set already
			OperationsDesktop.wait_For_Object(executionContext);
			OperationsDesktop.input(executionContext);
			
			String userPassword = ExecutionContext.getObjectLocator(DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), 
					"ICE_PharmacyPage",	"wEdt_Password", Browser);
			executionContext.setXpathDataPair(userPassword, password);
			OperationsDesktop.input(executionContext);

			String signInButtonXPath = ExecutionContext.getObjectLocator(DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "ICE_PharmacyPage", "wBtn_SignIn",	Browser);
			executionContext.setXpathDataPair(signInButtonXPath, "");
			OperationsDesktop.click(executionContext);

			String signoutButtonXPath = ExecutionContext.getObjectLocator(DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "ICE_Pharmacy_LoginPage", "wLnk_SignOut", Browser);
			executionContext.setXpathDataPair(signoutButtonXPath, "");
			OperationsDesktop.wait_For_Object(executionContext);
			
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
			reportUtility.setStatusOfOperationForStep(executionContext, false);
		}
		reportUtility.finalStatusSetupToExecuteForEveryStep(executionContext);

	}

	@Given("^navigates to prescription savings screen using savings banner on ICE home page$")
	public void navigates_to_prescription_savings_screen_using_savings_banner_on_ICE_home_page() {
		// Write code here that turns the phrase above into concrete actions

		reportUtility.performInitialSetupForStep(executionContext);
		try {

			String SearchForSavingsxPath = ExecutionContext.getObjectLocator(
					DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "ICE_Pharmacy_LoginPage",
					"wBtn_SearchForSavings", Browser);
			executionContext.setXpathDataPair(SearchForSavingsxPath, "");
			OperationsDesktop.wait_For_Object(executionContext);
			OperationsDesktop.click_Java_Script(executionContext);

			String howCVS_findsMySavingsxPath = ExecutionContext.getObjectLocator(
					DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "MyPrescriptionsFinderPage",
					"wTxt_howCVS_findsMySavings", Browser);
			executionContext.setXpathDataPair(howCVS_findsMySavingsxPath, "");			
			
			OperationsDesktop.wait_For_Object(executionContext);

		} catch (Exception e) {
			ExceptionHandler.handleException(e);
			reportUtility.setStatusOfOperationForStep(executionContext, false);
		}
		reportUtility.finalStatusSetupToExecuteForEveryStep(executionContext);
	}

	@When("^user clicks on each prescription they should see correct opportunities$")
	public void user_clicks_on_each_prescription_they_should_see_correct_opportunities(DataTable objDataTable) {

		reportUtility.performInitialSetupForStep(executionContext);
		try {

			List<String> prescriptionList=executionContext.getExecutionDataList(objDataTable, "prescription");
			List<String> savingOpportunityList=executionContext.getExecutionDataList(objDataTable, "savings_opportunities");
			List<String> alternativeList=executionContext.getExecutionDataList(objDataTable, "alternatives");

			for (int i=0;i<prescriptionList.size();i++) {

				String currentPrescription=prescriptionList.get(i);

				String[] currentSavingOptionsList=savingOpportunityList.get(i).split(",");
				String[] currentAlternativeOptionList=alternativeList.get(i).split(",");

				String searchForSavingsxPath = ExecutionContext.getObjectLocator(
						DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(),
						"MyPrescriptionsFinderPage", "wTxt_prescriptionSavingsNames", Browser);
				searchForSavingsxPath = searchForSavingsxPath.replace("dynamic_prescSavingsNames",
						currentPrescription.trim());
				executionContext.setXpathDataPair(searchForSavingsxPath, "");

				if (OperationsDesktop.exist(executionContext)) {

					OperationsDesktop.click(executionContext);

					String savings_OpportunitiesxPath = ExecutionContext.getObjectLocator(
							DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(),
							"SavingsOpportunitiesPage", "wTxt_Savings opportunities", Browser);
					executionContext.setXpathDataPair(savings_OpportunitiesxPath, "");

					OperationsDesktop.wait_For_Object(executionContext);

					for (String string : currentSavingOptionsList) {

						String wHeading_Savings_Opportunities = ExecutionContext.getObjectLocator(
								DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(),
								"SavingsOpportunitiesPage", "wHeading_Savings opportunities", Browser);
						wHeading_Savings_Opportunities = wHeading_Savings_Opportunities
								.replace("dynamic_SavingsOpportunities", string.trim());
						executionContext.setXpathDataPair(wHeading_Savings_Opportunities, "");
						OperationsDesktop.exist(executionContext);

					}

					String wBtn_ShowAlternative = ExecutionContext.getObjectLocator(
							DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(),
							"MyPrescriptionsFinderPage", "wBtn_ShowAlternative", Browser);
					executionContext.setXpathDataPair(wBtn_ShowAlternative, "");

					if (OperationsDesktop.exist(executionContext)) {

						OperationsDesktop.click(executionContext);

						for (String string : currentAlternativeOptionList) {

							String wHeading_Alternatives = ExecutionContext.getObjectLocator(
									DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(),
									"SavingsOpportunitiesPage", "wHeading_Alternatives", Browser);
							wHeading_Alternatives = wHeading_Alternatives.replace("dynamic_Alternatives",
									string.trim());
							executionContext.setXpathDataPair(wHeading_Alternatives, "");

							OperationsDesktop.exist(executionContext);

						}
					}
				}
				String wBreadCrumb_PrescriptionSavingsFinder = ExecutionContext.getObjectLocator(
						DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(),
						"SavingsOpportunitiesPage", "wBreadCrumb_PrescriptionSavingsFinder", Browser);
				executionContext.setXpathDataPair(wBreadCrumb_PrescriptionSavingsFinder, "");

				OperationsDesktop.click_Java_Script(executionContext);
			} 
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
			reportUtility.setStatusOfOperationForStep(executionContext, false);
		}
		reportUtility.finalStatusSetupToExecuteForEveryStep(executionContext);

	}

	/***********************************************************************************************************************
	 * Third Scenario
	 * 
	 ************************************************************************************************************************/
	@When("^user navigates to savings search page$")
	public void user_navigates_to_savings_search_page(){
	    // Write code here that turns the phrase above into concrete actions
		
		reportUtility.performInitialSetupForStep(executionContext);
		try {

			//Get activity object / data
			String wLnk_Search_savings_by_drugName = ExecutionContext.getObjectLocator(
					DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "MyPrescriptionsFinderPage",
					"wLnk_Search_savings_by_drugName", Browser);
			executionContext.setXpathDataPair(wLnk_Search_savings_by_drugName, "");
			
			OperationsDesktop.wait_For_Object(executionContext);
			OperationsDesktop.click(executionContext);

			String wInput_Medication = ExecutionContext.getObjectLocator(
					DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "FindAndPriceMedicationPage",
					"wInput_Medication", Browser);
			executionContext.setXpathDataPair(wInput_Medication, "");
			OperationsDesktop.wait_For_Object(executionContext);

		}
	 	catch(Exception e){
	 		ExceptionHandler.handleException(e);
			reportUtility.setStatusOfOperationForStep(executionContext, false);
			
		}
	   reportUtility.finalStatusSetupToExecuteForEveryStep(executionContext);
	}

	@When("^search for \"([^\"]*)\" and selects drug \"([^\"]*)\" from search results$")
	public void search_for_and_selects_drug_from_search_results(String drugPartialName, String drugFullName) {
		// Write code here that turns the phrase above into concrete actions

		reportUtility.performInitialSetupForStep(executionContext);
		try{
			//Parse data as per local / Data Base
			drugPartialName=executionContext.getExecutionData("searchString", drugPartialName);
			drugFullName=executionContext.getExecutionData("selectString", drugFullName);

			//Get activity object / data
			String wInput_Medication = ExecutionContext.getObjectLocator(
					DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "FindAndPriceMedicationPage",
					"wInput_Medication", Browser);
			executionContext.setXpathDataPair(wInput_Medication, drugPartialName);
			OperationsDesktop.input(executionContext);

			String wSelect_Medication = ExecutionContext.getObjectLocator(
					DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "FindAndPriceMedicationPage",
					"wSelect_Medication", Browser);
			wSelect_Medication=wSelect_Medication.replace("dynamic_Medication", drugFullName.trim());
			executionContext.setXpathDataPair(wSelect_Medication, drugFullName);
			OperationsDesktop.wait_For_Object(executionContext);
			OperationsDesktop.click(executionContext);

			String wBtn_Request = ExecutionContext.getObjectLocator(
					DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "FindAndPriceMedicationPage",
					"wBtn_Request", Browser);
			executionContext.setXpathDataPair(wBtn_Request, "");

			OperationsDesktop.wait_For_Object(executionContext);

		}
	 	catch(Exception e){
	 		ExceptionHandler.handleException(e);
			reportUtility.setStatusOfOperationForStep(executionContext, false);
			
		}
	   reportUtility.finalStatusSetupToExecuteForEveryStep(executionContext);

	}

	@Then("^user should see these opportunities$")
	public void user_should_see_these_opportunities(DataTable objDataTable)  {

		reportUtility.performInitialSetupForStep(executionContext);
		try{
			String savingOpportunity=executionContext.getExecutionData(objDataTable, "savings_opportunities");
			String alternateOption=executionContext.getExecutionData(objDataTable, "alternatives");

			String[] savingOpportunityList=savingOpportunity.split(",");
			String[] alternateOptionList=alternateOption.split(",");


			for (String string : savingOpportunityList) {

				String wHeading_Savings_Opportunities = ExecutionContext.getObjectLocator(
						DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "FindAndPriceMedicationPage",
						"wHeading_Savings opportunities", Browser);
				wHeading_Savings_Opportunities=wHeading_Savings_Opportunities.replace("dynamic_SavingsOpportunities", string.trim());
				executionContext.setXpathDataPair(wHeading_Savings_Opportunities, "");
				OperationsDesktop.exist(executionContext);

			}

			//Get activity object / data
			String wBtn_ShowMoreOptions = ExecutionContext.getObjectLocator(
					DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "FindAndPriceMedicationPage",
					"wBtn_ShowMoreOptions", Browser);
			executionContext.setXpathDataPair(wBtn_ShowMoreOptions, "");

			if (OperationsDesktop.exist(executionContext)) {
				OperationsDesktop.click(executionContext);
				for (String string : alternateOptionList) {

					String wTxt_ValidateDrugOptions = ExecutionContext.getObjectLocator(
							DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "FindAndPriceMedicationPage",
							"wTxt_ValidateDrugOptions", Browser);
					wTxt_ValidateDrugOptions=wTxt_ValidateDrugOptions.replace("dynamic_Medication", string.trim());
					executionContext.setXpathDataPair(wTxt_ValidateDrugOptions, "");
					OperationsDesktop.exist(executionContext);

				}
			}
		}
		catch(Exception e){
			ExceptionHandler.handleException(e);
			reportUtility.setStatusOfOperationForStep(executionContext, false);

		}
		reportUtility.finalStatusSetupToExecuteForEveryStep(executionContext);
	}
	
	/***********************************************************************************************************************
	 * Fourth Scenario
	 * 
	 ************************************************************************************************************************/
	
	@When("^user click on \"([^\"]*)\" prescription$")
	public void user_click_on_prescription(String drugName)  {

		reportUtility.performInitialSetupForStep(executionContext);
		try {
			//Parse data form local / Data Base
			drugName=executionContext.getExecutionData("prescription", drugName);
			
			//Get activity object / data
			String searchForSavingsxPath = ExecutionContext.getObjectLocator(
					DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "MyPrescriptionsFinderPage",
					"wTxt_prescriptionSavingsNames", Browser);
			searchForSavingsxPath = searchForSavingsxPath.replace("dynamic_prescSavingsNames", drugName.trim());
			executionContext.setXpathDataPair(searchForSavingsxPath, "");
			OperationsDesktop.click(executionContext);

			String wBtn_RequestGeneric = ExecutionContext.getObjectLocator(
					DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "SavingsOpportunitiesPage",
					"wBtn_RequestGeneric", Browser);
			executionContext.setXpathDataPair(wBtn_RequestGeneric, "");
			OperationsDesktop.wait_For_Object(executionContext);

		} catch (Exception e) {
			ExceptionHandler.handleException(e);
			reportUtility.setStatusOfOperationForStep(executionContext, false);

		}
		reportUtility.finalStatusSetupToExecuteForEveryStep(executionContext);

	}

	@When("^request generic medication on savings oppurtunities screen$")
	public void request_generic_medication_on_savings_oppurtunities_screen() {

		try {
			//Get activity object / data
			String wBtn_RequestGeneric = ExecutionContext.getObjectLocator(
					DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "SavingsOpportunitiesPage",
					"wBtn_RequestGeneric", Browser);
			executionContext.setXpathDataPair(wBtn_RequestGeneric, "");
			OperationsDesktop.click(executionContext);

			String wBtn_SubmitSavingsRequest = ExecutionContext.getObjectLocator(
					DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "SavingsOpportunitiesPage",
					"wBtn_SubmitSavingsRequest", Browser);
			executionContext.setXpathDataPair(wBtn_SubmitSavingsRequest, "");
			OperationsDesktop.wait_For_Object(executionContext);
			
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
			reportUtility.setStatusOfOperationForStep(executionContext, false);

		}
		reportUtility.finalStatusSetupToExecuteForEveryStep(executionContext);
	}
	
	@When("^request low-cost alternative medication on savings oppurtunities screen$")
	public void request_low_cost_alternative_medication_on_savings_oppurtunities_screen() {

		try {
			//Get activity object / data
			String wBtn_RequestTALT = ExecutionContext.getObjectLocator(
					DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "SavingsOpportunitiesPage",
					"wBtn_RequestTALT", Browser);
			executionContext.setXpathDataPair(wBtn_RequestTALT, "");
			OperationsDesktop.click(executionContext);

			String wBtn_SubmitSavingsRequest = ExecutionContext.getObjectLocator(
					DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "SavingsOpportunitiesPage",
					"wBtn_SubmitSavingsRequest", Browser);
			executionContext.setXpathDataPair(wBtn_SubmitSavingsRequest, "");
			OperationsDesktop.wait_For_Object(executionContext);
			
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
			reportUtility.setStatusOfOperationForStep(executionContext, false);

		}
		reportUtility.finalStatusSetupToExecuteForEveryStep(executionContext);
	}
	
	@When("^request (\\d+)Day alternative medication on savings oppurtunities screen$")
	public void request_Day_alternative_medication_on_savings_oppurtunities_screen(int arg1) throws Throwable {

		try {
			//Get activity object / data
			String wBtn_Request90Day = ExecutionContext.getObjectLocator(
					DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "SavingsOpportunitiesPage",
					"wBtn_Request90Day", Browser);
			executionContext.setXpathDataPair(wBtn_Request90Day, "");
			OperationsDesktop.click(executionContext);

			String wBtn_SubmitSavingsRequest = ExecutionContext.getObjectLocator(
					DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "SavingsOpportunitiesPage",
					"wBtn_SubmitSavingsRequest", Browser);
			executionContext.setXpathDataPair(wBtn_SubmitSavingsRequest, "");
			OperationsDesktop.wait_For_Object(executionContext);
			
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
			reportUtility.setStatusOfOperationForStep(executionContext, false);

		}
		reportUtility.finalStatusSetupToExecuteForEveryStep(executionContext);
	}
	@When("^continue to submit the request from modal$")
	public void continue_to_submit_the_request_from_modal() {
		// Write code here that turns the phrase above into concrete actions

		try {
			//Get activity object / data
			String wBtn_SubmitSavingsRequest = ExecutionContext.getObjectLocator(
					DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "SavingsOpportunitiesPage",
					"wBtn_SubmitSavingsRequest", Browser);
			executionContext.setXpathDataPair(wBtn_SubmitSavingsRequest, "");
			OperationsDesktop.click(executionContext);
			
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
			reportUtility.setStatusOfOperationForStep(executionContext, false);

		}
		reportUtility.finalStatusSetupToExecuteForEveryStep(executionContext);
	}

	@Then("^request should be submitted successfully$")
	public void request_should_be_submitted_successfully() {
		// Write code here that turns the phrase above into concrete actions

		try {
			//Get activity object / data
			String wMsg_Congratulations = ExecutionContext.getObjectLocator(
					DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "Savings status",
					"wMsg_Congratulations", Browser);
			executionContext.setXpathDataPair(wMsg_Congratulations, "");
			OperationsDesktop.wait_For_Object(executionContext);
			
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
			reportUtility.setStatusOfOperationForStep(executionContext, false);

		}
		reportUtility.finalStatusSetupToExecuteForEveryStep(executionContext);
	}

	@Then("^correct message should be displayed to the user$")
	public void correct_message_should_be_displayed_to_the_user(DataTable objDataTable) {

		try {
			//Parse data form local / Data Base
			String successMessage=executionContext.getExecutionData(objDataTable,"successMessage");

			//Get activity object / data
			String wMsg_SuccessMsg = ExecutionContext.getObjectLocator(
					DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "Savings status",
					"wMsg_SuccessMsg", Browser);
			executionContext.setXpathDataPair(wMsg_SuccessMsg, successMessage);
			OperationsDesktop.validate_Object_Text(executionContext);
			
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
			reportUtility.setStatusOfOperationForStep(executionContext, false);

		}
		reportUtility.finalStatusSetupToExecuteForEveryStep(executionContext);
	}

	@Then("^correct pharmacy address should be displayed$")
	public void correct_pharmacy_address_should_be_displayed(DataTable objDataTable) {

		try {
			//Parse data form local / Data Base
			String pharmacyAddress=executionContext.getExecutionData(objDataTable,"pharmacyAddress");

			//Get activity object / data
			String pharmacy_addressxPath = ExecutionContext.getObjectLocator(
					DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "Savings status",
					"wMsg_YourPharmacy", Browser);
			executionContext.setXpathDataPair(pharmacy_addressxPath, pharmacyAddress);
			OperationsDesktop.validate_Object_Text(executionContext);
			
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
			reportUtility.setStatusOfOperationForStep(executionContext, false);

		}
		reportUtility.finalStatusSetupToExecuteForEveryStep(executionContext);
	}

	@Then("^correct prescriber information should be displayed$")
	public void correct_prescriber_information_should_be_displayed(DataTable objDataTable) {

		try {
			//Parse data form local / Data Base
			String prescriberInformation=executionContext.getExecutionData(objDataTable,"prescriberInformation");

			//Get activity object / data
			String prescriberInformationxPath = ExecutionContext.getObjectLocator(
					DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "Savings status",
					"wMsg_YourPrescriber", Browser);
			executionContext.setXpathDataPair(prescriberInformationxPath, prescriberInformation);
			OperationsDesktop.validate_Object_Text(executionContext);
			
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
			reportUtility.setStatusOfOperationForStep(executionContext, false);

		}
		reportUtility.finalStatusSetupToExecuteForEveryStep(executionContext);
	}
	
	@Then("^verify saving message \"([^\"]*)\" displayed on the banner along with text on the button \"([^\"]*)\"$")
	public void verify_saving_message_saving_message_displayed_on_the_banner_along_with_text_button_saving_cta(String savings_message, String saving_cta) {
		
		reportUtility.performInitialSetupForStep(executionContext);
		try {
			//get the savings message and validate
			String savingsMessage = executionContext.getExecutionData("savingsMessage", savings_message);
			String savingsMessageXpath = ExecutionContext.getObjectLocator("ICE_Pharmacy_HomePage", "wTxt_Banner_Message_PotentialSavings1", Browser);
			executionContext.setXpathDataPair(savingsMessageXpath, savingsMessage);
			OperationsDesktop.validate_Object_Text(executionContext);
			
			//retrieve button text and validate
			
			String savingsButtonLabel = executionContext.getExecutionData("savingsButtonLabel", saving_cta);
			String savingsButtonXpath = ExecutionContext.getObjectLocator("ICE_Pharmacy_HomePage", "wBtn_Savings", Browser);
			executionContext.setXpathDataPair(savingsButtonXpath, savingsButtonLabel);
			OperationsDesktop.validate_Object_Text(executionContext);

		} catch (Exception e) {
			ExceptionHandler.handleException(e);
			reportUtility.setStatusOfOperationForStep(executionContext, false);

		}
		reportUtility.finalStatusSetupToExecuteForEveryStep(executionContext);

	}
	
	@And("^verify disclaimer message \"([^\"]*)\" displayed on the banner$")
	public void verify_disclaimer_message_savings_disclaimer_displayed_on_the_banner(String saving_disclaimer){
		
		reportUtility.performInitialSetupForStep(executionContext);
		try {
			//setting wait time to populate the savings number on the banner
			executionContext.setXpathDataPair("", "5000");
			OperationsDesktop.wait(executionContext);
			
			if ((saving_disclaimer.equals("na")) || (saving_disclaimer.isEmpty())){
				
				String savingsDisclaimerXpath = ExecutionContext.getObjectLocator("ICE_Pharmacy_HomePage", "wTxt_Banner_Message_PotentialSavings2", Browser);
				executionContext.setXpathDataPair(savingsDisclaimerXpath, "");
				OperationsDesktop.not_Exist(executionContext);
			}
			else {
				
				String savingsDisclaimerText = executionContext.getExecutionData("savingsButtonLabel", saving_disclaimer);
				String savingsDisclaimerXpath = ExecutionContext.getObjectLocator("ICE_Pharmacy_HomePage", "wTxt_Banner_Message_PotentialSavings2", Browser);
				executionContext.setXpathDataPair(savingsDisclaimerXpath, savingsDisclaimerText);
				OperationsDesktop.validate_Object_Text(executionContext);
			}
			
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
			reportUtility.setStatusOfOperationForStep(executionContext, false);

		}
		reportUtility.finalStatusSetupToExecuteForEveryStep(executionContext);

	}
	
	@And("^request CDC on savings oppurtunities screen$")
	public void request_CDC_on_savings_oppurtunities_screen(){
		reportUtility.performInitialSetupForStep(executionContext);
		try {
			//Get activity object / data
			String wBtn_RequestGeneric = ExecutionContext.getObjectLocator(
					DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "SavingsOpportunitiesPage",
					"wBtn_RequestCDC", Browser);
			executionContext.setXpathDataPair(wBtn_RequestGeneric, "");
			OperationsDesktop.click(executionContext);

			String wBtn_SubmitSavingsRequest = ExecutionContext.getObjectLocator(
					DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "SavingsOpportunitiesPage",
					"wBtn_SubmitSavingsRequest", Browser);
			executionContext.setXpathDataPair(wBtn_SubmitSavingsRequest, "");
			OperationsDesktop.wait_For_Object(executionContext);
			
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
			reportUtility.setStatusOfOperationForStep(executionContext, false);

		}
		reportUtility.finalStatusSetupToExecuteForEveryStep(executionContext);
	}
	
	@When("^user searches for \"([^\"]*)\"$")
	public void user_searches_for(String drug_name){
		reportUtility.performInitialSetupForStep(executionContext);
		try {
			//enter drug name in search box
			String drugPartialName=executionContext.getExecutionData("searchString", drug_name);
			String wInput_Medication = ExecutionContext.getObjectLocator("FindAndPriceMedicationPage", "wInput_Medication", Browser);
			executionContext.setXpathDataPair(wInput_Medication, drugPartialName);
			OperationsDesktop.input(executionContext);
			//wait for the results
			String wLst_DrugSearchList = ExecutionContext.getObjectLocator("FindAndPriceMedicationPage","wLst_DrugSearchList", Browser);
			//wSelect_Medication=wSelect_Medication.replace("dynamic_Medication", drugPartialName.trim());
			executionContext.setXpathDataPair(wLst_DrugSearchList, drugPartialName);
			OperationsDesktop.wait_For_Object(executionContext);
					
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
			reportUtility.setStatusOfOperationForStep(executionContext, false);
		}
		reportUtility.finalStatusSetupToExecuteForEveryStep(executionContext);
	}

	@Then("^drugs with zero dasys supply and zero qty should not display and number of drugs displayed should match with \"([^\"]*)\"$")
	public void drugs_with_zero_dasys_supply_and_zero_qty_should_not_display_and_number_of_drugs_displayed_should_match_with(String drug_num){
		reportUtility.performInitialSetupForStep(executionContext);
		// get the count of drugs returned by search
		try {
			String wLst_DrugSearchList = ExecutionContext.getObjectLocator("FindAndPriceMedicationPage", "wLst_DrugSearchList", Browser);
			executionContext.setXpathDataPair(wLst_DrugSearchList, "");
			List<WebElement> drugSearchCount = OperationsDesktop.findElements(executionContext.getDriver(), wLst_DrugSearchList);
			int expectedDrugNum = Integer.parseInt(drug_num);
			Assert.assertEquals(expectedDrugNum, drugSearchCount.size());
			ReportUtility.reportStepStatus(executionContext, "expected drugs: " + expectedDrugNum, "actual drugs found: " + drugSearchCount.size(), expectedDrugNum ==  drugSearchCount.size()?true:false);
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
			reportUtility.setStatusOfOperationForStep(executionContext, false);
		}
		
		reportUtility.finalStatusSetupToExecuteForEveryStep(executionContext);
	}
	
	@Then("^Verify savings banner is not displayed$")
	public void verify_savings_banner_is_not_displayed(){
		reportUtility.performInitialSetupForStep(executionContext);
		try {
			//click on Okay button on the modal if exists
			String wBtn_ModalOkay = ExecutionContext.getObjectLocator("ICE_Pharmacy_HomePage", "wBtn_ModalOkay", Browser);
			executionContext.setXpathDataPair(wBtn_ModalOkay, "");
			OperationsDesktop.click_Object_If_Exist(executionContext);
			
			//check for banner is not there
			String wBtn_Savings = ExecutionContext.getObjectLocator("ICE_Pharmacy_HomePage", "wBtn_Savings", Browser);
			executionContext.setXpathDataPair(wBtn_Savings, "");
			OperationsDesktop.not_Exist(executionContext);
			//Boolean isBannerExist = OperationsDesktop.not_Exist(executionContext);
			/*if (!isBannerExist) {
				ReportUtility.reportStepStatus(executionContext, "Banner expected: false", "Banner appeared: " + isBannerExist, true);
			}
			else {
				ReportUtility.reportStepStatus(executionContext, "Banner expected: false", "Banner appeared: " + isBannerExist, false);
			}*/

						
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
			reportUtility.setStatusOfOperationForStep(executionContext, false);
		}
		reportUtility.finalStatusSetupToExecuteForEveryStep(executionContext);
	}
	
	public void verify_savings_banner_is_displayed(){
		reportUtility.performInitialSetupForStep(executionContext);
		try {
			//click on Okay button on the modal if exists
			String wBtn_ModalOkay = ExecutionContext.getObjectLocator("ICE_Pharmacy_HomePage", "wBtn_ModalOkay", Browser);
			executionContext.setXpathDataPair(wBtn_ModalOkay, "");
			OperationsDesktop.click_Object_If_Exist(executionContext);
			
			//check for banner is not there
			String wBtn_Savings = ExecutionContext.getObjectLocator("ICE_Pharmacy_HomePage", "wBtn_Savings", Browser);
			executionContext.setXpathDataPair(wBtn_Savings, "");
			OperationsDesktop.exist(executionContext);
			//Boolean isBannerExist = OperationsDesktop.not_Exist(executionContext);
			/*if (!isBannerExist) {
				ReportUtility.reportStepStatus(executionContext, "Banner expected: false", "Banner appeared: " + isBannerExist, true);
			}
			else {
				ReportUtility.reportStepStatus(executionContext, "Banner expected: false", "Banner appeared: " + isBannerExist, false);
			}*/

						
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
			reportUtility.setStatusOfOperationForStep(executionContext, false);
		}
		reportUtility.finalStatusSetupToExecuteForEveryStep(executionContext);
	}
	
	@Then("^prescription savings finder option under My Prescriptions is not displayed$")
	public void prescription_savings_finder_option_under_My_Prescriptions_is_not_displayed() {
		reportUtility.performInitialSetupForStep(executionContext);
		try {
			//mouse hover
			String myPrescriptionXPath=ExecutionContext.getObjectLocator(DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "ICE_Pharmacy_LoginPage","wLnk_MyPrescriptions",Browser);
			executionContext.setXpathDataPair(myPrescriptionXPath, "");
			OperationsDesktop.mouse_Hover(executionContext);
			//check for prescription savings finder option is not there
			String wLnk_PrescriptionsSavingsFinder = ExecutionContext.getObjectLocator("ICE_Pharmacy_HomePage", "wLnk_PrescriptionsSavingsFinder", Browser);
			executionContext.setXpathDataPair(wLnk_PrescriptionsSavingsFinder, "");
			OperationsDesktop.not_Exist(executionContext);
						
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
			reportUtility.setStatusOfOperationForStep(executionContext, false);
		}
		reportUtility.finalStatusSetupToExecuteForEveryStep(executionContext);
	}
	
	public void prescription_savings_finder_option_under_My_Prescriptions_is_displayed() {
		reportUtility.performInitialSetupForStep(executionContext);
		try {
			//mouse hover to menu
			String myPrescriptionXPath=ExecutionContext.getObjectLocator(DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "ICE_Pharmacy_LoginPage","wLnk_MyPrescriptions",Browser);
			executionContext.setXpathDataPair(myPrescriptionXPath, "");
			OperationsDesktop.mouse_Hover(executionContext);
			
			//check for prescription savings finder option is not there
			String wLnk_PrescriptionsSavingsFinder = ExecutionContext.getObjectLocator("ICE_Pharmacy_HomePage", "wLnk_PrescriptionsSavingsFinder", Browser);
			executionContext.setXpathDataPair(wLnk_PrescriptionsSavingsFinder, "");
			OperationsDesktop.exist(executionContext);
						
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
			reportUtility.setStatusOfOperationForStep(executionContext, false);
		}
		reportUtility.finalStatusSetupToExecuteForEveryStep(executionContext);
	}
	
	@Given("^navigated to Pharmacy module from CVS Home Page$")
	public void navigated_to_Pharmacy_module_from_CVS_Home_Page() {
		reportUtility.performInitialSetupForStep(executionContext);
		try {
			
			//Click on pharmacy link on CVS home page
			String wLnk_Pharmacy = ExecutionContext.getObjectLocator("CVS_HomePage", "wLnk_Pharmacy", Browser);
			executionContext.setXpathDataPair(wLnk_Pharmacy, "");
			OperationsDesktop.click(executionContext);
			
			//wait_For_Object
			String signoutButtonXPath=ExecutionContext.getObjectLocator(DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "ICE_Pharmacy_LoginPage","wLnk_SignOut",Browser);
			executionContext.setXpathDataPair(signoutButtonXPath, "");
			OperationsDesktop.wait_For_Object(executionContext);
						
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
			reportUtility.setStatusOfOperationForStep(executionContext, false);
		}
		reportUtility.finalStatusSetupToExecuteForEveryStep(executionContext);		
	}
	
	@Then("^Verify savings banner and prescription savings finder menu option are displayed or not based on data \"([^\"]*)\"$")
	public void verify_savings_banner_and_prescription_savings_finder_menu_option_are_displayed_or_not_based_on_data(String is_banner_menu_show) {
		reportUtility.performInitialSetupForStep(executionContext);
		try {
			
			//verify banner and menu options are displayed or not based on the value passed
			if (is_banner_menu_show.equalsIgnoreCase("yes")) {
				Thread.sleep(2000);
				verify_savings_banner_is_displayed();
				prescription_savings_finder_option_under_My_Prescriptions_is_displayed();
			}
			else {
				Thread.sleep(2000);
				verify_savings_banner_is_not_displayed();
				prescription_savings_finder_option_under_My_Prescriptions_is_not_displayed();
			}
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
			reportUtility.setStatusOfOperationForStep(executionContext, false);
		}
		reportUtility.finalStatusSetupToExecuteForEveryStep(executionContext);	
		
	}

	@Then("^verify prescription savings finder menu option are displayed or not in my prescription screen based on data \"([^\"]*)\"$")
	public void verify_prescription_savings_finder_menu_option_are_displayed_or_not_in_my_prescription_screen_based_on_data(String is_banner_menu_show) {
		reportUtility.performInitialSetupForStep(executionContext);
		try {
			
			String myPrescriptionXPath=ExecutionContext.getObjectLocator(DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "ICE_Pharmacy_LoginPage","wLnk_MyPrescriptions",Browser);
			executionContext.setXpathDataPair(myPrescriptionXPath, "");
			OperationsDesktop.mouse_Hover(executionContext);
			
			//navigate to my prescriptions
			String prescriptionSavingFinderLinks=ExecutionContext.getObjectLocator(DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "ICE_Pharmacy_HomePage","wLnk_AllPrescriptions",Browser);
			executionContext.setXpathDataPair(prescriptionSavingFinderLinks, "");
			OperationsDesktop.click(executionContext);
			//click on modal ok button
			String wBtn_ModalOkay = ExecutionContext.getObjectLocator("ICE_Pharmacy_HomePage", "wBtn_ModalOkay", Browser);
			executionContext.setXpathDataPair(wBtn_ModalOkay, "");
			OperationsDesktop.click_Object_If_Exist(executionContext);
			//wait for refill all button to load
			String refillAllBtn =ExecutionContext.getObjectLocator(DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "AllPrescriptionsPage","wBtn_RefillAll",Browser);
			executionContext.setXpathDataPair(refillAllBtn, "");
			OperationsDesktop.wait_For_Object(executionContext);
			
			//verify menu options is displayed or not based on the value passed
			if (is_banner_menu_show.equalsIgnoreCase("yes")) {
				prescription_savings_finder_option_under_My_Prescriptions_is_displayed();
			}
			else { 
				prescription_savings_finder_option_under_My_Prescriptions_is_not_displayed();
			}
			
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
			reportUtility.setStatusOfOperationForStep(executionContext, false);
		}
		reportUtility.finalStatusSetupToExecuteForEveryStep(executionContext);	
	}
	
	@Given("^user launched \"([^\"]*)\" and logged in with valid credentials \"([^\"]*)\", \"([^\"]*)\"$")
	public void user_launched_and_logged_in_with_valid_credentials(String cvs_dotcom_url, String username, String password) {
		reportUtility.performInitialSetupForStep(executionContext);
		try {
						
			executionContext.setXpathDataPair("", PropertyFileLoader.getInstance().getProperty(cvs_dotcom_url));
			
			//in this example only URL is expected
			//execute generic method inside the assert statement to terminate in case of failure
			Assert.assertTrue("URL "+PropertyFileLoader.getInstance().getProperty(cvs_dotcom_url)+ " navigated successfully",OperationsDesktop.navigateURL(executionContext));

			//Click on sign in link
			String lnkSignInXpath = ExecutionContext.getObjectLocator("CVS_HomePage", "wLnk_SignIn", Browser);
			executionContext.setXpathDataPair(lnkSignInXpath, "");
			OperationsDesktop.click_Object_If_Exist(executionContext);
			
			//set current xpath and data for input method
			String userNameXPath = ExecutionContext.getObjectLocator(DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "CVS_HomePage", "wEdt_EmailAddress", Browser);
			executionContext.setXpathDataPair(userNameXPath, username);
			
			//both the operations can be invoked sequentially as both require same xPath and data which has been set already
			OperationsDesktop.wait_For_Object(executionContext);
			OperationsDesktop.input(executionContext);
			
			String userPassword = ExecutionContext.getObjectLocator(DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), 
					"CVS_HomePage",	"wEdt_Password", Browser);
			executionContext.setXpathDataPair(userPassword, password);
			OperationsDesktop.input(executionContext);

			String signInButtonXPath = ExecutionContext.getObjectLocator(DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "CVS_HomePage", "wBtn_SignIn",	Browser);
			executionContext.setXpathDataPair(signInButtonXPath, "");
			OperationsDesktop.click(executionContext);

			String signoutButtonXPath = ExecutionContext.getObjectLocator(DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "CVS_HomePage", "wLnk_SignOut", Browser);
			executionContext.setXpathDataPair(signoutButtonXPath, "");
			OperationsDesktop.wait_For_Object(executionContext);
			
		}
		catch (Exception e) {
			ExceptionHandler.handleException(e);
			reportUtility.setStatusOfOperationForStep(executionContext, false);
		}
		reportUtility.finalStatusSetupToExecuteForEveryStep(executionContext);	
	}
	
	@When("^user enter cookie in the URL to enable savings finder tool$")
	public void user_enter_cookie_in_the_URL_to_enable_savings_finder_tool() {
		reportUtility.performInitialSetupForStep(executionContext);
		try {
			//enter cookie in the browser
			executionContext.setXpathDataPair("", PropertyFileLoader.getInstance().getProperty("CVS_SPM_COOKIE"));
			OperationsDesktop.navigateURL(executionContext);
			Thread.sleep(2000);
			
			
			
		}
		catch (Exception e) {
			ExceptionHandler.handleException(e);
			reportUtility.setStatusOfOperationForStep(executionContext, false);
		}
		reportUtility.finalStatusSetupToExecuteForEveryStep(executionContext);


	}

	@Then("^user should be able to see savings banner and prescription savings finder menu option$")
	public void user_should_be_able_to_see_savings_banner_and_prescription_savings_finder_menu_option() {
		reportUtility.performInitialSetupForStep(executionContext);
		try {
			verify_savings_banner_is_displayed();
			prescription_savings_finder_option_under_My_Prescriptions_is_displayed();
		}
		catch (Exception e) {
			ExceptionHandler.handleException(e);
			reportUtility.setStatusOfOperationForStep(executionContext, false);
		}
		reportUtility.finalStatusSetupToExecuteForEveryStep(executionContext);

	}
	
	@Then("^user should be able to see the \"([^\"]*)\" for caregivee on prescription saving screen$")
	public void user_should_be_able_to_see_the_for_caregivee_on_prescription_saving_screen(String message) {
		reportUtility.performInitialSetupForStep(executionContext);
		try {
			//get the message and compare
			String messageXpath = ExecutionContext.getObjectLocator("Prescription_saving", "wMsg_noSavingCaregiveeMsg", Browser);
			executionContext.setXpathDataPair(messageXpath, message);
			OperationsDesktop.validate_Object_Text(executionContext);
			}
		catch (Exception e) {
			ExceptionHandler.handleException(e);
			reportUtility.setStatusOfOperationForStep(executionContext, false);
		}
		reportUtility.finalStatusSetupToExecuteForEveryStep(executionContext);
	}
	
	@Then("^user should not see \"([^\"]*)\" related to caregivee on prescription saving screen$")
	public void user_should_not_see_related_to_caregivee_on_prescription_saving_screen(String message) {
		reportUtility.performInitialSetupForStep(executionContext);
		try {
			String messageXPath = ExecutionContext.getObjectLocator(DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "MyPrescriptionsFinderPage","wTxt_prescriptionSavingsNames",Browser);
			String updatedMessageXPath = messageXPath.replaceAll("dynamic_prescSavingsNames", message.trim());
			executionContext.setXpathDataPair(updatedMessageXPath, "");
			OperationsDesktop.not_Exist(executionContext);
		}
		catch (Exception e) {
			ExceptionHandler.handleException(e);
			reportUtility.setStatusOfOperationForStep(executionContext, false);
		}
		reportUtility.finalStatusSetupToExecuteForEveryStep(executionContext);
	}
	
	@Given("^clicks on the \"([^\"]*)\" which has saving opportutnity$")
	public void clicks_on_the_which_has_saving_opportutnity(String drugName) {
		reportUtility.performInitialSetupForStep(executionContext);
		try {
			//click on the drug
			String drugNamexPath = ExecutionContext.getObjectLocator("MyPrescriptionsFinderPage", "wTxt_prescriptionSavingsNames", Browser);
			drugNamexPath = drugNamexPath.replace("dynamic_prescSavingsNames", drugName.trim());
			executionContext.setXpathDataPair(drugNamexPath, "");
			OperationsDesktop.click(executionContext);
			
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
			reportUtility.setStatusOfOperationForStep(executionContext, false);
		}
		reportUtility.finalStatusSetupToExecuteForEveryStep(executionContext);
	    
	}
}
