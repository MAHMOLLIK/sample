package test.java.stepdefs.com.cvshealth.digital.cat.savingtools;

import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import test.java.stepdefs.com.cvshealth.digital.library.AbstractStepDefinition;
import test.java.stepdefs.com.cvshealth.digital.library.DBCacheSingleton;
import test.java.stepdefs.com.cvshealth.digital.library.ExceptionHandler;
import test.java.stepdefs.com.cvshealth.digital.library.ExecutionContext;
import test.java.stepdefs.com.cvshealth.digital.library.OperationsDesktop;

public class EmailSignup extends AbstractStepDefinition {

	@Then("^user can see email sign up button and related copy \"([^\"]*)\", \"([^\"]*)\"$")
	public void user_can_see_email_sign_up_button_and_related_copy(String promoHeading, String promoCopy)
			 {
		// Write code here that turns the phrase above into concrete actions
		reportUtility.performInitialSetupForStep(executionContext);
		try {
			// check for promo heading
			String promoHeadingXpath = ExecutionContext.getObjectLocator(
					DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "MyPrescriptionsFinderPage",
					"wTxt_prescriptionSavingsNames", Browser);
			String updatedpromoHeadingXpath = promoHeadingXpath.replaceAll("dynamic_prescSavingsNames",
					promoHeading.trim());
			executionContext.setXpathDataPair(updatedpromoHeadingXpath, "");
			OperationsDesktop.exist(executionContext);

			// check for promo copy
			String promoCopyXpath = ExecutionContext.getObjectLocator(
					DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "MyPrescriptionsFinderPage",
					"wTxt_prescriptionSavingsNames", Browser);
			String updatedpromoCopyXpath = promoCopyXpath.replaceAll("dynamic_prescSavingsNames", promoCopy.trim());
			executionContext.setXpathDataPair(updatedpromoCopyXpath, "");
			OperationsDesktop.exist(executionContext);

			// check for sign up button
			String wBtn_TellMeMore = ExecutionContext.getObjectLocator("SavingsOptions_Email", "wBtn_TellMeMore",
					Browser);
			executionContext.setXpathDataPair(wBtn_TellMeMore, "");
			OperationsDesktop.exist(executionContext);
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
			reportUtility.setStatusOfOperationForStep(executionContext, false);

		}
		reportUtility.finalStatusSetupToExecuteForEveryStep(executionContext);

	}

	@When("^user click on tell me more button for email sign up$")
	public void user_click_on_tell_me_more_button_for_email_sign_up() {
		// Write code here that turns the phrase above into concrete actions
		reportUtility.performInitialSetupForStep(executionContext);
		try {
			// click on sign up button
			String wBtn_TellMeMore = ExecutionContext.getObjectLocator("SavingsOptions_Email", "wBtn_TellMeMore",
					Browser);
			executionContext.setXpathDataPair(wBtn_TellMeMore, "");
			OperationsDesktop.click(executionContext);

			// wait for object
			String wBtn_RequestNotifications = ExecutionContext.getObjectLocator("SavingsOptions_Email",
					"wBtn_RequestNotifications", Browser);
			executionContext.setXpathDataPair(wBtn_RequestNotifications, "");
			OperationsDesktop.wait_For_Object(executionContext);

		} catch (Exception e) {
			ExceptionHandler.handleException(e);
			reportUtility.setStatusOfOperationForStep(executionContext, false);

		}
		reportUtility.finalStatusSetupToExecuteForEveryStep(executionContext);
		// wait for pop up

	}

	@Then("^email sign up modal should appear with email field, request notificaion button, no thanks text along with copy text \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\"$")
	public void email_sign_up_modal_should_appear_with_email_field_request_notificaion_button_no_thanks_text_along_with_copy_text(
			String modalHeading, String modalCopy1, String modalCopy2) {
		// Write code here that turns the phrase above into concrete actions
		reportUtility.performInitialSetupForStep(executionContext);
		try {
			// check for modal heading
			String modalHeadingXpath = ExecutionContext.getObjectLocator(
					DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "MyPrescriptionsFinderPage",
					"wTxt_prescriptionSavingsNames", Browser);
			String updatedmodalHeadingXpath = modalHeadingXpath.replaceAll("dynamic_prescSavingsNames",
					modalHeading.trim());
			executionContext.setXpathDataPair(updatedmodalHeadingXpath, "");
			OperationsDesktop.exist(executionContext);

			// check for modal copy
			String modalCopy1Xpath = ExecutionContext.getObjectLocator(
					DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "MyPrescriptionsFinderPage",
					"wTxt_prescriptionSavingsNames", Browser);
			String updatedmodalCopy1Xpath = modalCopy1Xpath.replaceAll("dynamic_prescSavingsNames", modalCopy1.trim());
			executionContext.setXpathDataPair(updatedmodalCopy1Xpath, "");
			OperationsDesktop.exist(executionContext);

			// check for modal copy
			String modalCopy2Xpath = ExecutionContext.getObjectLocator(
					DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "MyPrescriptionsFinderPage",
					"wTxt_prescriptionSavingsNames", Browser);
			String updatedmodalCopy2Xpath = modalCopy2Xpath.replaceAll("dynamic_prescSavingsNames", modalCopy2.trim());
			executionContext.setXpathDataPair(updatedmodalCopy2Xpath, "");
			OperationsDesktop.exist(executionContext);

			// check for request button
			String wBtn_RequestNotifications = ExecutionContext.getObjectLocator("SavingsOptions_Email",
					"wBtn_RequestNotifications", Browser);
			executionContext.setXpathDataPair(wBtn_RequestNotifications, "");
			OperationsDesktop.exist(executionContext);

			// check for no thanks button
			String wBtn_EmailNothanks = ExecutionContext.getObjectLocator("SavingsOptions_Email", "wBtn_EmailNothanks",
					Browser);
			executionContext.setXpathDataPair(wBtn_EmailNothanks, "");
			OperationsDesktop.exist(executionContext);

		} catch (Exception e) {
			ExceptionHandler.handleException(e);
			reportUtility.setStatusOfOperationForStep(executionContext, false);

		}
		reportUtility.finalStatusSetupToExecuteForEveryStep(executionContext);

	}

	@When("^user click on tell me more button for email sign up and then click on no thanks$")
	public void user_click_on_tell_me_more_button_for_email_sign_up_and_then_click_on_no_thanks() {
		// Write code here that turns the phrase above into concrete actions
		user_click_on_tell_me_more_button_for_email_sign_up();
		reportUtility.performInitialSetupForStep(executionContext);
		try {
			// click on no thanks
			String wBtn_EmailNothanks = ExecutionContext.getObjectLocator("SavingsOptions_Email", "wBtn_EmailNothanks",
					Browser);
			executionContext.setXpathDataPair(wBtn_EmailNothanks, "");
			OperationsDesktop.click(executionContext);

		} catch (Exception e) {
			ExceptionHandler.handleException(e);
			reportUtility.setStatusOfOperationForStep(executionContext, false);

		}
		reportUtility.finalStatusSetupToExecuteForEveryStep(executionContext);
	}

	@Then("^modal should disappear and user should be navigated to savings hub screen$")
	public void modal_should_disappear_and_user_should_be_navigated_to_savings_hub_screen() {
		// Write code here that turns the phrase above into concrete actions
		reportUtility.performInitialSetupForStep(executionContext);
		try {
			// check for sign up button
			String wBtn_TellMeMore = ExecutionContext.getObjectLocator("SavingsOptions_Email", "wBtn_TellMeMore",
					Browser);
			executionContext.setXpathDataPair(wBtn_TellMeMore, "");
			OperationsDesktop.exist(executionContext);

		} catch (Exception e) {
			ExceptionHandler.handleException(e);
			reportUtility.setStatusOfOperationForStep(executionContext, false);

		}
		reportUtility.finalStatusSetupToExecuteForEveryStep(executionContext);
	}

	@When("^user click on tell me more button for email sign up and then add email in the modal displayed$")
	public void user_click_on_tell_me_more_button_for_email_sign_up_and_then_add_email_in_the_modal_displayed()
			throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		user_click_on_tell_me_more_button_for_email_sign_up();
		reportUtility.performInitialSetupForStep(executionContext);
		try {
			// click on no thanks
			String wBtn_RequestNotifications = ExecutionContext.getObjectLocator("SavingsOptions_Email",
					"wBtn_RequestNotifications", Browser);
			executionContext.setXpathDataPair(wBtn_RequestNotifications, "");
			OperationsDesktop.click(executionContext);

			// wait for congratulations
			// check for promo heading
			String signedUpXpath = ExecutionContext.getObjectLocator(
					DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "MyPrescriptionsFinderPage",
					"wTxt_prescriptionSavingsNames", Browser);
			String updatedsignedUpXpath = signedUpXpath.replaceAll("dynamic_prescSavingsNames",
					"signed up for savings");
			executionContext.setXpathDataPair(updatedsignedUpXpath, "");
			OperationsDesktop.wait_For_Object(executionContext);

		} catch (Exception e) {
			ExceptionHandler.handleException(e);
			reportUtility.setStatusOfOperationForStep(executionContext, false);

		}
		reportUtility.finalStatusSetupToExecuteForEveryStep(executionContext);
	}

	@Then("^email should be added successfully with confirmaiton message \"([^\"]*)\", \"([^\"]*)\"$")
	public void email_should_be_added_successfully_with_confirmaiton_message(String successBannerHeading,
			String successBannerText) {
		// Write code here that turns the phrase above into concrete actions
		reportUtility.performInitialSetupForStep(executionContext);
		try {
			// check for promo heading
			String successBannerHeadingXpath = ExecutionContext.getObjectLocator(
					DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "MyPrescriptionsFinderPage",
					"wTxt_prescriptionSavingsNames", Browser);
			String updatedsuccessBannerHeadingXpath = successBannerHeadingXpath.replaceAll("dynamic_prescSavingsNames",
					successBannerHeading.trim());
			executionContext.setXpathDataPair(updatedsuccessBannerHeadingXpath, "");
			OperationsDesktop.exist(executionContext);

			// check for promo copy
			String successBannerTextXpath = ExecutionContext.getObjectLocator(
					DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "MyPrescriptionsFinderPage",
					"wTxt_prescriptionSavingsNames", Browser);
			String updatedsuccessBannerTextXpath = successBannerTextXpath.replaceAll("dynamic_prescSavingsNames", successBannerText.trim());
			executionContext.setXpathDataPair(updatedsuccessBannerTextXpath, "");
			OperationsDesktop.exist(executionContext);

			// check for sign up button
			String wBtn_TellMeMore = ExecutionContext.getObjectLocator("SavingsOptions_Email", "wBtn_TellMeMore",
					Browser);
			executionContext.setXpathDataPair(wBtn_TellMeMore, "");
			OperationsDesktop.exist(executionContext);
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
			reportUtility.setStatusOfOperationForStep(executionContext, false);

		}
		reportUtility.finalStatusSetupToExecuteForEveryStep(executionContext);

	}

}
