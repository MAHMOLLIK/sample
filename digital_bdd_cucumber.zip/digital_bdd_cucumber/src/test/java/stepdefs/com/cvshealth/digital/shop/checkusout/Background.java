package test.java.stepdefs.com.cvshealth.digital.shop.checkusout;

import org.junit.Assert;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import test.java.stepdefs.com.cvshealth.digital.library.AbstractStepDefinition;
import test.java.stepdefs.com.cvshealth.digital.library.DBCacheSingleton;
import test.java.stepdefs.com.cvshealth.digital.library.ExceptionHandler;
import test.java.stepdefs.com.cvshealth.digital.library.ExecutionContext;
import test.java.stepdefs.com.cvshealth.digital.library.OperationsDesktop;
import test.java.stepdefs.com.cvshealth.digital.library.PropertyFileLoader;

public class Background extends AbstractStepDefinition {

	@Given("^user should navigate login \"([^\"]*)\" url$")
	public void user_should_navigate_login_url(String CVS_QA4) {
		reportUtility.performInitialSetupForStep(executionContext);
		try {

			executionContext.setXpathDataPair("", PropertyFileLoader.getInstance().getProperty(CVS_QA4));
			Assert.assertTrue(
					"URL " + PropertyFileLoader.getInstance().getProperty(CVS_QA4) + " navigated successfully",
					OperationsDesktop.navigateCustomURL(executionContext));

		} catch (Exception e) {
			ExceptionHandler.handleException(e);
			reportUtility.setStatusOfOperationForStep(executionContext, false);
		}
		reportUtility.finalStatusSetupToExecuteForEveryStep(executionContext);
	   
	}

	@When("^user enters valid email that associated with the particuler account$")
	public void user_enters_valid_email_that_associated_with_the_particuler_account() {
		reportUtility.performInitialSetupForStep(executionContext);
		try {
				
			String Input_Email = ExecutionContext.getObjectLocator("Singin_Page", "Input_Email", Browser);
			executionContext.setXpathDataPair(Input_Email, "sukantasaha91@gmail.com");
			//OperationsDesktop.wait_For_Object(executionContext);
			OperationsDesktop.input(executionContext);
			
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
			reportUtility.setStatusOfOperationForStep(executionContext, false);
		}
		reportUtility.finalStatusSetupToExecuteForEveryStep(executionContext);
	   
	}

	@When("^user enters a valid password that associated with the particuler account and press login button$")
	public void user_enters_a_valid_password_that_associated_with_the_particuler_account_and_press_login_button() {
		reportUtility.performInitialSetupForStep(executionContext);
		try {
			
			String Input_Password = ExecutionContext.getObjectLocator("Singin_Page", "Input_Password", Browser);
			executionContext.setXpathDataPair(Input_Password, "abc12345");
			OperationsDesktop.wait_For_Object(executionContext);
			OperationsDesktop.input(executionContext);
			
			String wBtn_Signin = ExecutionContext.getObjectLocator("Singin_Page", "wBtn_Signin", Browser);
			executionContext.setXpathDataPair(wBtn_Signin, "");
			OperationsDesktop.wait_For_Object(executionContext);
			OperationsDesktop.click(executionContext);
	
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
			reportUtility.setStatusOfOperationForStep(executionContext, false);
		}
		reportUtility.finalStatusSetupToExecuteForEveryStep(executionContext);
	}
}
