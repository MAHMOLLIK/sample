package test.java.stepdefs.com.cvshealth.digital.library;


/** 
* <p style="font-family:Arial;">
* <b>DESCRIPTION: This Class logs exception trace in log files
* <br><br>
* Author: - ACOE Team
* <br><br>
* Date Created: 05/03/2019
* <br><br>Revision History: 
* </b></P> 
* 
*/
public class ExceptionHandler {
	
	/*
	 * =========================================================================================== 
	 * Function Name: handleException
	 * CREATED BY: ACOE Team
	 * CREATED DATE: 05/03/2019
	 * DESCRIPTION: This method is used to log exception trace in log files
	 * Parameter: Object of Exception class
	 * RETURNS: Nothing
	 * COMMENTS: 
	 * Modification Log: 
	 * Revision: 1.0
	 * Date: 05/03/2019
	 * Comment: Implemented method with initial requirement
	 *  
	 * ===========================================================================================
	 */
	/** 
	* <p style="font-family:Arial;">
	* <b>DESCRIPTION: This method is used to log exception trace in log files
	* <br><br>
	* Author: - ACOE Team
	* <br><br>
	* Date Created: 05/03/2019
	* <br><br>Revision History: 
	* <br>1.0: Define method and added initial code
	* <br>
	* @param Object of Exception class
	* @return No Return Value
	* @throws Exception  If any error occurs, reports the exception message and log the full exception trace in log file
	* </b></P> 
	* 
	*/
	public static void handleException(Exception e) {
		try {
			e.printStackTrace();
			StackTraceElement[] stackTrace=e.getStackTrace();
			try{Log.writeToLogFile(e.toString());}catch(Exception e1){}
			String data="";
			for(StackTraceElement st:stackTrace){
				if(data==null||data.equalsIgnoreCase("")){
					data="         at "+st;
				}else{
					data=data+"\n"+"         at "+st;
				}		
			}
			Log.writeToLogFile(data);
		}catch(Exception e1) {

		}
	}
}