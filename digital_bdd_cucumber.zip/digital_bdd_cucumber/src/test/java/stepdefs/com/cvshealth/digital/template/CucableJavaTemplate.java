package test.java.stepdefs.com.cvshealth.digital.template;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;
import org.junit.runner.RunWith;

@RunWith(Cucumber.class)
@CucumberOptions(
        glue = "test.java.stepdefs",
        features = {"target/parallel/features/[CUCABLE:FEATURE].feature"},
        plugin = {"json:target/cucumber-parallel/[CUCABLE:RUNNER].json"}
)
public class CucableJavaTemplate {
    // [CUCABLE:CUSTOM:comment]
}