package test.java.stepdefs.com.cvshealth.digital.bab.Shop;


import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import sun.security.util.PendingException;
import test.java.stepdefs.com.cvshealth.digital.library.AbstractStepDefinition;
import test.java.stepdefs.com.cvshealth.digital.library.ExceptionHandler;
import test.java.stepdefs.com.cvshealth.digital.library.ExecutionContext;
import test.java.stepdefs.com.cvshealth.digital.library.OperationsDesktop;
import test.java.stepdefs.com.cvshealth.digital.library.PropertyFileLoader;


public class BB_Shop_PLP_PDP extends AbstractStepDefinition {
	
	@Given("^user opened cvs dotcom url$")
	public void user_opened_cvs_dotcom_url() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		reportUtility.performInitialSetupForStep(executionContext);
		try {
			System.out.println(System.getProperties());
			
			//executionContext.setXpathDataPair("", PropertyFileLoader.getInstance().getProperty(cvs_dotcom_url));
			executionContext.setXpathDataPair("", PropertyFileLoader.getInstance().getURL());
			Assert.assertTrue(OperationsDesktop.navigateURL(executionContext));
			//in this example only URL is expected
			//execute generic method inside the assert statement to terminate in case of failure
			//Assert.assertTrue("URL "+PropertyFileLoader.getInstance().getURL()+ " navigated successfully", OperationsDesktop.navigateURL(executionContext));
			
			String lnkSignInXpath = ExecutionContext.getObjectLocator("CVS_HomePage", "wLnk_SignIn", Browser);
			executionContext.setXpathDataPair(lnkSignInXpath, "");
			OperationsDesktop.wait_For_Object(executionContext);
		}
		catch (Exception e) {
			ExceptionHandler.handleException(e);
			reportUtility.setStatusOfOperationForStep(executionContext, false);
		}
		reportUtility.finalStatusSetupToExecuteForEveryStep(executionContext);	
	}

	@Given("^search for a product \"([^\"]*)\" from home page$")
	public void search_for_a_product_from_home_page(String searchkey) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		reportUtility.performInitialSetupForStep(executionContext);
try {
	
			System.out.println(System.getProperties());
			
			//Get required data from data base
			searchkey=executionContext.getExecutionData("searchkey", searchkey);
			
			//Input search key
			String ObjSearchXpath = ExecutionContext.getObjectLocator("CVS_HomePage", "wEdt_SearchBox", Browser);
			executionContext.setXpathDataPair(ObjSearchXpath, searchkey);
			OperationsDesktop.input(executionContext);
			
		}
		catch (Exception e) {
			ExceptionHandler.handleException(e);
			reportUtility.setStatusOfOperationForStep(executionContext, false);
		}
		reportUtility.finalStatusSetupToExecuteForEveryStep(executionContext);
	  
	}

	@Given("^click on search button$")
	public void click_on_search_button() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		reportUtility.performInitialSetupForStep(executionContext);
		try {
			
					System.out.println(System.getProperties());
		
					//Click on search button
					String BtnSearchbox = ExecutionContext.getObjectLocator("CVS_HomePage", "wBtn_Search", Browser);
					executionContext.setXpathDataPair(BtnSearchbox, "");
					OperationsDesktop.click(executionContext);
					OperationsDesktop.wait_Page_Load(executionContext);
					
				}
				catch (Exception e) {
					ExceptionHandler.handleException(e);
					reportUtility.setStatusOfOperationForStep(executionContext, false);
				}
				reportUtility.finalStatusSetupToExecuteForEveryStep(executionContext);
	}

	@Given("^user able to see search results on PLP page$")
	public void user_able_to_see_search_results_on_PLP_page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		reportUtility.performInitialSetupForStep(executionContext);
		try {
			
					System.out.println(System.getProperties());
		
					//Wait for Element get visible
					//BB
					String ObjSearchText = ExecutionContext.getObjectLocator("CVS_PLP", "wTxt_Search_Breadcrumb", Browser);
					
				// Non-BB
					//String ObjSearchText = ExecutionContext.getObjectLocator("CVS_PLP_NonBB", "wTxt_Search_Breadcrumb", Browser);
					executionContext.setXpathDataPair(ObjSearchText, "");
					OperationsDesktop.wait_Page_Load(executionContext);
					OperationsDesktop.wait_For_Object(executionContext);
					OperationsDesktop.wait_Page_Load(executionContext);
					
				}
				catch (Exception e) {
					ExceptionHandler.handleException(e);
					reportUtility.setStatusOfOperationForStep(executionContext, false);
				}
				reportUtility.finalStatusSetupToExecuteForEveryStep(executionContext);
	}

	@Then("^click on the product Img$")
	public void click_on_the_product_Img() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		reportUtility.performInitialSetupForStep(executionContext);
		try {
			
					System.out.println(System.getProperties());
		
					//Wait for Element get visible
					String ProductNamePLP = ExecutionContext.getObjectLocator("CVS_PLP", "wLnk_ProductName_PLP", Browser);
					//String ProductNamePLP = ExecutionContext.getObjectLocator("CVS_PLP_NonBB", "wLnk_ProductName_PLP", Browser);
					executionContext.setXpathDataPair(ProductNamePLP, "");
					OperationsDesktop.wait_Page_Load(executionContext);
					OperationsDesktop.wait_For_Object(executionContext);
					OperationsDesktop.findElements(executionContext.getDriver(), ProductNamePLP);
					OperationsDesktop.click(executionContext);
					OperationsDesktop.wait_Page_Load(executionContext);
									
				}
				catch (Exception e) {
					ExceptionHandler.handleException(e);
					reportUtility.setStatusOfOperationForStep(executionContext, false);
				}
				reportUtility.finalStatusSetupToExecuteForEveryStep(executionContext);
	}

	@Then("^navigate to PDP page$")
	public void navigate_to_PDP_page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		reportUtility.performInitialSetupForStep(executionContext);
		try {
			
					System.out.println(System.getProperties());
		
					//Wait for Element get visible
					String ProductNamePDP = ExecutionContext.getObjectLocator("CVS_PDP", "wTxt_ProductName_PDP", Browser);
					//String ProductNamePDP = ExecutionContext.getObjectLocator("CVS_PDP_NonBB", "wTxt_ProductName_PDP", Browser);
					executionContext.setXpathDataPair(ProductNamePDP, "");
					OperationsDesktop.wait_Page_Load(executionContext);
					OperationsDesktop.wait_For_Object(executionContext);
					OperationsDesktop.exist(executionContext);
									
				}
				catch (Exception e) {
					ExceptionHandler.handleException(e);
					reportUtility.setStatusOfOperationForStep(executionContext, false);
				}
				reportUtility.finalStatusSetupToExecuteForEveryStep(executionContext);
	}

	@Then("^click on ATB button$")
	public void click_on_ATB_button() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		reportUtility.performInitialSetupForStep(executionContext);
		try {
			
					System.out.println(System.getProperties());
		
					//Wait for Element get visible
					//String ATBPDP = ExecutionContext.getObjectLocator("CVS_PDP", "wBtn_ATB_PDP", Browser);
					String ATBPDP = ExecutionContext.getObjectLocator("CVS_PDP_NonBB", "wBtn_ATB_PDP", Browser);
					executionContext.setXpathDataPair(ATBPDP, "");
					OperationsDesktop.click(executionContext);
					OperationsDesktop.wait_Page_Load(executionContext);
									
				}
				catch (Exception e) {
					ExceptionHandler.handleException(e);
					reportUtility.setStatusOfOperationForStep(executionContext, false);
				}
				reportUtility.finalStatusSetupToExecuteForEveryStep(executionContext);
	}

	@When("^ATB model loaded click on Checkout button$")
	public void atb_model_loaded_click_on_Checkout_button() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		reportUtility.performInitialSetupForStep(executionContext);
		try {
			
					System.out.println(System.getProperties());
		
					//Wait for Element get visible
					//String CheckoutATB = ExecutionContext.getObjectLocator("CVS_ATB", "wBtn_Checkout_ATB", Browser);
					String CheckoutATB = ExecutionContext.getObjectLocator("CVS_ATB_NonBB", "wBtn_Checkout_ATB", Browser);
					executionContext.setXpathDataPair(CheckoutATB, "");
					OperationsDesktop.wait_For_Object(executionContext);
					OperationsDesktop.click(executionContext);
					OperationsDesktop.wait_Page_Load(executionContext);
									
				}
				catch (Exception e) {
					ExceptionHandler.handleException(e);
					reportUtility.setStatusOfOperationForStep(executionContext, false);
				}
				reportUtility.finalStatusSetupToExecuteForEveryStep(executionContext);
	}

	@Then("^user naviagate to cart page$")
	public void user_naviagate_to_cart_page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		reportUtility.performInitialSetupForStep(executionContext);
		try {
			
					System.out.println(System.getProperties());
		
					//Wait for Element get visible
					String CheckoutATB = ExecutionContext.getObjectLocator("CartPage_NonBB", "wBtn_CheckoutNow", Browser);
					executionContext.setXpathDataPair(CheckoutATB, "");
					OperationsDesktop.wait_For_Object(executionContext);
					OperationsDesktop.click(executionContext);
					OperationsDesktop.wait_Page_Load(executionContext);
									
				}
				catch (Exception e) {
					ExceptionHandler.handleException(e);
					reportUtility.setStatusOfOperationForStep(executionContext, false);
				}
				reportUtility.finalStatusSetupToExecuteForEveryStep(executionContext);
	}


}
