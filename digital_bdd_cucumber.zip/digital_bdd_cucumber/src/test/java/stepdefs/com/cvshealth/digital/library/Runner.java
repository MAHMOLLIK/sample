package test.java.stepdefs.com.cvshealth.digital.library;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;


/*@RunWith(Cucumber.class)
@CucumberOptions(
        strict = true,
        features = {"src\\test\\java\\features\\CVS_LoginOld.feature"},
        glue = {"test.java.stepdefinitions.com.cvshealth.digital.cat.savingtools"}
       // tags = {"@test1"}
        )*/
/*@RunWith(Cucumber.class)
@CucumberOptions(features = "@target/rerun.txt", plugin = {"rerun:target/rerun.txt"})
*/


/*@RunWith(Cucumber.class)
@CucumberOptions(features = "src\\test\\java\\features\\")*/

/*@RunWith(Cucumber.class)
@CucumberOptions(
        strict = true,
        features = {"src/test/java/features/com/cvshealth/digital/cat/savingtools/Savingtools.feature"},
        plugin = {"json:C:/Automation_Enterprise/Selenium/digital_bdd_official/target/cucumber-parallel/1.json"},
        monochrome = false,
        tags = {"@smoketestFirst"},
        glue = {"test.java.stepdefs"})*/
/*@RunWith(Cucumber.class)
@CucumberOptions(
        //strict = true,
        features = {"src/test/java/features/com/cvshealth/digital/cat/clinicaltools/RoutineMedications.feature"},
        plugin = {"pretty", "html:target/cucumber"},
        monochrome = false,
        tags = {"@ValidatePatientBasicInfo"},
        glue = {"test.java.stepdefs"})*/

/*@RunWith(Cucumber.class)
@CucumberOptions(
		
		features = {"src\\test\\java\\features\\com\\cvshealth\\digital\\cat\\clinicaltools\\RoutineMedications.feature"}		
		,glue={"test.java.stepdefs"}		
		,plugin = {"pretty","json:target/cucumber-reports/CucumberTestReport.json","com.cucumber.listener.ExtentCucumberFormatter:target/cucumber-reports/Results.html"}		
		,monochrome= true		
		,tags={"@ValidatePatientBasicInfo"}
		)*/

public class Runner{	
}

