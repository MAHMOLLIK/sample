package test.java.stepdefs.com.cvshealth.digital.cat.clinicaltools;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.List;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebElement;

import cucumber.api.DataTable;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import test.java.stepdefs.com.cvshealth.digital.library.AbstractStepDefinition;
import test.java.stepdefs.com.cvshealth.digital.library.DBCacheSingleton;
import test.java.stepdefs.com.cvshealth.digital.library.ExceptionHandler;
import test.java.stepdefs.com.cvshealth.digital.library.ExecutionContext;
import test.java.stepdefs.com.cvshealth.digital.library.Log;
import test.java.stepdefs.com.cvshealth.digital.library.OperationsDesktop;
import test.java.stepdefs.com.cvshealth.digital.library.PropertyFileLoader;
import test.java.stepdefs.com.cvshealth.digital.library.ReportUtility;

public class OtherMedications extends AbstractStepDefinition {
	
	@Then("^User is able to see all basic components of Other medications table$")
	public void user_is_able_to_see_all_basic_componenets_of_other_medications_table() {

		reportUtility.performInitialSetupForStep(executionContext);

		try {

			// Retrieve all the xpath needed for validation
			String directionForUsePath = ExecutionContext.getObjectLocator(
					DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "PrescriptionSchedule_Page",
					"wElt_DirectionForUse_Other", Browser);
			String refillInfoPath = ExecutionContext.getObjectLocator(
					DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "PrescriptionSchedule_Page",
					"wElt_RefillInfo_Other", Browser);
			String sixMonthPickUpHistoryPath = ExecutionContext.getObjectLocator(
					DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "PrescriptionSchedule_Page",
					"wElt_6MonthPickUpHistory", Browser);
			String morningSlotPath = ExecutionContext.getObjectLocator(
					DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "PrescriptionSchedule_Page",
					"wElt_MorningSlot_Other", Browser);
			String middaySlotPath = ExecutionContext.getObjectLocator(
					DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "PrescriptionSchedule_Page",
					"wElt_MiddaySlot_Other", Browser);
			String eveningSlotPath = ExecutionContext.getObjectLocator(
					DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "PrescriptionSchedule_Page",
					"wElt_EveningSlot_Other", Browser);
			String bedtimeSlotPath = ExecutionContext.getObjectLocator(
					DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "PrescriptionSchedule_Page",
					"wElt_BedtimeSlot_Other", Browser);

			// Verify Medications or Directions for use column
			executionContext.setXpathDataPair(directionForUsePath, "");
			OperationsDesktop.scroll_To_Object(executionContext);
			OperationsDesktop.exist(executionContext);

			// Verify Refill Information column
			executionContext.setXpathDataPair(refillInfoPath, "");
			OperationsDesktop.exist(executionContext);

			// Verify 6 Month Pick Up Information column
			executionContext.setXpathDataPair(sixMonthPickUpHistoryPath, "");
			OperationsDesktop.exist(executionContext);

			// Verify Morning Slot column
			executionContext.setXpathDataPair(morningSlotPath, "");
			OperationsDesktop.exist(executionContext);

			// Verify Middday Slot column
			executionContext.setXpathDataPair(middaySlotPath, "");
			OperationsDesktop.exist(executionContext);

			// Verify Evening Slot column
			executionContext.setXpathDataPair(eveningSlotPath, "");
			OperationsDesktop.exist(executionContext);

			// Verify Bedtime Slot column
			executionContext.setXpathDataPair(bedtimeSlotPath, "");
			OperationsDesktop.exist(executionContext);

		} catch (Exception e) {

			ExceptionHandler.handleException(e);
			reportUtility.setStatusOfOperationForStep(executionContext, false);

		}

		reportUtility.finalStatusSetupToExecuteForEveryStep(executionContext);
	}

}
