package test.java.stepdefs.com.cvshealth.digital.library;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class Log {
	
	//This variable is used to store current log file path
	public static String LogFilePath=getLogDirectoryPath();
	
	//Store current logs
	public static List<String> logMessageList=new ArrayList<String>();
	
	//Store current log counter;
	private static int counter=0;
	

	/*
	 * =========================================================================================== 
	 * Function Name: writeToLogFile
	 * CREATED BY: ACOE Team
	 * CREATED DATE: 05/03/2019
	 * DESCRIPTION: This method is used to add logs in list and add logs in log file if current log size is greater than 100
	 * Parameter: log message
	 * RETURNS: Nothing
	 * COMMENTS: 
	 * Modification Log: 
	 * Revision: 1.0
	 * Date: 05/03/2019
	 * Comment: Implemented method with initial requirement
	 *  
	 * ===========================================================================================
	 */
	/** 
	* <p style="font-family:Arial;">
	* <b>DESCRIPTION: This method is used to add logs in list and add logs in log file if current log size is greater than 100
	* <br><br>
	* Author: - ACOE Team
	* <br><br>
	* Date Created: 05/03/2019
	* <br><br>Revision History: 
	* <br>1.0: Define method and added initial code
	* <br>
	* @param  String argument - Log message
	* @return No Return Value
	* @throws Exception  If any error occurs, reports the exception message and log the full exception trace in log file
	* </b></P> 
	* 
	*/
	public static void writeToLogFile(String object)
	{
		try{	
			logMessageList.add(object);
			counter++;
			if(counter>100) {				
				writeToLogFile(logMessageList);
				logMessageList=new ArrayList<String>();
				counter=0;
			}
		} 
		catch(Exception e)
		{
			e.printStackTrace();
		} 
	} 

	/*
	 * =========================================================================================== 
	 * Function Name: writeToLogFile
	 * CREATED BY: ACOE Team
	 * CREATED DATE: 05/03/2019
	 * DESCRIPTION: This method is used to add logs from list in to log file
	 * Parameter: List of String
	 * RETURNS: Nothing
	 * COMMENTS: 
	 * Modification Log: 
	 * Revision: 1.0
	 * Date: 05/03/2019
	 * Comment: Implemented method with initial requirement
	 *  
	 * ===========================================================================================
	 */
	/** 
	* <p style="font-family:Arial;">
	* <b>DESCRIPTION: This method is used to add logs from list in to log file
	* <br><br>
	* Author: - ACOE Team
	* <br><br>
	* Date Created: 05/03/2019
	* <br><br>Revision History: 
	* <br>1.0: Define method and added initial code
	* <br>
	* @param  List of String - log messages to be added in log file
	* @return No Return Value
	* @throws Exception  If any error occurs, reports the exception message and log the full exception trace in log file
	* </b></P> 
	* 
	*/
	public static void writeToLogFile(List<String> objectList) 
	{
		try{			
			File file = new File(LogFilePath);
			if (!file.exists()) {
				file.createNewFile();
			} 
			FileWriter fw = new FileWriter(file.getAbsoluteFile(),true);
			BufferedWriter writer = new BufferedWriter(fw);
			for(String msg:objectList){				
				writer.write(msg+"");
				writer.newLine();
				System.out.println(msg);
			}
			writer.close();
			fw.close();
		} 
		catch(Exception e)
		{
			e.printStackTrace();
		} 
	} 	
	
	/*
	 * =========================================================================================== 
	 * Function Name: getLogDirectoryPath
	 * CREATED BY: ACOE Team
	 * CREATED DATE: 05/03/2019
	 * DESCRIPTION: This method is used to get current log directory path
	 * Parameter: None
	 * RETURNS: Current log directory path as String argument
	 * COMMENTS: 
	 * Modification Log: 
	 * Revision: 1.0
	 * Date: 05/03/2019
	 * Comment: Implemented method with initial requirement
	 *  
	 * ===========================================================================================
	 */
	/** 
	* <p style="font-family:Arial;">
	* <b>DESCRIPTION: This method is used to get current log directory path
	* <br><br>
	* Author: - ACOE Team
	* <br><br>
	* Date Created: 05/03/2019
	* <br><br>Revision History: 
	* <br>1.0: Define method and added initial code
	* <br>
	* @param  None
	* @return String - Current log directory path as String argument
	* @throws Exception  If any error occurs, reports the exception message and log the full exception trace in log file
	* </b></P> 
	* 
	*/
	public static String getLogDirectoryPath() {
		String logDirectoryPath="";
		try {
			if(!(LogFilePath==null || LogFilePath.equalsIgnoreCase(""))) {
				return LogFilePath;
			}
			File file=new File("TestResults");
			String logFilePath1=file.getAbsolutePath()+"/Log";
			file=new File(logFilePath1);
			if(!file.exists()) {
				file.mkdirs();
			}
			Date date=new Date();
			logDirectoryPath=logFilePath1+"/Log_"+date.getTime()+".log";			
		}catch(Exception e) {
			e.printStackTrace();
		}
		return logDirectoryPath;
	}

} 