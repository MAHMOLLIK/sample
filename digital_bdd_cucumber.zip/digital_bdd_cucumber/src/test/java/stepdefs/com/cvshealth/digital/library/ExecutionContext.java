package test.java.stepdefs.com.cvshealth.digital.library;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.openqa.selenium.WebDriver;

import cucumber.api.DataTable;
import cucumber.api.Scenario;

public class ExecutionContext {


	private static HashMap<Long, ExecutionContext> store_ExecutionContextInstanceForThread = new HashMap<>();
	private static HashMap<String, Integer> iteration_Number_For_Scenario_Map = new HashMap<String, Integer>();
	private static HashMap<String, String> scenario_Status_Map = new HashMap<String, String>();
	private static String browser = PropertyFileLoader.getInstance().getBrowser();
	
	//This member is used to Store scenario name
	private Scenario scenario;
	
	//This member is used to Store feature name
	private String featureName;
	
	//This array list is used to store operation status for a particular step definition
	private ArrayList<Boolean> allOperationsStatusWithinAStep = new ArrayList<Boolean>();
	
	
	// This list is used to store list of xPath used in a step definitions for each activity
	private List<String>  elementsXPathList=new ArrayList<String>();
	
	// This list is used to store data used by step definitions for each activity
	private List<String>  elementsDataList=new ArrayList<String>();
	
	// This list is used to store current activity counter and used to fetch xPath and data for current activity
	private int activityCounter=0;
	
	//This member used to store current object xPath
	private String  currentElementXPath;
	
	//This member is used to store current activity data
	private String  currentElementData;

	//This member is used to store current driver object
	private WebDriver driver;
	
	//This member is used to store a value that can be used to pass to a custom method
	private String runtimeProperty;
	
	/*
	 * =========================================================================================== 
	 * Function Name: populateExecutionContext
	 * CREATED BY: ACOE Team
	 * CREATED DATE: 05/03/2019
	 * DESCRIPTION: This method is used to populate current operation data
	 * Parameter: Nothing
	 * RETURNS: Nothing
	 * COMMENTS: 
	 * Modification Log: 
	 * Revision: 1.0
	 * Date: 05/03/2019
	 * Comment: Implemented method with initial requirement
	 *  
	 * ===========================================================================================
	 */
	/** 
	* <p style="font-family:Arial;">
	* <b>DESCRIPTION: This method is used to populate current operation data
	* <br><br>
	* Author: - ACOE Team
	* <br><br>
	* Date Created: 05/03/2019
	* <br><br>Revision History: 
	* <br>1.0: Define method and added initial code
	* <br>
	* @param  Nothing
	* @return No Return Value
	* @throws Exception  If any error occurs, reports the exception message and log the full exception trace in log file
	* </b></P> 
	* 
	*/
	public void populateExecutionContext() {
		try {
			currentElementXPath = "";
			currentElementData = "";
			try {
				currentElementXPath = elementsXPathList.get(activityCounter);
			} catch (Exception e) {
				ExceptionHandler.handleException(e);
			}
			Log.writeToLogFile("Current Object: " + currentElementXPath);
			try {
				currentElementData = elementsDataList.get(activityCounter);
			} catch (Exception e) {
				ExceptionHandler.handleException(e);
			}
			Log.writeToLogFile("Current Object Data: " + currentElementData);

			Log.writeToLogFile("Current Object Counter: " + activityCounter);

			activityCounter++;

		} catch (Exception e) {
			ExceptionHandler.handleException(e);
		}
	}
	
	/*
	 * =========================================================================================== 
	 * Function Name: getObjectLocator
	 * CREATED BY: ACOE Team
	 * CREATED DATE: 05/03/2019
	 * DESCRIPTION: This method is used to fetch current object from Object repository
	 * Parameter: 
	 * 	1.) Object repository hash map
	 *  2.) Screen Name - String
	 *  3.) Object Name - String
	 *  4.) Browser Name - String
	 * RETURNS: Object Id in form of String
	 * COMMENTS: 
	 * Modification Log: 
	 * Revision: 1.0
	 * Date: 05/03/2019
	 * Comment: Implemented method with initial requirement
	 *  
	 * ===========================================================================================
	 */
	/** 
	* <p style="font-family:Arial;">
	* <b>DESCRIPTION: This method is used to fetch current object from Object repository
	* <br><br>
	* Author: - ACOE Team
	* <br><br>
	* Date Created: 05/03/2019
	* <br><br>Revision History: 
	* <br>1.0: Define method and added initial code
	* <br>
	* @param  	1.) Object repository hash map
	 *  		2.) Screen Name - String
	 * 		 	3.) Object Name - String
	 *  		4.) Browser Name - String
	* @return Object Id in form of String
	* @throws Exception  If any error occurs, reports the exception message and log the full exception trace in log file
	* </b></P> 
	* 
	*/
	public static String getObjectLocator(HashMap<String, String> hashMapWithData, String screenName, String objectName, String browserName) {
		String returnData = "";
		try {
			returnData = hashMapWithData.get(screenName + "|" + objectName + "|" + browserName);
			Log.writeToLogFile("Value of ScreenName|ObjectName " + returnData);
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
		}
		return returnData;
	}
	
	public static String getObjectLocator(String screenName, String objectName, String browserName) {
		String returnData = "";
		try {
			returnData = DBCacheSingleton.getInstance().getHashMapObjectRepositoryData().get(screenName + "|" + objectName + "|" + browserName);
			Log.writeToLogFile("Value of ScreenName|ObjectName " + returnData);
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
		}
		return returnData;
	}

	
	/*
	 * =========================================================================================== 
	 * Function Name: getExecutionData
	 * CREATED BY: ACOE Team
	 * CREATED DATE: 05/03/2019
	 * DESCRIPTION: This method is used to get current activity execution data
	 * Parameter: 
	 *  		1.) Argument Name - String
	 * 		 	2.) Argument Value - String
	 * RETURNS: execution data - String
	 * COMMENTS: 
	 * Modification Log: 
	 * Revision: 1.0
	 * Date: 05/03/2019
	 * Comment: Implemented method with initial requirement
	 *  
	 * ===========================================================================================
	 */
	/** 
	* <p style="font-family:Arial;">
	* <b>DESCRIPTION: This method is used to get current activity execution data
	* <br><br>
	* Author: - ACOE Team
	* <br><br>
	* Date Created: 05/03/2019
	* <br><br>Revision History: 
	* <br>1.0: Define method and added initial code
	* <br>
	* @param  	1.) Argument Name - String
	 * 		 	2.) Argument Value - String
	* @return Execution data - String
	* @throws Exception  If any error occurs, reports the exception message and log the full exception trace in log file
	* </b></P> 
	* 
	*/
	public String getExecutionData(String argumentName, String argumentValue) {
		String data = "DATA_NOT_FOUND";
		try {
			
			String dataSourceStatus=PropertyFileLoader.getInstance().getProperty("FETCH_DATA_FROM_DB");
			if(dataSourceStatus!=null && dataSourceStatus.equalsIgnoreCase("YES")) {
				Log.writeToLogFile("Fetching execution data for argument '"+argumentName+"' from data base...");
				long currentThreadId=Thread.currentThread().getId();
				String dataKeyName=scenario.getName()+"_"+featureName+"_"+currentThreadId;
				
				Integer currentIterationNumber=ExecutionContext.getIteration_Number_For_Scenario_Map().get(dataKeyName);
				String environment=PropertyFileLoader.getInstance().getENVIRONMENT();
				String dataKey=featureName+"|"+scenario.getName()+"|"+environment+"|"+argumentName+currentIterationNumber;
				Log.writeToLogFile("Execution Data Key: "+dataKey);
				data=DBCacheSingleton.getInstance().getHashMapTestExecutionData().get(dataKey);
				if(data==null) {
					data="DATA_NOT_FOUND";
				}
			}else {
				data =  argumentValue;
			}
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
		}
		Log.writeToLogFile("Value of data for argument '"+argumentName+"' is '"+data+"'");
		return data;
	}

	
	/*
	 * =========================================================================================== 
	 * Function Name: getExecutionData
	 * CREATED BY: ACOE Team
	 * CREATED DATE: 05/06/2019
	 * DESCRIPTION: This method is used to get data from DataTable object based on argument name with iteration 1. 
	 * 				It will return single data
	 * Parameter: 
	 * 		 	1.) Object of DataTable class
	 * 		 	2.) Argument Name - String
	 * RETURNS: execution data - String
	 * COMMENTS: 
	 * Modification Log: 
	 * Revision: 1.0
	 * Date: 05/03/2019
	 * Comment: Implemented method with initial requirement
	 *  
	 * ===========================================================================================
	 */
	/** 
	* <p style="font-family:Arial;">
	* <b>DESCRIPTION: This method is used to get data from DataTable object based on argument name with iteration 1. It will return single data
	* <br><br>
	* Author: - ACOE Team
	* <br><br>
	* Date Created: 05/06/2019
	* <br><br>Revision History: 
	* <br>1.0: Define method and added initial code
	* <br>
	* @param  	
	* 		 	1.) Object of DataTable class
	* 		 	2.) Argument Name - String
	* @return Execution data - String
	* @throws Exception  If any error occurs, reports the exception message and log the full exception trace in log file
	* </b></P> 
	* 
	*/
	public String getExecutionData(DataTable objDataTable, String argumentName) {
		String data = "DATA_NOT_FOUND";
		int iterationNumber=1;
		try {						
			data=getExecutionData(objDataTable,argumentName,iterationNumber);
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
		}
		Log.writeToLogFile("Value of data for argument '"+argumentName+"' and iteration number '"+iterationNumber+"' is '"+data+"'");
		return data;
	}
	
	/*
	 * =========================================================================================== 
	 * Function Name: getExecutionData
	 * CREATED BY: ACOE Team
	 * CREATED DATE: 05/06/2019
	 * DESCRIPTION: This method is used to get data from DataTable object based on argument name with provided iteration. 
	 * 				It will return single data
	 * Parameter: 
	 * 		 	1.) Object of DataTable class
	 * 		 	2.) Argument Name - String
	 * 			3.) Iteration Number - Int 
	 * RETURNS: execution data - String
	 * COMMENTS: 
	 * Modification Log: 
	 * Revision: 1.0
	 * Date: 05/03/2019
	 * Comment: Implemented method with initial requirement
	 *  
	 * ===========================================================================================
	 */
	/** 
	* <p style="font-family:Arial;">
	* <b>DESCRIPTION: This method is used to get data from DataTable object based on argument name with provided iteration. 
	* 				It will return single data
	* <br><br>
	* Author: - ACOE Team
	* <br><br>
	* Date Created: 05/06/2019
	* <br><br>Revision History: 
	* <br>1.0: Define method and added initial code
	* <br>
	* @param  	
	* 		 	1.) Object of DataTable class
	* 		 	2.) Argument Name - String
	* 			3.) Iteration Number - Int
	* @return Execution data - String
	* @throws Exception  If any error occurs, reports the exception message and log the full exception trace in log file
	* </b></P> 
	* 
	*/
	public String getExecutionData(DataTable objDataTable, String argumentName, int iterationNumber) {
		String data = "DATA_NOT_FOUND";
		try {
			
			String dataSourceStatus=PropertyFileLoader.getInstance().getProperty("FETCH_DATA_FROM_DB");
			if(dataSourceStatus!=null && dataSourceStatus.equalsIgnoreCase("YES")) {
				Log.writeToLogFile("Fetching execution data for argument '"+argumentName+"' from data base...");
				String environment=PropertyFileLoader.getInstance().getENVIRONMENT();
				String dataKey=featureName+"|"+scenario.getName()+"|"+environment+"|"+argumentName+iterationNumber;
				Log.writeToLogFile("Execution Data Key: "+dataKey);
				data=DBCacheSingleton.getInstance().getHashMapTestExecutionData().get(dataKey);
				if(data==null) {
					data="DATA_NOT_FOUND";
				}
			}else {
				List<Map<String, String>> dataList = objDataTable.asMaps(String.class, String.class);
				if(dataList.size()>=iterationNumber) {
					data = dataList.get(iterationNumber-1).get(argumentName);
				}else {
					Log.writeToLogFile("No data found with argument name '"+argumentName+"' and iteration number "+iterationNumber);
				}
				
			}
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
		}
		Log.writeToLogFile("Value of data for argument '"+argumentName+"' and iteration number '"+iterationNumber+"' is '"+data+"'");
		return data;
	}	
	
	
	/*
	 * =========================================================================================== 
	 * Function Name: getExecutionDataList
	 * CREATED BY: ACOE Team
	 * CREATED DATE: 05/03/2019
	 * DESCRIPTION: This method is used to get data from DataTable object based on argument name. 
	 * 				It could return multiple data
	 * Parameter: 
	 * 		 	1.) Object of DataTable class
	 * 		 	2.) Argument Name - String
	 * RETURNS: List of execution data - Object of List<Stirng>
	 * COMMENTS: 
	 * Modification Log: 
	 * Revision: 1.0
	 * Date: 05/06/2019
	 * Comment: Implemented method with initial requirement
	 *  
	 * ===========================================================================================
	 */
	/** 
	* <p style="font-family:Arial;">
	* <b>DESCRIPTION: This method is used to get data from DataTable object based on argument name. 
	* 				And the argument name should exactly match  the column name in Feature File or Database.
	* 				
	* 		It returns a list of all rows (converted into String) existing in this column name of this step in Feature File or 
	* 		all rows existing in sequential iterations for this column name of this scenario from Database . 
	* <br><br>
	* Author: - ACOE Team
	* <br><br>
	* Date Created: 05/06/2019
	* <br><br>Revision History: 
	* <br>1.0: Define method and added initial code
	* <br>
	* @param  	
	 * 		 	1.) Object of DataTable class
	 * 		 	2.) Argument Name - String
	* @return Execution List of execution data - Object of List<Stirng>
	* @throws Exception  If any error occurs, reports the exception message and log the full exception trace in log file
	* </b></P> 
	* 
	*/
	public List<String> getExecutionDataList(DataTable objDataTable, String argumentName) {
		
		int iteration_Number = 1;
		boolean currentData_is_Not_Null_flag = true;
		
		List<String> dataList = new ArrayList<String>();
		String currentData="";
		

		try {
			
			String dataSourceStatus=PropertyFileLoader.getInstance().getProperty("FETCH_DATA_FROM_DB");
			
			while (currentData_is_Not_Null_flag) {

				if (dataSourceStatus != null && dataSourceStatus.equalsIgnoreCase("YES")) {

					String environment = PropertyFileLoader.getInstance().getENVIRONMENT();

					String dataKey = featureName + "|" + scenario.getName() + "|" + environment + "|" + argumentName
							+ (iteration_Number);

					Log.writeToLogFile("Current Execution Data Key: " + dataKey);

					currentData = DBCacheSingleton.getInstance().getHashMapTestExecutionData().get(dataKey);

				} else {

					List<Map<String, String>> dataListFromDataTable = objDataTable.asMaps(String.class, String.class);

					if (dataListFromDataTable.size() >= iteration_Number)
						currentData = dataListFromDataTable.get(iteration_Number - 1).get(argumentName);
					else
						currentData = null;

				}
				if (currentData != null) {

					dataList.add(currentData);
					iteration_Number++;
				} else {
					currentData_is_Not_Null_flag = false;
				}
			}
		}
		 catch (Exception e) {
			ExceptionHandler.handleException(e);
		}
		Log.writeToLogFile("Number of data found for argument '"+argumentName+"' is '"+dataList.size()+"'");
		Log.writeToLogFile("Extracted data list for argument '"+argumentName+"' is: "+dataList);
		return dataList;
	}
	
	
	
	/**
	 * Setter and getter method
	 * @return
	 */
	public static HashMap<String, Integer> getIteration_Number_For_Scenario_Map() {
		return iteration_Number_For_Scenario_Map;
	}

	public static void setIteration_Number_For_Scenario_Map(
			HashMap<String, Integer> iteration_Number_For_Scenario_Map) {
		ExecutionContext.iteration_Number_For_Scenario_Map = iteration_Number_For_Scenario_Map;
	}

	public ArrayList<Boolean> getAllOperationsStatusWithinAStep() {
		return allOperationsStatusWithinAStep;
	}

	public void setAllOperationsStatusWithinAStep(ArrayList<Boolean> allOperationsStatusWithinAStep) {
		this.allOperationsStatusWithinAStep = allOperationsStatusWithinAStep;
	}

	public String getFeatureName() {
		return featureName;
	}

	public void setFeatureName(String featureName) {
		this.featureName = featureName;
	}

	public static HashMap<Long, ExecutionContext> getStore_ExecutionContextInstanceForThread() {
		return store_ExecutionContextInstanceForThread;
	}

	public static void setStore_ExecutionContextInstanceForThread(
			HashMap<Long, ExecutionContext> store_ExecutionContextInstanceForThread) {
		ExecutionContext.store_ExecutionContextInstanceForThread = store_ExecutionContextInstanceForThread;
	}

	public Scenario getScenario() {
		return scenario;
	}

	public void setScenario(Scenario scenario) {
		this.scenario = scenario;
	}

	public static String getBrowser() {
		return browser;
	}

	public static void setBrowser(String browser) {
		ExecutionContext.browser = browser;
	}

	public WebDriver getDriver() {
		return driver;
	}

	public void setDriver(WebDriver driver) {
		this.driver = driver;
	}
	
	
	
	
	public HashMap<String, String> DBRetrieve = new HashMap<String, String>();

	//public String sLocator = "", sObjID, sObjIDTemp, sObjState = "", sData, sReportDesc;
	/**
	 * s_Time_Stamp - assign the time stamp value
	 */
	public String sTimeStamp = "";
	/**
	 * UI_Rec_Count - generate the UI rec count
	 */
	public int UIRecCount = 0;
	/**
	 * DB_Rec_Count - generate the DB rec count
	 */
	public int DBRecCount = 0;
	/**
	 * Identification_Mode - Mode of Identification - NATIVE/WEB
	 */
	public String sIdentificationMode = "";
	/**
	 * <b>String Device_Type - Placeholder for input of Device Type</b>
	 */
	public String Device_Type = "";
	/**
	 * <b>PAGE_WAIT_PERIOD - Waits for 180 (unit of time)</b>
	 */
	public int PAGE_WAIT_PERIOD = 100000;
	/**
	 * <b>ELEMENT_WAIT_PERIOD - Waits for 25 (unit of time)</b>
	 */
	public int ELEMENT_WAIT_PERIOD = 25;
	/**
	 * <b>EXECUTION MODE - Mode of Execution (CLOUD/LOCAL)</b>
	 */
	public String modeExecution = null;
	/**
	 * <b>String sScreenName - Object Repository SCREEN_NAME</b>
	 */
	public String sScreenName = "";
	/**
	 * <b>String sObjName - Object Repository OBJECT_NAME</b>
	 */
	public String sObjName = "";

	public String sTempValue = null;

	/**
	 * @return the elementXPath
	 */
	public String getCurrentElementXPath() {
		return currentElementXPath;
	}

	/**
	 * @param elementXPath the elementXPath to set
	 */
	public void setCurrentElementXPath(String elementXPath) {
		this.currentElementXPath = elementXPath;
	}

	/**
	 * @return the elementData
	 */
	public String getCurrentElementData() {
		return currentElementData;
	}

	/**
	 * @param elementData the elementData to set
	 */
	public void setCurrentElementData(String elementData) {
		this.currentElementData = elementData;
	}

	/*public List<String> getElementsXPathList() {
		return elementsXPathList;
	}*/

	/*public void setElementsXPathList(List<String> elementsXPathList) {
		this.elementsXPathList = elementsXPathList;
	}*/

	/*public List<String> getElementsDataList() {
		return elementsDataList;
	}

	public void setElementsDataList(List<String> elementsDataList) {
		this.elementsDataList = elementsDataList;
	}*/

	public String getRuntimeProperty() {
		return runtimeProperty;
	}

	public void setRuntimeProperty(String runtimeProperty) {
		this.runtimeProperty = runtimeProperty;
	}
	/**
	 * for each method call, user should set xpath-data pair and then call method
	 * Pass empty string respectively when xpath/data is not required to call the method
	  */

	public void setXpathDataPair(String objXpath, String data) {
		setCurrentElementData(data);
		setCurrentElementXPath(objXpath);
	}
/*	public void addXpathDataList(String objXpath, String[] dataArray) {
		//add each array element to dataList
		getElementsDataList().add(dataArray);
		getElementsXPathList().add(objXpath);
	}*/

	public static HashMap<String, String> getScenario_Status_Map() {
		return scenario_Status_Map;
	}

	public static void setScenario_Status_Map(HashMap<String, String> scenario_Status_Map) {
		ExecutionContext.scenario_Status_Map = scenario_Status_Map;
	}

}//public class GlobalVariables {
