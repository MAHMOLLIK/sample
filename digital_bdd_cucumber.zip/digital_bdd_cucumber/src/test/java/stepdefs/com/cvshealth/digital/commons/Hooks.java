package test.java.stepdefs.com.cvshealth.digital.commons;

import cucumber.api.Scenario;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import test.java.stepdefs.com.cvshealth.digital.library.BrowserInvocation;
import test.java.stepdefs.com.cvshealth.digital.library.DBCacheSingleton;
import test.java.stepdefs.com.cvshealth.digital.library.ExceptionHandler;
import test.java.stepdefs.com.cvshealth.digital.library.ExecutionContext;
import test.java.stepdefs.com.cvshealth.digital.library.Log;

/**
 * Hooks class is scanned before and after every scenario execution and functions 
 * are executed according to Junit annotations
 **/

public class Hooks {
	
	/*
	 * =========================================================================================== 
	 * Function Name: beforeHook
	 * CREATED BY: ACOE Team
	 * CREATED DATE: 05/03/2019
	 * DESCRIPTION: This method is used to execute code before starting step definition execution
	 * Parameter: Object of Scenario class
	 * RETURNS: Nothing
	 * COMMENTS: 
	 * Modification Log: 
	 * Revision: 1.0
	 * Date: 05/03/2019
	 * Comment: Implemented method with initial requirement
	 *  
	 * ===========================================================================================
	 */
	/** 
	* <p style="font-family:Arial;">
	* <b>DESCRIPTION: This method is used to execute code before starting step definition execution for every Scenario
	* <br><br>
	* Author: - ACOE Team
	* <br><br>
	* Date Created: 05/03/2019
	* <br><br>Revision History: 
	* <br>1.0: Define method and added initial code
	* <br>
	* @param  Object of Scenario class
	* @return No Return Value
	* @throws Exception  If any error occurs, reports the exception message and logs the full exception trace in log file
	* </b></P> 
	* 
	*/
	
	@Before
	public void beforeHook(Scenario scenario) {
		try {
			
		//Initialize the DB
		DBCacheSingleton.getInstance();
			
		//Create an object of ExecutionHandler class
		ExecutionContext executionContext = new ExecutionContext();
		
		
		//Store current senario name in execution handler
		executionContext.setScenario(scenario);
		
		//Store current feature name in ExecutionHandler class
		String feature = scenario.getId().split(";")[0].replaceAll("-", " ").toUpperCase();
		executionContext.setFeatureName(feature);
		
		long currentThreadId=Thread.currentThread().getId();
	    
		//Store current ExecutionHandler object in Execution context
		ExecutionContext.getStore_ExecutionContextInstanceForThread().put(currentThreadId, executionContext);
		
		Integer iterationNumber=1;
		String dataKeyName=scenario.getName()+"_"+feature+"_"+currentThreadId;
		Log.writeToLogFile("Current Iteration Key: "+dataKeyName);
		Integer currentIterationNumber=ExecutionContext.getIteration_Number_For_Scenario_Map().get(dataKeyName+"");
		Log.writeToLogFile("Last Executed Iteration: "+currentIterationNumber);
		Log.writeToLogFile("Current Iteration: "+iterationNumber);
		if(!(currentIterationNumber==null || currentIterationNumber==0 )) {			
			iterationNumber=iterationNumber+1;
		}
		
		//store current iteration number for a unique key:(ScenarioNmae_FeatureName_ThreadId)
		ExecutionContext.getIteration_Number_For_Scenario_Map().put(dataKeyName+"",iterationNumber);
		Log.writeToLogFile("Current Iteration: "+iterationNumber);
		
		
		
		Log.writeToLogFile("Before Hook - Scenario Name: " +scenario.getName());
		Log.writeToLogFile("Before Hook - Feature Name: " +executionContext.getFeatureName());
		
		//Instantiate browser
		new BrowserInvocation(ExecutionContext.getBrowser(), executionContext);	
				
		}catch(Exception e) {
			ExceptionHandler.handleException(e);
		}
	}
	/*
	 * =========================================================================================== 
	 * Function Name: tearDown
	 * CREATED BY: ACOE Team
	 * CREATED DATE: 05/03/2019
	 * DESCRIPTION: This method is used to execute code after completing step definition execution for every Scenario
	 * Parameter: None
	 * RETURNS: Nothing
	 * COMMENTS: 
	 * Modification Log: 
	 * Revision: 1.0
	 * Date: 05/03/2019
	 * Comment: Implemented method with initial requirement
	 *  
	 * ===========================================================================================
	 */
	/** 
	* <p style="font-family:Arial;">
	* <b>DESCRIPTION: This method is used to execute code after completing step definition execution for every Scenario
	* <br><br>
	* Author: - ACOE Team
	* <br><br>
	* Date Created: 05/03/2019
	* <br><br>Revision History: 
	* <br>1.0: Define method and added initial code
	* <br>
	* @param  None
	* @return No Return Value
	* @throws Exception  If any error occurs, reports the exception message and logs the full exception trace in log file
	* </b></P> 
	* 
	*/
	
	@After
	public void tearDown() {
		try {
			Log.writeToLogFile("Inside tear down");
			Log.writeToLogFile("Cleaninng up the execution");

			// fetches ExecutionContext instance for currently running thread
			ExecutionContext executionContext = ExecutionContext.getStore_ExecutionContextInstanceForThread()
					.get(Thread.currentThread().getId());

			String dataKey = executionContext.getScenario().getName() + "_" + executionContext.getFeatureName();

			long currentThreadId = Thread.currentThread().getId();

			Integer currentIterationNumber = ExecutionContext.getIteration_Number_For_Scenario_Map()
					.get(dataKey + "_" + currentThreadId);

			// determines the status of scenario, If map already has the key
			// then Scenario might have failed as it has been added earlier in
			// ReportUtility class
			if (!(ExecutionContext.getScenario_Status_Map().containsKey(dataKey)))
				ExecutionContext.getScenario_Status_Map().put(dataKey, "PASS");

			else if (ExecutionContext.getScenario_Status_Map().containsKey(dataKey) && currentIterationNumber > 1) {

				if (!(ExecutionContext.getScenario_Status_Map().get(dataKey).contains("|"))) {
					String statusAlready = ExecutionContext.getScenario_Status_Map().get(dataKey);
					ExecutionContext.getScenario_Status_Map().put(dataKey, statusAlready + "|" + "PASS");
				}
			}

			System.out.println("Scenario Status tear down: " + ExecutionContext.getScenario_Status_Map());

			// closes browser and quits driver after completing Scenario
			try {
				executionContext.getDriver().quit();
			} catch (Exception e) {
				ExceptionHandler.handleException(e);
			}

			Log.writeToLogFile(Log.logMessageList);
			Log.logMessageList.clear();
			
		}catch(Exception e) {
			ExceptionHandler.handleException(e);
		}
	}

}
