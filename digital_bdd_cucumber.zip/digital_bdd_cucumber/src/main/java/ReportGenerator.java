package main.java;
import java.io.File;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import net.masterthought.cucumber.Configuration;
import net.masterthought.cucumber.ReportBuilder;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
 
/** 
 * <p style="font-family:Arial;">
* <b>Class Name:ReportGenerator</b>
* <b>Method Description: This class shall generate cucumber reports.
* Author: - Srikanth Srinivas (Cognizant) / Rakesh Ghosal (Cognizant)
* <br><br>
* Date Created: Jan-2019
* <br><br>Revision History: 
 * <br>1.0: Define method and added initial code
* <br>
* @param  No Parameters
* @return No Return Value   //Adding a comment for demo
* @throws Exception  If any error if not able to generate reports
* </b></P> 
 * 
 */

public class ReportGenerator {
	
	static String filePath=null;
	
	public static void main(String args[]) throws Exception
	{
		generateReport();
		Thread.sleep(5000);
	
	}

	/**
	 * This method will generate Cucumber Report after execution is completed. 
	 * @throws Exception
	 */
	public static void generateReport() throws Exception {
		List<String> allJsonFiles = getJsonFiles();
		List<String> jsonFiles = new ArrayList<String>();
		for(int i=0;i<allJsonFiles.size();i++)
		{
			jsonFiles.add("target/cucumber-parallel/"+allJsonFiles.get(i));
		}
		String timeStamp = getTimeStamp();
		
		filePath=System.getProperty("user.dir")+"\\TestResults\\"+timeStamp;
		File reportOutputDirectory = new File(filePath);
		
		
		String buildNumber = "1";
		String projectName = "Digital";
		boolean runWithJenkins = false;
		boolean parallelTesting = true;

		Configuration configuration = new Configuration(reportOutputDirectory,
				projectName);
		// optional configuration
		configuration.setParallelTesting(parallelTesting);
		configuration.setRunWithJenkins(runWithJenkins);
		configuration.setBuildNumber(buildNumber);
		
		ReportBuilder reportBuilder = new ReportBuilder(jsonFiles,
				configuration);
		
		reportBuilder.generateReports();
		System.out.println("Report got generated");
	}
	
	/**
	 * This Method will get all the JSON files generated and delete the corrupted JSON 
	 * file to generate report successfully. 
	 * @return
	 */
	public static List<String> getJsonFiles()
	{
		List<String> allJsonFiles=new ArrayList<String>();
		File folder = new File(System.getProperty("user.dir")+"\\target\\cucumber-parallel");
		File[] listOfFiles = folder.listFiles();

		    for (int i = 0; i < listOfFiles.length; i++) {
		      if (listOfFiles[i].isFile()) {
		    	  if(listOfFiles[i].getName().endsWith("json"))
		    	  {
		    		  boolean jsonFileValidationStatus=validateEmptyJsonFile(System.getProperty("user.dir")+"\\target\\cucumber-parallel\\"+listOfFiles[i].getName());
		              System.out.println("File " + listOfFiles[i].getName() +jsonFileValidationStatus);
		              if(jsonFileValidationStatus==true)
		              {
		               allJsonFiles.add(listOfFiles[i].getName());
		              }
		    	  }
		      }
	}
		    return allJsonFiles;
	}
	
	/**
	 * This method will validate if a generated JSON file is empty or not.
	 * @param filePath
	 * @return
	 */
	public static boolean validateEmptyJsonFile(String filePath)
	{
		try
		{
			File file = new File(filePath);

			if (file.length() == 0) {
				//Adding code to delete corrupted file so that Jenkins would able to make report - Rakesh
				try
				{
					if(file.delete())
					{
						System.out.println("Corrupted File Deleted Successfully ");
					}
				}
				catch(Exception e)
				{
					System.out.println("Corrupted file could not deleted successfully, exception occurred "+e);
				}
			    return false;
			} else {
			    return true;
			}
			
		}
		catch(Exception e)
		{
			System.out.println("Exception occurred while validating JSON file is empty or not "+e);
			return false;
		}
		
	}
	
	/**
	 * This method will give current time stamp in MM-dd-yyyy HH:mm:ss format. 
	 * @return
	 * @throws Exception
	 */
	public static String getTimeStamp() throws Exception
	{
		Date todaysDate = new Date();
	    DateFormat df = new SimpleDateFormat("MM-dd-yyyy HH:mm:ss");
	    String timeStamp = df.format(todaysDate);
	    String tempStr = timeStamp.replace(" ", "_");
	    String tempStr1 = tempStr.replace(":", "");
	    timeStamp = tempStr1.replace("-", "_");
	    return timeStamp;
	}
	
	/**
	 * This method will open the the cucumber report and get all the results. 
	 * @throws IOException
	 * @throws InterruptedException
	 */
	public static void getResultOverview() throws IOException, InterruptedException
	{
		System.out.println("Called openBrowser");
		String exePath = "C:\\Automation_Enterprise\\chromedriver_win32\\chromedriver.exe";
		//String exePath = "C:\\Automation_Enterprise\\Selenium\\Resources\\Chrome\\chromedriver.exe";
		System.setProperty("webdriver.chrome.driver", exePath);
		ChromeOptions options = new ChromeOptions();
		options.setExperimentalOption("useAutomationExtension", false);
		options.addArguments("start-maximized");
		options.addArguments("--no-sandbox");
		options.addArguments("--disable-extensions-except");
		options.addArguments("disable-extensions");
		WebDriver driver = new ChromeDriver(options);
		driver.get(filePath + "\\cucumber-html-reports\\overview-features.html");
		Thread.sleep(2000);

		WebElement ele = driver.findElement(By.xpath("//*[@id='tablesorter']"));
		JavascriptExecutor je = (JavascriptExecutor) driver;
		je.executeScript("arguments[0].scrollIntoView(true);", ele);

		// Get entire page screenshot
		File screenshot = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);

		File screenshotLocation = new File(System.getProperty("user.dir") + "\\testResult.png");
		FileUtils.copyFile(screenshot, screenshotLocation);
		// driver.close();
		driver.quit();
	}
}//public class ReportGenerator {
/************************************************************************************/




