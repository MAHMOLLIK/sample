package main.java.util;
public interface EnvProperties {
	public static String INBOUND_LOCATION = "INBOUND_LOCATION";	
	public static String WAIT_TIME = "WAIT_TIME";
	public static String MAX_WAIT_TIME = "MAX_WAIT_TIME";	
	public static String MAINTAIN_REPORTS = "MAINTAIN_REPORTS";
}//public interface EnvProperties {
