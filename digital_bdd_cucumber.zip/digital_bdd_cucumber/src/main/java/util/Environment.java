package main.java.util;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;
import main.java.template.UtilityConstants;
public class Environment {	
	private static Properties prop;		
	public static void loadProperties(){
		loadProperties(UtilityConstants.ENV_PROPERTIES);
	}//public static void loadProperties(){	
	public static void loadProperties(String fileName){
        ClassLoader loader = Thread.currentThread().getContextClassLoader();
        prop = new Properties();
        try {
            try(InputStream resourceStream = loader.getResourceAsStream(fileName)) {
            	prop.load(resourceStream);
            }//try(InputStream resourceStream = loader.getResourceAsStream(fileName)) {
        } catch (IOException e) {
            e.printStackTrace();
        }//try {		
	}//public static void loadProperties(String fileName){	
	public static String getValue(String key){
		if(prop == null){
			loadProperties();
		}//if(prop == null){
		return prop.getProperty(key);
	}//public static String getValue(String key){
}//public class Environment {

