package main.java.template;
public class UtilityConstants {
	public static String SETTINGS_PROPERTIES="settings.properties";
	public static String ENV_PROPERTIES="environment.Properties";	
	public static String FILE_PATH_PROPERTIES="src/test/resources/";
}//public class UtilityConstants {
